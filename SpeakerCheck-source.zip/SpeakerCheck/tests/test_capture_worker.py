import os
import threading
import json
from pathlib import Path
import pytest
from PySide6.QtWidgets import QApplication
from speakercheck.capture_ui import CaptureWorker
from speakercheck.production import ProductionStore
from speakercheck.audio import CapturePlan,one_khz_spec
from speakercheck.spec import default_spec
from test_capture import SyntheticBackend

@pytest.fixture(scope='module')
def app(): return QApplication.instance() or QApplication([])


def test_real_sox_after_capture_is_persisted_before_success(app,tmp_path):
    store=ProductionStore(tmp_path)
    plan=CapturePlan(input_device=2,output_device=3,duration=.2,settle=.05)
    spec=one_khz_spec(default_spec(),1,False,False)
    spec['confirmed']=True
    run=store.begin('SN001','kim','line1',{'plan':'test'})
    worker=CaptureWorker(store,run,plan,spec,os.environ.get('SOX_BINARY','sox'),backend=SyntheticBackend())
    outputs=[];errors=[]
    worker.succeeded.connect(lambda report:outputs.append((report,store.history()[0]['state'])))
    worker.failed.connect(errors.append)
    worker.run()
    assert not errors
    assert len(outputs)==1
    report,state_at_signal=outputs[0]
    assert state_at_signal==report['verdict']=='PASS'
    assert report['production']['serial']=='SN001'
    assert report['capture']['plan']['frequency']==1000
    assert Path(run['wav_path']).is_file()
    assert len(report['source']['sha256'])==64
    from speakercheck.report import export_csv
    csv_path=tmp_path/'measurement.csv'
    export_csv(report,csv_path)
    assert 'SN001' in csv_path.read_text('utf-8-sig')
    assert run['run_id'] in csv_path.read_text('utf-8-sig')


def test_cancelled_test_logged_and_no_wav_or_success(app,tmp_path):
    store=ProductionStore(tmp_path)
    run=store.begin('SN001','op','line1',{})
    w=CaptureWorker(store,run,CapturePlan(input_device=2,output_device=3),default_spec(),os.environ.get('SOX_BINARY','sox'),backend=SyntheticBackend())
    w.request_cancel()
    outputs=[];w.succeeded.connect(outputs.append)
    w.run()
    assert not outputs
    assert store.history()[0]['state']=='ABORTED'
    assert not Path(run['wav_path']).exists()


def test_persistence_failure_does_not_emit_pass(app,tmp_path,monkeypatch):
    store=ProductionStore(tmp_path)
    run=store.begin('SN001','op','line1',{})
    original=store.finish
    def fail_final(run_id,state,report=None,error='',**kwargs):
        if state in ('PASS','SPEC REQUIRED','INCOMPLETE','NG'):
            raise OSError('disk full')
        return original(run_id,state,report,error,**kwargs)
    monkeypatch.setattr(store,'finish',fail_final)
    w=CaptureWorker(store,run,CapturePlan(input_device=2,output_device=3,duration=.2,settle=.05),
        one_khz_spec(default_spec(),1,False,False),os.environ.get('SOX_BINARY','sox'),backend=SyntheticBackend())
    outputs=[];errors=[];w.succeeded.connect(outputs.append);w.failed.connect(errors.append)
    w.run()
    assert not outputs and errors
    assert store.history()[0]['state']=='ERROR'


def test_profile_preserves_numeric_limits_but_needs_reconfirmation():
    s=default_spec();s['confirmed']=True
    s['metrics']['thd_percent']['upper']=1.23456789
    r=one_khz_spec(s,1,False,False)
    assert r['metrics']['thd_percent']['upper']==1.23456789
    assert not r['confirmed']
    for key in ['response_db','noise_dbfs','snr_db','balance_db','spl_db']:
        assert not r['metrics'][key]['enabled']
    assert s['confirmed'] and s['metrics']['response_db']['enabled']


def test_cancel_during_finalizing_event_cannot_commit_pass(app,tmp_path,monkeypatch):
    store=ProductionStore(tmp_path)
    plan=CapturePlan(input_device=2,output_device=3,duration=.2,settle=.05)
    spec=one_khz_spec(default_spec(),1,False,False);spec['confirmed']=True
    run=store.begin('SN','op','station',{})
    w=CaptureWorker(store,run,plan,spec,os.environ.get('SOX_BINARY','sox'),backend=SyntheticBackend())
    real=store._event
    def cancel_during_log(run_id,event,detail=None):
        real(run_id,event,detail)
        if event=='run.finalizing': w.request_cancel()
    monkeypatch.setattr(store,'_event',cancel_during_log)
    success=[];w.succeeded.connect(success.append)
    w.run()
    assert not success
    assert store.history()[0]['state']=='ABORTED'


def test_late_signal_loss_cannot_pass_even_when_average_and_thd_pass(app,tmp_path,monkeypatch):
    import numpy as np
    from speakercheck.audio import CapturedAudio
    from speakercheck.analysis import AnalysisSettings
    import speakercheck.capture_ui as module
    t=np.arange(144000)/48000
    x=(10**(-24/20)*np.sin(2*np.pi*1000*t)).astype(np.float32)[:,None]
    x[48000:]=0
    def acquire(*args,**kwargs):
        return CapturedAudio(x,AnalysisSettings(signal_end=3,tone_hz=1000),{'plan':{}})
    monkeypatch.setattr(module,'capture_audio',acquire)
    store=ProductionStore(tmp_path);run=store.begin('DROPOUT','op','station',{})
    spec=one_khz_spec(default_spec(),1,False,False);spec['confirmed']=True
    w=CaptureWorker(store,run,CapturePlan(2,3,duration=3),spec,os.environ.get('SOX_BINARY','sox'))
    success=[];w.succeeded.connect(success.append);w.run()
    assert success and success[0]['verdict']=='INCOMPLETE'
    assert not success[0]['capture']['valid_1khz_return']
    assert store.history()[0]['state']=='INCOMPLETE'
