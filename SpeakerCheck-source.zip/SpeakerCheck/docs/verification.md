# 검증 기록

2026-10-23, Linux cloud environment. Windows 실행/EXE 빌드 미검증.

실제 SoX 14.4.2를 사용하여 다음을 검증했다:
- 16bit stereo/24bit PCM/normalized float, 공백·한국어 경로.
- 정해진 RMS/Peak/THD(1%, off-bin tone)/SNR/좌우차/SPL/광대역 상대 gain.
- 합성 composite WAV의 모든 항목 PASS와 왜율·좌우차 NG 전이.
- 무음·mono·겹친 구간·대역 자극 부족·invalid Spec·NaN/Inf·float overrange.
- timeout·입력 변경·decode budget·truncated WAV.
- 실제 Qt offscreen worker→표시→설정 변경 후 export 무효화.
- 확인 체크 변경 후 stale report 제거, Spec float 정밀도 보존, 입력/그래프 visibility.

독립 리뷰에서 중요한 3건을 발견하고 각 재현 테스트 RED→GREEN으로 수정했다:
1. bool signal→0-argument signal 연결로 확인 상태 변경이 결과를 무효화하지 못함: lambda 연결.
2. imported Spec을 6자리 숫자로 포맷하여 NG가 PASS로 바뀔 수 있음: round-trip 문자열 사용.
3. SoX가 invalid/overrange float를 finite clipped 표본으로 변환: 원본 float 사전 검증.

추가 UI 시각 확인에서 Qt NoButtons spin field 폭이 1px가 되는 현상을 발견: 기본 spin controls 사용. 그래프의 최소 높이와 측정 페이지 스크롤을 설정했다.

Minor deferred: 최상위 Spec의 알 수 없는 추가 필드는 허용/보존되지만 판정에는 사용하지 않는다. version은 1과 동등한 numeric/bool도 통과한다. metric와 주파수 기준점의 키는 엄격히 검사한다. 현재 version 1의 판정에는 영향 없으며 향후 schema version 도입 시 엄격한 타입 검사를 권장한다.

실제 스피커·마이크/녹음 chain·교정기·제품 Spec은 제공되지 않았으므로 물리 성능/생산 라인 PASS를 주장하지 않는다.

최종 실행: `python -m pytest tests -q` → **38 passed** (2.46s). `python scripts/preview.py` → 예시 Spec 상태 `SPEC REQUIRED`, 항목 9개 PASS. `python -m compileall -q speakercheck launch.py scripts` → exit 0. 실제 Qt 화면 PNG 확인.
