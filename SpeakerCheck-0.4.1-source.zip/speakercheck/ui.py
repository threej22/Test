"""Korean desktop UI. Analysis runs on a worker with immutable input snapshots."""
from pathlib import Path
from datetime import datetime
from .production import KST
import sys
from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtGui import QColor,QShortcut,QKeySequence
from PySide6.QtWidgets import (QApplication,QMainWindow,QWidget,QFrame,QVBoxLayout,QHBoxLayout,
    QLabel,QPushButton,QLineEdit,QDoubleSpinBox,QCheckBox,QFormLayout,QStackedWidget,
    QScrollArea,QTableWidget,QTableWidgetItem,QHeaderView,QAbstractItemView,QFileDialog,
    QMessageBox,QTabWidget,QProgressBar,QSplitter,QTextBrowser,QComboBox)
from .styles import STYLE
from .spec import default_spec
from .spec_editor import SpecEditor
from .analysis import AnalysisSettings
from .sox import SoxEngine, locate_sox
from .report import make_report, export_json, export_csv
from .plots import MeasurementPlot

STATUS_COLORS = {'PASS':'#70e4be','NG':'#ff8995','UNAVAILABLE':'#efc27a','SKIP':'#879bb6',
                 'INCOMPLETE':'#efc27a','SPEC REQUIRED':'#efc27a','READY':'#8ba3bd'}


def label(text, kind=None, wrap=False):
    w = QLabel(text)
    if kind:
        w.setObjectName(kind)
    w.setWordWrap(wrap)
    return w


def card():
    w = QFrame()
    w.setObjectName('card')
    layout = QVBoxLayout(w)
    layout.setContentsMargins(17,14,17,14)
    layout.setSpacing(9)
    return w,layout


def spin(value=0, maximum=36000, minimum=0, decimals=3):
    w = QDoubleSpinBox()
    w.setRange(minimum,maximum)
    w.setDecimals(decimals)
    w.setValue(value)
    return w


class AnalysisWorker(QThread):
    succeeded = Signal(object)
    failed = Signal(str)

    def __init__(self, sox, path, settings, spec, reference):
        super().__init__()
        self.args = sox,path,settings,spec,reference

    def run(self):
        try:
            sox,path,settings,spec,reference = self.args
            self.succeeded.emit(make_report(SoxEngine(sox),path,settings,spec,reference))
        except Exception as exc:
            self.failed.emit(str(exc))


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.report = None
        self.worker = None
        self.current_run_id = None
        self._initializing = True
        self.setWindowTitle('SpeakerCheck · SoX Speaker Verification')
        self.resize(1540,1080)
        self.setMinimumSize(1180,800)
        self.setStyleSheet(STYLE)
        central = QWidget()
        self.setCentralWidget(central)
        root = QHBoxLayout(central)
        root.setContentsMargins(0,0,0,0)
        root.setSpacing(0)
        sidebar = QFrame()
        sidebar.setObjectName('sidebar')
        sidebar.setFixedWidth(208)
        nav = QVBoxLayout(sidebar)
        nav.setContentsMargins(18,30,18,22)
        nav.setSpacing(10)
        nav.addWidget(label('◈  SpeakerCheck','brand'))
        nav.addWidget(label('ACOUSTIC VERIFICATION','eyebrow'))
        nav.addSpacing(36)
        self.nav_buttons = []
        for i,text in enumerate(('01   WAV 분석','02   Spec 관리','03   설정')):
            button = QPushButton(text)
            button.setObjectName('nav')
            button.setCheckable(True)
            button.clicked.connect(lambda checked=False,index=i:self.navigate(index))
            nav.addWidget(button)
            self.nav_buttons.append(button)
        nav.addStretch()
        nav.addWidget(label('LOCAL ANALYSIS','eyebrow'))
        nav.addWidget(label('WAV → SoX → Spec\n항목별 판정과 결과 추적','muted',True))
        nav.addSpacing(12)
        nav.addWidget(label('SpeakerCheck  0.4.1\nWindows desktop','muted'))
        root.addWidget(sidebar)
        body = QWidget()
        outer = QVBoxLayout(body)
        outer.setContentsMargins(26,22,26,16)
        outer.setSpacing(15)
        header = QHBoxLayout()
        headings = QVBoxLayout()
        headings.addWidget(label('스피커 검증','title'))
        headings.addWidget(label('분석 실행 한 번으로 녹음부터 PASS/FAIL 판정까지 진행합니다.','muted'))
        header.addLayout(headings)
        header.addStretch()
        self.audio_stop_button=QPushButton('■ 오디오 중지 (Esc)')
        self.audio_stop_button.setEnabled(False)
        self.audio_stop_button.clicked.connect(lambda:self.capture_panel.stop_all())
        header.addWidget(self.audio_stop_button,0,Qt.AlignmentFlag.AlignTop)
        self.stop_shortcut=QShortcut(QKeySequence('Esc'),self)
        self.stop_shortcut.activated.connect(lambda:self.capture_panel.stop_all())
        self.local_badge = label('●  LOCAL · SoX','badge')
        header.addWidget(self.local_badge,0,Qt.AlignmentFlag.AlignTop)
        outer.addLayout(header)
        self.pages = QStackedWidget()
        outer.addWidget(self.pages,1)
        self.status = label('준비됨 · 출력과 입력 장치를 선택하고 분석 실행을 누르세요.','muted')
        outer.addWidget(self.status)
        root.addWidget(body,1)
        self._measurement_page()
        spec_scroll = QScrollArea()
        spec_scroll.setWidgetResizable(True)
        self.spec_editor = SpecEditor()
        spec_scroll.setWidget(self.spec_editor)
        self.pages.addWidget(spec_scroll)
        self._settings_page()
        self._capture_page()
        self.spec_editor.changed.connect(self.invalidate)
        self.capture_panel.refresh_devices()
        self._initializing = False
        self.navigate(0)

    def navigate(self,index):
        self.pages.setCurrentIndex(index)
        for i,button in enumerate(self.nav_buttons):
            button.setChecked(i == index)

    def _measurement_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        self.measurement_layout=layout
        layout.setContentsMargins(0,0,0,0)
        layout.setSpacing(14)
        self.file_card,files = card()
        top = QHBoxLayout()
        top.addWidget(label('측정 파일','section'))
        top.addStretch()
        demo_button = QPushButton('합성 샘플 열기')
        demo_button.clicked.connect(self.load_demo)
        top.addWidget(demo_button)
        files.addLayout(top)
        self.source_edit = QLineEdit()
        self.source_edit.setPlaceholderText('분석할 스피커 녹음 WAV 파일')
        self.reference_edit = QLineEdit()
        self.reference_edit.setPlaceholderText('선택 · 동일 시험의 기준 WAV (주파수 응답 비교용)')
        for title,edit in [('DUT WAV',self.source_edit),('기준 WAV',self.reference_edit)]:
            row = QHBoxLayout()
            tag = label(title,'muted')
            tag.setFixedWidth(72)
            row.addWidget(tag)
            row.addWidget(edit,1)
            button = QPushButton('파일 선택')
            button.clicked.connect(lambda checked=False,e=edit:self.browse_wav(e))
            row.addWidget(button)
            files.addLayout(row)
            edit.textChanged.connect(self.invalidate)
        layout.addWidget(self.file_card)
        split = QSplitter(Qt.Orientation.Horizontal)
        self.conditions,conditions = card()
        conditions.addWidget(label('측정 조건','section'))
        conditions.addWidget(label('단위: 초 · 종료 0 = 파일 끝','muted'))
        conditions.addSpacing(3)
        form = QFormLayout()
        form.setSpacing(9)
        self.signal_start = spin()
        self.signal_end = spin()
        form.addRow('신호 시작',self.signal_start)
        form.addRow('신호 종료',self.signal_end)
        conditions.addLayout(form)
        self.tone_enabled = QCheckBox('THD · 정상상태 단일 톤')
        conditions.addWidget(self.tone_enabled)
        self.tone_hz = spin(1000,maximum=40000,minimum=20,decimals=2)
        self.tone_hz.setSuffix(' Hz')
        conditions.addWidget(self.tone_hz)
        self.noise_enabled = QCheckBox('무음 구간 지정 · Noise / SNR')
        conditions.addWidget(self.noise_enabled)
        nf = QFormLayout()
        self.noise_start = spin(1)
        self.noise_end = spin(2)
        nf.addRow('무음 시작',self.noise_start)
        nf.addRow('무음 종료',self.noise_end)
        conditions.addLayout(nf)
        self.response_enabled = QCheckBox('주파수 응답 구간 별도 지정')
        conditions.addWidget(self.response_enabled)
        rf = QFormLayout()
        self.response_start = spin(2)
        self.response_end = spin(4)
        rf.addRow('응답 시작',self.response_start)
        rf.addRow('응답 종료',self.response_end)
        conditions.addLayout(rf)
        self.calibration_enabled = QCheckBox('교정 offset 적용 · dB SPL')
        conditions.addWidget(self.calibration_enabled)
        self.calibration_db = spin(110,maximum=250,minimum=-100,decimals=2)
        self.calibration_db.setSuffix(' dB')
        conditions.addWidget(self.calibration_db)
        conditions.addWidget(label('교정 offset = 기준 음압 − 교정 녹음 RMS(dBFS). 동일 마이크·게인 조건에만 적용하세요.','muted',True))
        conditions.addStretch()
        conditions.addWidget(label('필수 조건이 부족한 항목은 측정 불가로 표시됩니다.','muted',True))
        self.conditions.setMinimumWidth(278)
        condition_scroll = QScrollArea()
        self.condition_scroll=condition_scroll
        condition_scroll.setWidgetResizable(True)
        condition_scroll.setWidget(self.conditions)
        split.addWidget(condition_scroll)
        result = QWidget()
        results = QVBoxLayout(result)
        results.setContentsMargins(10,0,0,0)
        results.setSpacing(12)
        self.summary_card,summary = card()
        summary_top = QHBoxLayout()
        verdict_text = QVBoxLayout()
        verdict_text.addWidget(label('FINAL RESULT','eyebrow'))
        self.verdict_label = label('READY','verdict')
        self.verdict_caption = label('분석 대기 · 실제 제품 Spec을 설정하세요.','muted',True)
        verdict_text.addWidget(self.verdict_label)
        verdict_text.addWidget(self.verdict_caption)
        self.run_identity=label('검사 ID: —','muted',True)
        self.run_identity.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        verdict_text.addWidget(self.run_identity)
        summary_top.addLayout(verdict_text,1)
        self.run_button = QPushButton('▶  분석 실행')
        self.run_button.setObjectName('primary')
        self.run_button.clicked.connect(self.start_analysis)
        summary_top.addWidget(self.run_button)
        summary.addLayout(summary_top)
        self.progress = QProgressBar()
        self.progress.setFixedHeight(4)
        self.progress.setTextVisible(False)
        self.progress.hide()
        summary.addWidget(self.progress)
        results.addWidget(self.summary_card)
        self.graph_panel=QWidget()
        self.graph_panel.setMinimumHeight(430)
        graph_layout=QVBoxLayout(self.graph_panel)
        graph_layout.setContentsMargins(0,0,0,0)
        metric_row = QHBoxLayout()
        self.metric_labels = {}
        for key,title,unit in [('rms_dbfs','RMS LEVEL','dBFS'),('thd_percent','THD · H2–H5','%'),('balance_db','L / R DIFFERENCE','dB')]:
            box,box_layout = card()
            box_layout.addWidget(label(title,'muted'))
            value = label('—','metric')
            box_layout.addWidget(value)
            box_layout.addWidget(label(unit,'muted'))
            metric_row.addWidget(box)
            self.metric_labels[key] = value
        graph_layout.addLayout(metric_row)
        self.plot_tabs = QTabWidget()
        self.plot_tabs.setFixedHeight(310)
        self.plots = {}
        for key,title in [('waveform','원본 / 입력 파형'),('spectrum','원본 / 입력 주파수'),('overview','전체 녹음')]:
            plot = MeasurementPlot(key)
            self.plots[key] = plot
            self.plot_tabs.addTab(plot,title)
        graph_layout.addWidget(label('자동 검사: 원본은 설정한 디지털 1 kHz 신호입니다. 파형 위상만 입력 L에 맞추며 진폭은 보정하지 않습니다. 음향 기준 측정이나 지연 측정이 아닙니다.','muted',True))
        graph_layout.addWidget(self.plot_tabs)
        results.addWidget(self.graph_panel,2)
        self.graph_panel.hide()
        result_top = QHBoxLayout()
        result_top.addWidget(label('항목별 판정','section'))
        result_top.addStretch()
        self.graph_toggle=QPushButton('그래프 보기')
        self.graph_toggle.setCheckable(True)
        self.graph_toggle.toggled.connect(self.graph_panel.setVisible)
        self.graph_toggle.toggled.connect(lambda checked:self.graph_toggle.setText('그래프 접기' if checked else '그래프 보기'))
        result_top.addWidget(self.graph_toggle)
        self.export_json_button = QPushButton('JSON 저장')
        self.export_csv_button = QPushButton('CSV 저장')
        self.export_json_button.clicked.connect(lambda:self.save_result('json'))
        self.export_csv_button.clicked.connect(lambda:self.save_result('csv'))
        for button in (self.export_json_button,self.export_csv_button):
            button.setEnabled(False)
            result_top.addWidget(button)
        results.addLayout(result_top)
        self.result_table = QTableWidget(0,5)
        self.result_table.setHorizontalHeaderLabels(['검사 항목','측정값','허용 범위','판정','사유'])
        self.result_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.result_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.result_table.setAlternatingRowColors(True)
        self.result_table.verticalHeader().hide()
        self.result_table.setColumnWidth(0,167)
        self.result_table.setColumnWidth(1,152)
        self.result_table.setColumnWidth(2,122)
        self.result_table.setColumnWidth(3,104)
        self.result_table.horizontalHeader().setSectionResizeMode(4,QHeaderView.ResizeMode.Stretch)
        self.result_table.setMinimumHeight(260)
        self.result_table.itemSelectionChanged.connect(self.show_reason)
        results.addWidget(self.result_table,3)
        self.reason_label = label('행을 선택하면 상세 사유를 확인할 수 있습니다.','muted',True)
        self.reason_label.setMinimumHeight(34)
        results.addWidget(self.reason_label)
        split.addWidget(result)
        split.setStretchFactor(0,0)
        split.setStretchFactor(1,1)
        split.setSizes([285,1000])
        layout.addWidget(split,1)
        measurement_scroll = QScrollArea()
        measurement_scroll.setWidgetResizable(True)
        measurement_scroll.setWidget(page)
        page.setMinimumHeight(820)
        self.graph_toggle.toggled.connect(lambda checked:page.setMinimumHeight(1280 if checked else 820))
        self.pages.addWidget(measurement_scroll)
        for control in (self.signal_start,self.signal_end,self.tone_hz,self.noise_start,self.noise_end,
                        self.response_start,self.response_end,self.calibration_db):
            control.valueChanged.connect(self.invalidate)
        for check,controls in [(self.tone_enabled,[self.tone_hz]),(self.noise_enabled,[self.noise_start,self.noise_end]),
                               (self.response_enabled,[self.response_start,self.response_end]),
                               (self.calibration_enabled,[self.calibration_db])]:
            for control in controls:
                control.setEnabled(False)
                check.toggled.connect(control.setEnabled)
            check.toggled.connect(self.invalidate)

    def _settings_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        self.settings_layout=layout
        layout.setContentsMargins(0,0,0,0)
        box,settings = card()
        self.sox_card = box
        settings.addWidget(label('SoX 실행 환경','section'))
        settings.addWidget(label('Windows에서는 설치한 sox.exe를 선택하세요. SoX는 별도로 제공해야 합니다.','muted',True))
        row = QHBoxLayout()
        self.sox_edit = QLineEdit(locate_sox())
        self.sox_edit.textChanged.connect(self.invalidate)
        row.addWidget(self.sox_edit,1)
        browse = QPushButton('실행 파일 선택')
        browse.clicked.connect(self.browse_sox)
        row.addWidget(browse)
        settings.addLayout(row)
        layout.addWidget(box)
        help_view = QTextBrowser()
        self.help_view=help_view
        help_view.setHtml('''<h2>측정과 판정 안내</h2>
        <p>WAV 분석 화면의 분석 실행을 누르면 PC 1kHz 출력, 입력 녹음, WAV 생성, 분석과 판정이 자동으로 이어집니다. WAV와 시험 로그는 자동 저장합니다. 기존 파일 분석은 설정에서 선택할 수 있습니다.</p>
        <h3>1. 제품 Spec 설정</h3><p>Spec 관리에서 검사 사용 여부와 상·하한을 설정하세요. 예시 값은 제품 기준이 아닙니다.
        실제 제품 Spec 확인을 선택해야 최종 PASS가 가능합니다.</p>
        <h3>2. 구간과 시험 신호</h3><p>신호 구간: RMS, THD, SPL과 SNR의 신호 레벨에 사용합니다.
        Peak·클리핑은 파일 전체를 검사합니다. 클리핑은 |sample| ≥ 1−1/32768인 표본의 비율이며 아날로그 클리핑을 보장해서 검출하지 않습니다.</p>
        <p>THD: 정상상태 단일 톤을 지정하세요. 기본 주파수 주변 ±2%에서 추정하고 2~5차 왜율을 계산합니다.
        20 Hz 이상·샘플레이트/10 미만이어야 하며, 전체 구간을 약 1초씩 나누고 채널별 가장 큰 THD를 사용합니다. Sweep·음악·광대역 노이즈는 적합하지 않습니다.</p>
        <p>Noise/SNR: 신호와 겹치지 않는 무음 구간이 필요합니다. SNR은 신호 구간 전력에서 무음 전력을 차감한 값과 무음 전력의 비입니다.
        무음이 완전한 디지털 0이면 장비 노이즈를 알 수 없으므로 측정 불가입니다.</p>
        <p>주파수 응답: 동일 샘플레이트의 광대역 기준 녹음과 DUT의 Welch PSD 비율을 1/6 옥타브 대역에서 계산합니다.
        동일한 시간 구간이 두 파일에 적용됩니다. 톤·무음·광대역을 조합했다면 응답 구간을 별도로 지정하세요.
        기준 대비 상대 레벨이며 절대 무향실 응답이나 위상 측정이 아닙니다. 기준의 대역 에너지가 부족하면 측정 불가입니다.</p>
        <p>SPL: 교정 offset = 교정기 음압 − 교정 녹음 RMS(dBFS). 동일 마이크·입력 게인·경로에만 적용합니다.
        한 offset이 모든 채널에 적용되므로 채널별 교정이 필요한 경우 별도로 녹음하세요. A/C 가중치 없이 계산합니다.</p>
        <h3>3. 최종 결과</h3><p><b>PASS</b>: 활성 항목 모두 측정 완료·기준 충족·Spec 확인.<br>
        <b>FAIL</b>: 기준 초과, 미측정, Spec 미확인, 오류 또는 중단. 상세 상태와 사유는 표와 로그에서 확인합니다.<br><b>NG (상세 상태)</b>: 활성 항목 중 기준 초과 있음.<br><b>INCOMPLETE</b>: 측정 불가 항목 또는 활성 항목 없음.<br>
        <b>SPEC REQUIRED</b>: 제품 Spec 미확인. 항목별 NG가 있다면 표에서 확인하세요.<br>
        <b>SKIP</b>: Spec에서 사용하지 않는 항목.</p>
        <h3>결과 추적</h3><p>JSON은 측정값·그래프·Spec·구간·교정값·원본 SHA256·SoX 통계를 포함합니다.
        CSV는 Excel에서 열 수 있는 UTF-8 BOM 형식입니다. 입력이나 Spec을 변경하면 이전 결과의 저장이 해제됩니다.</p>
        <p>합성 샘플의 교정값은 시연용입니다. 실제 스피커 성능 검증에는 실제 측정 파일과 확정된 제품 기준이 필요합니다.</p>''')
        layout.addWidget(help_view,1)
        self.pages.addWidget(page)

    def _capture_page(self):
        # Acquisition is a controller; its old separate production page is not shown.
        from .capture_ui import CapturePanel
        from .audio import one_khz_spec
        p=CapturePanel(self)
        self.capture_panel=p
        p.setParent(self);p.hide()
        def detach(form,widget):
            row=form.takeRow(widget)
            if row.labelItem is not None:
                row.labelItem.widget().hide()
                row.labelItem.widget().deleteLater()
        detach(p.identity_form,p.serial_edit)
        p.serial_edit.setParent(p);p.serial_edit.hide()
        p.noise_check.hide()
        self.input_card,inputs=card()
        inputs.addWidget(label('WAV 분석','section'))
        self.inspection_mode=QComboBox()
        self.inspection_mode.addItem('기본 검사 · 무음 노이즈 측정 안 함',False)
        self.inspection_mode.addItem('무음 노이즈 포함 · 무음 1초 + 1 kHz 검사',True)
        self.inspection_mode.currentIndexChanged.connect(lambda: p.noise_check.setChecked(self.inspection_mode.currentData()))
        self.inspection_mode.currentIndexChanged.connect(self.invalidate)
        inputs.addWidget(self.inspection_mode)
        inputs.addWidget(label('좌우 레벨 차이 · RMS/Peak · 클리핑 · THD 검사 / 입출력 장치는 설정에서 변경','muted',True))
        self.simple_hint=label('1 kHz 출력 → 녹음 → WAV 저장 → 분석·판정 · WAV와 Log 자동 저장','muted',True)
        inputs.addWidget(self.simple_hint)
        self.measurement_layout.insertWidget(0,self.input_card)

        self.settings_layout.removeWidget(self.help_view)
        self.settings_tabs=QTabWidget()
        self.settings_layout.addWidget(self.settings_tabs,1)
        details=QWidget();details_layout=QVBoxLayout(details)
        for title in p.identity_box.findChildren(QLabel):
            if title.text().startswith('제품 식별'):
                title.setText('작업자 · 검사 스테이션')
        details_layout.addWidget(p.audio_box)
        details_layout.addWidget(p.identity_box)
        details_layout.addWidget(p.storage_box)
        details_layout.addStretch()
        details_scroll=QScrollArea();details_scroll.setWidgetResizable(True);details_scroll.setWidget(details)
        self.settings_tabs.addTab(details_scroll,'녹음·저장 설정')

        advanced=QWidget();advanced_layout=QVBoxLayout(advanced)
        self.existing_file_check=QCheckBox('기존 WAV 파일을 선택해서 분석 (자동 녹음 대신)')
        self.existing_file_check.toggled.connect(self.invalidate)
        self.existing_file_check.toggled.connect(lambda checked:self.simple_hint.setText('기존 WAV 파일 분석 모드' if checked else '1 kHz 출력 → 녹음 → WAV 저장 → 분석·판정 · WAV와 Log 자동 저장'))
        self.existing_file_check.toggled.connect(self.file_card.setEnabled)
        advanced_layout.addWidget(self.existing_file_check)
        advanced_layout.addWidget(self.file_card)
        self.file_card.setEnabled(False)
        advanced_layout.addWidget(self.conditions)
        advanced_scroll=QScrollArea();advanced_scroll.setWidgetResizable(True);advanced_scroll.setWidget(advanced)
        self.settings_tabs.addTab(advanced_scroll,'기존 WAV·상세 분석')
        self.condition_scroll.hide()
        history=p.tabs.widget(1);p.tabs.removeTab(1)
        self.settings_tabs.addTab(history,'시험 이력')
        self.settings_tabs.addTab(self.help_view,'측정 안내')
        p.profile_button.setText('선택한 검사 모드의 사용 항목 표시')
        self.spec_editor.layout().insertWidget(2,label('자동 녹음: 사용 체크와 관계없이 좌우차·RMS·Peak·클리핑·THD를 검사합니다. 무음 노이즈는 메인 모드 선택에 따릅니다. 각 항목의 한계값은 아래 표를 적용합니다.','muted',True))
        self.spec_editor.layout().insertWidget(3,p.profile_button)
        self.spec_editor.set_spec(one_khz_spec(self.spec_editor.read_spec(),2,False,False))
        p.started.connect(self.capture_started)
        p.result_ready.connect(self.show_report)
        p.failed.connect(self.analysis_error)
        p.cancelled.connect(self.capture_cancelled)
        p.progress_message.connect(self.status.setText)

    def capture_started(self,worker):
        self.worker=worker
        self.set_running(True)
        self.verdict_label.setText('RECORDING')
        self.verdict_caption.setText('자동 녹음 및 양산 검사 진행 중')
        self.current_run_id=worker.record['run_id']
        self.run_identity.setText('자동 검사 ID: '+self.current_run_id+' · 시작 '+datetime.fromisoformat(worker.record['started_utc']).astimezone(KST).strftime('%Y-%m-%d %H:%M:%S KST'))
        worker.finished.connect(self.analysis_finished)

    def capture_cancelled(self,message):
        self.analysis_error(message)
        self.verdict_label.setText('FAIL')

    def browse_wav(self, edit):
        path,_ = QFileDialog.getOpenFileName(self,'WAV 선택','','WAV (*.wav *.WAV)')
        if path:
            self.existing_file_check.setChecked(True)
            edit.setText(path)

    def browse_sox(self):
        path,_ = QFileDialog.getOpenFileName(self,'SoX 실행 파일 선택','','실행 파일 (*.exe);;모든 파일 (*)')
        if path:
            self.sox_edit.setText(path)

    def settings(self):
        return AnalysisSettings(signal_start=self.signal_start.value(),signal_end=self.signal_end.value() or None,
            noise_start=self.noise_start.value() if self.noise_enabled.isChecked() else None,
            noise_end=self.noise_end.value() if self.noise_enabled.isChecked() else None,
            tone_hz=self.tone_hz.value() if self.tone_enabled.isChecked() else None,
            calibration_db=self.calibration_db.value() if self.calibration_enabled.isChecked() else None,
            response_start=self.response_start.value() if self.response_enabled.isChecked() else None,
            response_end=(self.response_end.value() or None) if self.response_enabled.isChecked() else None)

    def invalidate(self,*args,clear_production=True):
        if self._initializing:
            return
        if clear_production and hasattr(self,'capture_panel'):
            self.capture_panel.test_verdict.setText('READY')
            self.capture_panel.test_verdict.setStyleSheet('color: #8ba3bd;')
        if clear_production:
            self.current_run_id=None
            self.run_identity.setText('검사 ID: —')
        had_report = self.report is not None
        self.report = None
        self.export_json_button.setEnabled(False)
        self.export_csv_button.setEnabled(False)
        self.result_table.setRowCount(0)
        self.verdict_label.setText('READY')
        self.verdict_label.setStyleSheet('color: #8ba3bd;')
        self.verdict_caption.setText('조건 변경됨 · 분석을 실행하세요.')
        self.status.setText('준비됨 · 입력과 Spec을 확인한 뒤 분석하세요.')
        self.reason_label.setText('행을 선택하면 상세 사유를 확인할 수 있습니다.')
        source = Path(self.source_edit.text().strip())
        base = Path(sys.executable).parent if getattr(sys,'frozen',False) else Path(__file__).resolve().parent.parent
        is_demo = source.parent == base/'examples' and source.name in ('demo_composite.wav','demo_ng.wav')
        self.local_badge.setText('●  DEMO · 합성 데이터' if is_demo else '●  LOCAL · SoX')
        for value in self.metric_labels.values():
            value.setText('—')
        if had_report:
            for plot in self.plots.values():
                plot.render(None)

    def start_analysis(self):
        if self.worker is not None:
            return
        if not self.existing_file_check.isChecked():
            self.capture_panel.start_capture()
            return
        try:
            path = self.source_edit.text().strip()
            if not path or not Path(path).is_file():
                raise ValueError('분석할 WAV 파일을 선택하세요.')
            spec = self.spec_editor.read_spec()
            settings = self.settings()
        except (ValueError,OSError) as exc:
            self.analysis_error(str(exc))
            return
        self.invalidate()
        self.verdict_label.setText('ANALYZING')
        self.verdict_caption.setText('SoX 분석 중 · 잠시 기다려 주세요.')
        self.run_identity.setText('기존 WAV 파일 분석 · 자동 녹음 / 양산 이력 추가 없음')
        self.status.setText('분석 중 · 입력 파일과 Spec의 snapshot으로 계산합니다.')
        self.set_running(True)
        self.worker = AnalysisWorker(self.sox_edit.text(),path,settings,spec,self.reference_edit.text().strip() or None)
        self.worker.succeeded.connect(self.show_report)
        self.worker.failed.connect(self.analysis_error)
        self.worker.finished.connect(self.analysis_finished)
        self.worker.start()

    def set_running(self,running):
        self.run_button.setEnabled(not running)
        for w in (self.input_card,self.conditions,self.spec_editor,self.sox_card,self.existing_file_check):
            w.setEnabled(not running)
        self.file_card.setEnabled(not running and self.existing_file_check.isChecked())
        self.capture_panel.set_busy(running)
        self.progress.setVisible(running)
        self.progress.setRange(0,0 if running else 1)

    def analysis_finished(self):
        worker = self.worker
        self.worker = None
        self.set_running(False)
        self.run_button.setFocus()
        if worker:
            worker.deleteLater()

    def analysis_error(self,message):
        self.invalidate(clear_production=False)
        self.report = None
        self.export_json_button.setEnabled(False)
        self.export_csv_button.setEnabled(False)
        self.verdict_label.setText('FAIL')
        self.verdict_label.setStyleSheet('color: #ff8995;')
        self.verdict_caption.setText(message)
        self.status.setText('분석 실패 · '+message)

    def show_report(self,report):
        if report.get('capture') or report.get('production'):
            from .production import ProductionStore
            production=report.get('production',{})
            run_id=production.get('run_id')
            if self.current_run_id is not None and run_id!=self.current_run_id:
                # A queued result from an earlier inspection cannot replace this run.
                return
            try:
                database=Path(production['database'])
                if database.name!='production.sqlite3' or not database.is_file():
                    raise ValueError('현재 검사 로그 데이터베이스를 찾을 수 없습니다.')
                report=ProductionStore(database.parent).verified_report(run_id)
            except Exception as exc:
                self.analysis_error('최종 결과 확인 실패 · '+str(exc))
                self.current_run_id=run_id
                self.run_identity.setText('자동 검사 ID: '+str(run_id))
                return
            self.current_run_id=run_id
            self.run_identity.setText('자동 검사 ID: '+run_id+' · 완료 '+datetime.fromisoformat(report['production']['ended_utc']).astimezone(KST).strftime('%Y-%m-%d %H:%M:%S KST'))
        else:
            self.run_identity.setText('기존 WAV 파일 분석 · 자동 녹음 / 양산 이력 추가 없음')
        if report.get('capture'):
            self.source_edit.blockSignals(True)
            self.source_edit.setText(report['source']['path'])
            self.source_edit.blockSignals(False)
        self.report = report
        verdict = report['verdict']
        self.verdict_label.setText('PASS' if verdict=='PASS' else 'FAIL')
        self.verdict_label.setStyleSheet('color: '+('#73e5c4' if verdict=='PASS' else '#ff8995')+';')
        counts = {s:sum(r['status']==s for r in report['rows']) for s in ('PASS','NG','UNAVAILABLE','SKIP')}
        prefix = '제품 Spec 확인 필요 · ' if verdict == 'SPEC REQUIRED' else ''
        self.verdict_caption.setText(prefix+f"통과 {counts['PASS']}  ·  기준 초과 {counts['NG']}  ·  측정 불가 {counts['UNAVAILABLE']} · 상세 상태: {verdict}")
        for key,value_label in self.metric_labels.items():
            value = report['metrics'].get(key)
            vals = value if isinstance(value,list) else [value]
            vals = [v for v in vals if v is not None]
            chosen = (min(vals) if key in ('rms_dbfs','snr_db') else max(vals)) if vals else None
            value_label.setText('—' if chosen is None else f'{chosen:.2f}')
        self.result_table.setRowCount(len(report['rows']))
        for i,row in enumerate(report['rows']):
            vals = row['value'] if isinstance(row['value'],list) else [row['value']]
            text = ' / '.join('—' if v is None else f'{v:.3f}' for v in vals)
            if row['key']=='response_db':
                text = '주파수별 값 보기'
            low = '−∞' if row['lower'] is None else f"{row['lower']:g}"
            high = '+∞' if row['upper'] is None else f"{row['upper']:g}"
            bounds = '주파수별 기준' if row['key']=='response_db' else f'{low} ~ {high}'
            for col,value in enumerate((row['name'],text,bounds,row['status'],row['reason'])):
                cell = QTableWidgetItem(value)
                cell.setToolTip(value)
                if col == 3:
                    cell.setForeground(QColor(STATUS_COLORS[row['status']]))
                self.result_table.setItem(i,col,cell)
            self.result_table.setRowHeight(i,32)
            self.result_table.setRowHidden(i,row['status']=='SKIP' and bool(report.get('capture')))
        for plot in self.plots.values():
            plot.render(report)
        self.export_json_button.setEnabled(True)
        self.export_csv_button.setEnabled(True)
        source = report['source']
        self.status.setText(f"분석 완료 · {Path(source['path']).name} · {source['sample_rate']:,} Hz / {source['bits']} bit / {source['channels']} ch / {source['duration_seconds']:.3f} s · {report['sox']['version']}")

    def show_reason(self):
        if self.report is None:
            return
        index = self.result_table.currentRow()
        if index < 0 or index >= len(self.report['rows']):
            return
        row = self.report['rows'][index]
        text = row['reason']
        if row['key']=='response_db' and isinstance(row['value'],list):
            text += ' | '+' · '.join(f"{p['hz']:g}Hz: {'—' if v is None else f'{v:.2f}dB'}" for p,v in zip(self.report['spec']['response_points'],row['value']))
        self.reason_label.setText(text)

    def save_result(self,kind):
        if self.report is None:
            return
        path,_ = QFileDialog.getSaveFileName(self,'결과 저장',f'speaker-result.{kind}',f'{kind.upper()} (*.{kind})')
        if path:
            try:
                (export_json if kind=='json' else export_csv)(self.report,path)
                self.status.setText('결과 저장 완료 · '+path)
            except (ValueError,OSError) as exc:
                QMessageBox.warning(self,'저장 오류',str(exc))

    def load_demo(self):
        self.existing_file_check.setChecked(True)
        base = Path(sys.executable).parent if getattr(sys,'frozen',False) else Path(__file__).resolve().parent.parent
        source = base/'examples'/'demo_composite.wav'
        if not source.is_file():
            self.status.setText('샘플 파일이 없습니다. python scripts/generate_demo.py로 생성하세요.')
            return
        self.spec_editor.set_spec(default_spec())
        self.source_edit.setText(str(source))
        self.reference_edit.setText(str(base/'examples'/'demo_reference.wav'))
        self.signal_start.setValue(0)
        self.signal_end.setValue(1)
        self.tone_enabled.setChecked(True)
        self.tone_hz.setValue(1000)
        self.noise_enabled.setChecked(True)
        self.noise_start.setValue(1)
        self.noise_end.setValue(2)
        self.response_enabled.setChecked(True)
        self.response_start.setValue(2)
        self.response_end.setValue(4)
        self.calibration_enabled.setChecked(True)
        self.calibration_db.setValue(110)
        self.local_badge.setText('●  DEMO · 합성 데이터')
        self.status.setText('시연용 합성 WAV · 교정 offset 110 dB는 실제 장비 교정값이 아닙니다.')

    def closeEvent(self,event):
        self.capture_panel.stop_all()
        if self.worker is not None or self.capture_panel.input_monitor is not None:
            self.status.setText('오디오 작업을 중지하고 있습니다. 끝난 뒤 창을 닫아 주세요.')
            event.ignore()
        else:
            event.accept()


def main():
    app = QApplication(sys.argv)
    app.setApplicationName('SpeakerCheck')
    window = MainWindow()
    window.show()
    sys.exit(app.exec())
