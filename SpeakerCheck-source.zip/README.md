# SpeakerCheck 0.3.0

**WAV 분석 → 분석 실행** 한 번으로 다음 순서가 자동 진행됩니다.

**PC 1 kHz 출력 → 디바이스 입력 녹음 → WAV 생성 → SoX 분석 → PASS/NG → Log 저장**

별도의 자동 녹음·양산 메뉴를 없앴습니다. 메인은 출력/입력 장치, 제품번호(선택), 분석 실행, 판정 결과만 표시합니다. 그래프는 필요할 때 **그래프 보기**로 펼칩니다.

## Windows 실행

1. ZIP을 **새 폴더에 전체 압축 해제**합니다. `launch.py`만 복사하면 실행되지 않습니다.
2. Python 3.11 이상(64 bit, Python Launcher 포함)을 설치합니다.
3. `setup.bat` → `start.bat` 순서로 실행합니다. 최초 의존성 설치에는 인터넷이 필요합니다.
4. **설정**에서 설치한 `sox.exe` 경로를 지정합니다. SoX 배포본 전체를 `tools/sox/`에 놓아도 됩니다.
5. **WAV 분석**에서 장치 새로고침 후 PC 스피커 출력과 디바이스 PC 입력을 선택합니다.
6. **Spec 관리**에서 실제 제품 한계값과 사용 항목을 설정·확인합니다. 초기 Spec은 예시이며 확인 전에는 최종 PASS를 표시하지 않습니다.
7. **분석 실행**을 누릅니다. 이후 재생·녹음·파일 생성·분석·판정·로그 저장은 자동입니다.

디바이스가 Windows 오디오 녹음 장치로 인식되어야 합니다. 독자 UART/USB packet 입력은 지원하지 않습니다. SoX는 별도 설치해야 합니다: https://sourceforge.net/projects/sox/

압축을 풀면 같은 위치에 아래 구조가 있어야 합니다(0.3.0 ZIP은 중간 `SpeakerCheck/` 폴더 없이 파일을 담았습니다).

```text
launch.py
start.bat
setup.bat
requirements.txt
speakercheck/
  __init__.py
  ui.py
  ...
```

`No module named 'speakercheck'`가 발생하면 위 폴더가 모두 있는지 확인하세요. 새 실행기는 앱 경로를 직접 등록하고, 폴더가 없으면 전체 압축 해제 안내를 표시합니다. 시작 오류 상세는 `%TEMP%/SpeakerCheck-startup-error.log`에 저장합니다.

## 기본 검사

- 1 kHz 출력 Peak **-24 dBFS**, 48 kHz, 입력 1채널/출력 2채널.
- 안정화 1초 후 신호 3초 녹음. 앱이 시작한 톤은 녹음 후 종료됩니다.
- 제품번호를 입력하면 제품별로 추적합니다. 비워 두면 `TEST-...` 시험번호를 자동 발급하고 로그에 `generated_test_id`로 구분합니다.
- 바코드 Enter로도 분석 실행을 시작할 수 있습니다.
- 상단 **오디오 중지 / Esc**로 중단합니다. 최종 DB commit을 시작한 이후에는 완료된 측정의 저장을 마칩니다.
- 디바이스 입력은 PC 출력으로 다시 보내지 않습니다. 스피커→디바이스→PC 경로는 실제 외부 연결로 구성하세요.

PC 시스템 볼륨, 입력 게인, AGC/음향 효과는 시험 조건에 맞게 고정하세요. 장치 지연이 크면 설정에서 안정화 시간을 늘리세요.

## 설정으로 옮긴 항목

| 위치 | 항목 |
|---|---|
| 설정 상단 | sox.exe 경로 |
| 녹음·저장 설정 | 샘플레이트, 채널, 1 kHz 레벨, 녹음/안정화 시간, 무음 추가, SPL 교정, 작업자/스테이션, 저장 폴더 |
| 기존 WAV·상세 분석 | 기존 파일 분석 모드, WAV/기준 WAV 선택, 신호·무음·응답 구간 |
| 시험 이력 | 제품번호 검색, 최신 1,000건, 전체 검색 결과 CSV, 선택 보고서 JSON |
| 측정 안내 | 측정 항목과 필수 조건 설명 |

기존 WAV를 분석하려면 설정의 **기존 WAV 파일을 선택해서 분석**을 켜고 파일을 지정한 뒤 메인의 분석 실행을 누릅니다. 이 모드에서는 새 녹음 대신 선택 파일을 분석합니다. 다시 자동 녹음하려면 해당 선택을 끄세요.

## Spec과 판정

RMS/Peak/클리핑/THD/Noise/SNR/좌우차/교정 SPL/기준 대비 주파수 응답을 지원합니다. 기본은 1 kHz 검사에 맞춘 사용 항목이며 나머지 기능은 Spec과 설정에서 선택할 수 있습니다. **1 kHz 검사 항목 맞춤**은 한계값을 유지하고 무음/채널/교정 조건에 맞게 활성 항목을 조정하며 Spec 확인을 해제합니다.

- **PASS**: 활성 항목 모두 측정 완료·한계 이내·Spec 확인 완료·입력 유효성 확인·로그 commit 완료.
- **NG**: 활성 항목 중 기준 초과 있음.
- **INCOMPLETE**: 필수 항목 미측정, 활성 항목 없음, 입력 톤 단절 등.
- **SPEC REQUIRED**: 제품 Spec 미확인. 항목별 NG는 표에 표시됩니다.
- **ERROR / ABORTED**: 장치/저장 오류 또는 중단. 합격 아님.
- **SKIP**: Spec에서 사용하지 않는 항목.

상하한은 경계값을 포함합니다. 다채널은 모든 채널이 기준을 만족해야 합니다. Spec을 수정하면 확인이 해제됩니다.

THD는 정상상태 단일 톤의 주파수를 ±2% 범위에서 추정하고, 전체 신호를 약1초 window로 나눠 계산한 2~5차 THD의 채널별 최댓값을 사용합니다. 자동 녹음은 전체 신호의 약100ms FFT/20ms RMS를 확인하여 뒤쪽 신호 단절이 평균값에 숨겨지는 것을 막습니다.

무음 옵션은 톤을 잠시 끄고 안정화 후 무음 1초를 추가 녹음해 Noise/SNR을 측정합니다. SNR은 `10log10((P_signal-P_noise)/P_noise)`이며 전체 대역 무가중입니다. 디지털 0 무음은 노이즈를 알 수 없어 측정 불가입니다.

SPL은 동일 체인의 교정 offset을 적용해야 합니다: `SPL=RMS(dBFS)+offset`. 알려진 94dB SPL 교정 녹음이 -20dBFS면 offset=114dB입니다. 모든 채널에 같은 offset이 적용됩니다. A/C 가중치는 지원하지 않습니다.

고정1kHz로 전체 주파수 응답을 측정할 수는 없습니다. 응답 검사는 기존 WAV 모드에서 광대역 기준 녹음과 DUT 녹음의 Welch PSD 비율을 1/6 octave 대역으로 비교합니다. 같은 sample rate/시험 조건/시간 구간이 필요하며 절대 무향실 응답·위상·sweep deconvolution은 지원하지 않습니다.

## 자동 Log

기본 위치: Windows 사용자별 앱 데이터의 `SpeakerCheck/results`. 설정에서 변경할 수 있습니다.

```text
results/
  production.sqlite3
  YYYY-MM-DD/                 # KST 날짜
    HHMMSS-<run_id>.wav
    events.jsonl              # UTC 시각
```

매 시험은 고유 Run ID를 사용합니다. 시작 전 RUNNING을 기록하고 최종 SQLite commit 후 결과를 표시합니다. 제품/시험번호, 작업자, 스테이션, 시각, 소프트웨어/SoX 버전, 입출력 장치, 설정/Spec/교정 snapshot, 원본 SHA256, 측정값, 판정과 사유, 상세 report JSON을 기록합니다. 비정상 종료 후 RUNNING은 합격이 아닙니다. `events.jsonl`의 pending_state는 최종 판정이 아니며 집계에는 SQLite state를 사용하세요.

CSV는 Excel용 UTF-8 BOM이며 측정값을 개별 컬럼으로 제공합니다. 전체 그래프/Spec snapshot은 SQLite 및 JSON 보고서에 보관됩니다. 동일 제품 재검사도 기존 이력을 덮어쓰지 않습니다. 자동 로그는 새 녹음 경로에 적용되며 기존 WAV의 별도 분석은 생산 이력을 추가하지 않습니다.

## 검증과 범위

Linux에서 합성 오디오 backend + 실제 SoX/SQLite/Qt offscreen으로 시험했습니다. Windows 오디오 장치/실제 스피커 체인 및 Windows EXE 빌드는 미검증입니다. 물리 장치 연결, 교정/지연/오디오 효과, 전원/디스크/USB 재연결 장애와 로그 백업을 현장에서 검증해야 합니다. 정해진 시간 녹음 후 판정하며 무기한 실시간 갱신이나 PLC 트리거는 포함하지 않습니다.

Windows EXE 빌드: `build_windows.bat`. 결과 `dist/SpeakerCheck` 폴더 전체를 배포하세요. SoX 바이너리는 포함하지 않으며 재배포 시 라이선스 조건을 확인하세요.

```bash
python -m pip install -r requirements-dev.txt
# SoX를 PATH에 넣거나 SOX_BINARY 전체 경로 지정
python -m pytest tests -q
python launch.py
```

Linux CI: `QT_QPA_PLATFORM=offscreen`. 시연: `scripts/preview_capture.py`(합성 입력 + 실제 SoX/SQLite). 합성 WAV 샘플은 `examples/`, 설계/검증 기록은 `docs/`에 있습니다.
