import numpy as np
import pytest
from speakercheck.spec import default_spec


def test_two_modes_keep_required_metrics_and_confirmation():
    from speakercheck.spec import inspection_spec
    source=default_spec();source['confirmed']=True
    for rule in source['metrics'].values(): rule['enabled']=False
    for noise in (False,True):
        profile=inspection_spec(source,noise)
        enabled={k for k,v in profile['metrics'].items() if v['enabled']}
        required={'balance_db','rms_dbfs','peak_dbfs','clip_percent','thd_percent'}
        assert enabled==required|({'noise_dbfs'} if noise else set())
        assert profile['confirmed']
        assert profile['metrics']['balance_db']['upper']==1.5
    assert not source['metrics']['balance_db']['enabled']


def test_comparison_preserves_gain_balance_and_harmonics():
    from speakercheck.comparison import tone_comparison
    fs=48000;t=np.arange(fs)/fs
    x=.03*np.sin(2*np.pi*1000*t+.7)+.003*np.sin(2*np.pi*2000*t)
    data=tone_comparison(np.column_stack([x,x*.5]),fs,1000,-24)
    assert data['time_ms'][-1]<=5
    assert len(data['input'])==2
    assert np.max(np.abs(data['input'][0]))==pytest.approx(np.max(np.abs(data['input'][1]))*2)
    assert np.max(np.abs(data['original']))==pytest.approx(10**(-24/20),rel=.01)
    assert data['provenance']['gain_normalized'] is False
    assert data['provenance']['reference_kind']=='generated_digital_sine'
    spectrum=data['spectrum'];h=np.asarray(spectrum['hz'])
    idx=np.argmin(abs(h-2000))
    assert spectrum['input_db'][0][idx]>spectrum['original_db'][idx]+40
    assert np.all(np.isfinite(spectrum['input_db']))


def test_comparison_silence_is_finite():
    from speakercheck.comparison import tone_comparison
    data=tone_comparison(np.zeros((4800,2)),48000,1000,-24)
    assert np.all(np.isfinite(data['original']))
    assert np.all(np.isfinite(data['spectrum']['input_db']))
