@echo off
setlocal
cd /d "%~dp0"
set "SCX_BUILD_RC=1"
set "SCX_BUILD_LOG=%~dp0build.log"
> "%SCX_BUILD_LOG%" echo SpeakerCheck Windows x64 single EXE build
if errorlevel 1 goto LogFailed
call "%~dp0setup.bat" --no-pause
if errorlevel 1 goto SetupFailed
echo Installing the build tool...
"%~dp0.venv\Scripts\python.exe" -m pip install "pyinstaller==6.16.0" >> "%SCX_BUILD_LOG%" 2>&1
if errorlevel 1 goto Failed
echo Building a single EXE with DLLs, libraries, and SoX inside. A dialog will ask for your existing sox.exe.
echo Build progress is recorded in "%SCX_BUILD_LOG%"
if "%~1"=="" goto ChooseSox
"%~dp0.venv\Scripts\python.exe" "%~dp0scripts\build_portable.py" --sox "%~1" >> "%SCX_BUILD_LOG%" 2>&1
if errorlevel 1 goto Failed
goto Success
:ChooseSox
"%~dp0.venv\Scripts\python.exe" "%~dp0scripts\build_portable.py" >> "%SCX_BUILD_LOG%" 2>&1
if errorlevel 1 goto Failed
:Success
echo Build and EXE self-test complete.
echo Verified EXE and ZIP: "%~dp0output"
echo Build EXE: "%~dp0dist\SpeakerCheck.exe"
echo Distribute the verified EXE under output. No sibling DLL or tools folders are required.
echo Target PCs do not need Python, pip, setup.bat, or a separate SoX installation.
set "SCX_BUILD_RC=0"
goto Finish
:SetupFailed
echo Setup failed. See "%~dp0setup.log".
goto Finish
:LogFailed
echo Cannot write build.log. Extract the ZIP to a writable folder.
goto Finish
:Failed
echo Build failed. Details follow:
type "%SCX_BUILD_LOG%"
echo Log saved to "%SCX_BUILD_LOG%"
:Finish
pause
exit /b %SCX_BUILD_RC%
