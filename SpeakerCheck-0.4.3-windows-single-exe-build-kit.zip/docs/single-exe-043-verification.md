# 0.4.3 단일 EXE 로컬 빌드

- PyInstaller onefile에 Python/Qt/수치/PortAudio 의존성과 선택한 SoX/DLL, MSVC 런타임 및 라이선스를 포함합니다.
- onefile의 sys._MEIPASS를 자원 기준으로 사용하며 SoX와 데모 파일은 내부 추출 위치에서 찾습니다. 내부 SoX 우선과 기존 onedir 대체 경로 회귀 테스트 RED→GREEN.
- 원본 SoX가 이전 dist에 있어도 PyInstaller 전에 임시 staging으로 복사합니다. 소스 프로젝트 재귀 복사는 하지 않습니다.
- EXE만 한글 이름의 빈 폴더에 복사, Python/외부 SoX를 PATH에서 제외한 뒤 offscreen/일반 Windows GUI 자체 검증을 수행합니다. frozen/x64/Qt/라이선스 메타데이터/내장 SoX/합성 1kHz PASS·혼합톤 FAIL/SQLite를 검증합니다.
- 검증 통과 후에만 output의 최종 EXE를 생성합니다. 배포 ZIP에도 SpeakerCheck.exe 한 파일만 담습니다.
- WAV/SQLite 로그는 사용자 AppData 결과 폴더를 유지하며 onefile 임시 추출 폴더에 저장하지 않습니다.
- Linux 소스 테스트 92 passed, 네이티브 CMD용 2개는 skipped. 독립 코드 검토 Critical/Important 없음.
- 네이티브 Windows 단일 EXE 빌드 및 물리 오디오 검증은 사용자의 로컬 환경에서 수행합니다. 원격 자동 빌드는 실행하지 않았습니다.
