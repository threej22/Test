"""Build on Windows x64; end users run the resulting EXE without Python/setup."""
from pathlib import Path
import argparse
import hashlib
import importlib.metadata
import json
import os
import shutil
import struct
import subprocess
import sys
import tempfile
import zipfile


def build(sox_path):
    if sys.platform!='win32' or struct.calcsize('P')!=8:
        raise RuntimeError('Build requires 64-bit Python running on Windows.')
    root=Path(__file__).resolve().parents[1]
    sys.path.insert(0,str(root))
    from speakercheck import __version__
    out=root/'output';out.mkdir(exist_ok=True)
    subprocess.run([sys.executable,'-m','PyInstaller','--noconfirm','--clean','--onedir','--windowed',
        '--contents-directory','.','--name','SpeakerCheck','--hidden-import','sounddevice',
        '--collect-all','_sounddevice_data','--exclude-module','tkinter','--exclude-module','PyQt5',
        '--exclude-module','PyQt6','--add-data',str(root/'examples')+os.pathsep+'examples',str(root/'launch.py')],cwd=root,check=True)
    payload=root/'dist'/'SpeakerCheck'
    sox=Path(sox_path).resolve(strict=True)
    subprocess.run([str(sox),'--version'],check=True)
    if sox.name.lower()!='sox.exe':raise ValueError('Select actual sox.exe, not a package-manager shim.')
    shutil.copytree(sox.parent,payload/'tools'/'sox',dirs_exist_ok=True)
    system=Path(os.environ['SystemRoot'])/'System32'
    for name in ('msvcp140.dll','msvcp140_1.dll','msvcp140_2.dll','vcruntime140.dll','vcruntime140_1.dll','concrt140.dll'):
        if (system/name).is_file() and not (payload/name).is_file():shutil.copy2(system/name,payload/name)
    licenses=payload/'licenses';licenses.mkdir(exist_ok=True)
    python_license=Path(sys.base_prefix)/'LICENSE.txt'
    if python_license.is_file():shutil.copy2(python_license,licenses/'Python-LICENSE.txt')
    versions={}
    for name in ('PySide6','numpy','scipy','matplotlib','sounddevice','pyinstaller'):
        dist=importlib.metadata.distribution(name);versions[name]=dist.version
        for file in dist.files or []:
            if '.dist-info' in str(file) and any(x in str(file).lower() for x in ('license','copying','notice')):
                source=Path(dist.locate_file(file))
                if source.is_file():
                    target=licenses/name/str(file).split('.dist-info/',1)[-1]
                    target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
    (licenses/'components.json').write_text(json.dumps(versions,indent=2),encoding='utf-8')
    (licenses/'SoX-source.txt').write_text('SoX 14.4.2 source and license:\nhttps://sourceforge.net/projects/sox/files/sox/14.4.2/\nhttps://github.com/chirlu/sox\nSoX executables, libraries and original license files are included in tools/sox.\n',encoding='utf-8')
    (payload/'사용방법.txt').write_text('SpeakerCheck '+__version__+' Windows x64 portable\n\n1. ZIP 전체를 압축 해제합니다.\n2. SpeakerCheck 폴더의 SpeakerCheck.exe를 실행합니다.\nPython / setup.bat / pip / SoX 별도 설치가 필요 없습니다.\nEXE 옆 DLL과 tools 폴더도 함께 보관하세요.\nWindows 10/11 64비트 대상. 오디오 장치 드라이버와 마이크 접근 권한은 필요합니다.\n설정에서 스피커와 디바이스 입력을 확인하고 실제 제품 Spec을 설정하세요.\nWAV와 로그 위치는 설정에서 확인할 수 있습니다.\n시작 오류 로그: %TEMP%/SpeakerCheck-startup-error.log\n실제 제품의 음향 시험/교정은 별도로 수행해야 합니다.\n',encoding='utf-8-sig')
    zip_path=out/f'SpeakerCheck-{__version__}-windows-x64-portable.zip'
    with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(payload.rglob('*')):
            if path.is_file():archive.write(path,Path('SpeakerCheck')/path.relative_to(payload))
    with zipfile.ZipFile(zip_path) as archive:
        if archive.testzip():raise RuntimeError('Portable ZIP validation failed.')
        with tempfile.TemporaryDirectory(prefix='SpeakerCheck-clean-') as clean:
            clean=Path(clean);extracted=clean/'압축해제 실행 확인';archive.extractall(extracted)
            exe=extracted/'SpeakerCheck'/'SpeakerCheck.exe';diagnostic=clean/'diagnostic.json'
            env=os.environ.copy()
            for key in ('PYTHONPATH','PYTHONHOME','SOX_BINARY','QT_PLUGIN_PATH','QT_QPA_PLATFORM_PLUGIN_PATH'):
                env.pop(key,None)
            env['PATH']=str(system)+os.pathsep+str(system.parent)
            env['QT_QPA_PLATFORM']='offscreen'
            proc=subprocess.run([str(exe),'--self-test',str(diagnostic)],cwd=clean,env=env,timeout=120)
            result=json.loads(diagnostic.read_text('utf-8')) if diagnostic.exists() else {}
            if proc.returncode or result.get('status')!='ok' or not result.get('frozen') or result.get('pointer_bits')!=64:
                raise RuntimeError('Frozen EXE smoke test failed: '+json.dumps(result,ensure_ascii=False))
            if str(exe.parent).lower() not in result['sox_path'].lower():raise RuntimeError('Smoke test used external SoX.')
            shutil.copy2(diagnostic,out/'portable-diagnostic.json')
    digest=hashlib.file_digest(zip_path.open('rb'),'sha256').hexdigest()
    (out/(zip_path.name+'.sha256')).write_text(digest+'  '+zip_path.name+'\n',encoding='ascii')
    print(json.dumps({'portable':str(zip_path),'sha256':digest,'size':zip_path.stat().st_size}))


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--sox',required=True)
    build(parser.parse_args().sox)
