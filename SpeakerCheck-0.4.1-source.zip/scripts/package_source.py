"""Create a flat, complete source ZIP; exclude local caches and captured data."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile
from speakercheck import __version__

root=Path(__file__).resolve().parents[1]
out=root/'output';out.mkdir(exist_ok=True)
target=out/f'SpeakerCheck-{__version__}-source.zip'
excluded={'output','work','.venv','.pytest_cache','__pycache__','.git','build','dist'}
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
    for path in sorted(root.rglob('*')):
        relative=path.relative_to(root)
        if not path.is_file() or any(part in excluded for part in relative.parts):continue
        payload=path.read_bytes()
        if path.suffix=='.bat': payload=payload.replace(b'\r\n',b'\n').replace(b'\n',b'\r\n')
        z.writestr(str(relative),payload)
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None
    assert {'launch.py','speakercheck/ui.py','speakercheck/comparison.py','setup.bat','start.bat'}<=set(z.namelist())
shutil.copy2(target,out/'SpeakerCheck-source.zip')
data=target.read_bytes()
metadata={'path':str(target),'size':len(data),'sha256':hashlib.sha256(data).hexdigest(),
          'git_blob_sha':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()}
(out/f'package-{__version__}-meta.json').write_text(json.dumps(metadata,indent=2))
print(json.dumps(metadata))
