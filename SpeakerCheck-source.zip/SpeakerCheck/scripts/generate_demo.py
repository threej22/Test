"""Reproducible synthetic data, never a physical speaker qualification."""
from pathlib import Path
import json
import sys
import numpy as np
from scipy.io import wavfile
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from speakercheck.spec import default_spec


def generate(directory):
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    fs = 48000
    rng = np.random.default_rng(20261023)
    t = np.arange(fs)/fs
    tone = .15*np.sin(2*np.pi*1000*t) + .0015*np.sin(2*np.pi*2000*t)
    noise = rng.normal(0,.0002,fs)
    broadband = rng.normal(0,.055,fs*2)
    base = np.r_[tone,noise,broadband]
    dut = np.column_stack([base,base*.98])
    reference = np.column_stack([base,base])
    bad = dut.copy()
    bad[:fs,1] *= .5
    bad[:fs,0] += .025*np.sin(2*np.pi*2000*t)
    for name,data in [('demo_composite',dut),('demo_reference',reference),('demo_ng',bad)]:
        wavfile.write(directory/f'{name}.wav',fs,np.round(data*32767).astype(np.int16))
    spec = default_spec()
    spec['name'] = 'EXAMPLE · 100Hz–10kHz demo / 제품 기준으로 수정'
    (directory/'example_spec.json').write_text(json.dumps(spec,ensure_ascii=False,indent=2),encoding='utf-8')
    (directory/'README.txt').write_text('합성 데이터입니다. 실제 스피커 검증 결과가 아닙니다.\n0~1초: 1kHz 톤 + 1% 2차 harmonic\n1~2초: 무음 노이즈\n2~4초: 광대역 노이즈\n신호 0~1 / 무음 1~2 / 응답 2~4 / 톤 1000Hz\n시연용 SPL offset 110dB (실제 장비 교정값 아님)\ndemo_ng: 좌우차와 THD 초과 시연용\n',encoding='utf-8')

if __name__ == '__main__':
    generate(Path(__file__).resolve().parents[1]/'examples')
