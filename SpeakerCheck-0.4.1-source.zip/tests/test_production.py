import json
import sqlite3
import csv
import pytest
from speakercheck.production import ProductionStore


def test_serial_required_and_run_is_recorded_before_test(tmp_path):
    store=ProductionStore(tmp_path)
    with pytest.raises(ValueError): store.begin('', 'op', 'station', {})
    run=store.begin('SN001','kim','line1',{'level_dbfs':-24})
    assert store.history()[0]['state']=='RUNNING'
    assert store.history()[0]['run_id']==run['run_id']
    assert store.history()[0]['serial']=='SN001'


def test_exact_snapshot_persistence_and_csv(tmp_path):
    store=ProductionStore(tmp_path)
    run=store.begin('=SERIAL,001','op','line1',{'input':'USB Audio'})
    report={'verdict':'PASS','spec':{'name':'실제 기준','lower':-23.01029995,'confirmed':True},'metrics':{'rms_dbfs':[-20.]},'rows':[{'status':'PASS'}],'capture':{'valid_1khz_return':True}}
    saved=store.finish(run['run_id'],'PASS',report)
    assert saved['production']['serial']=='=SERIAL,001'
    row=store.history()[0]
    assert row['state']=='PASS'
    assert json.loads(row['report_json'])['spec']['lower']==-23.01029995
    path=tmp_path/'history.csv'
    store.export_csv(path)
    text=path.read_text('utf-8-sig')
    assert "'=SERIAL,001" in text
    assert 'PASS' in text
    from io import StringIO
    rows=list(csv.DictReader(StringIO(text)))
    assert rows[0]['rms_dbfs']=='[-20.0]'
    assert rows[0]['final_result']=='PASS'
    assert saved['final_result']=='PASS'
    assert store.get_report(run['run_id'])['verdict']=='PASS'


def test_cancel_and_error_logged_and_terminal_state_not_overwritten(tmp_path):
    store=ProductionStore(tmp_path)
    for state in ['ABORTED','ERROR']:
        r=store.begin('SN','op','station',{})
        store.finish(r['run_id'],state,None,'장치 연결 끊김')
        with pytest.raises(ValueError): store.finish(r['run_id'],'PASS',{'verdict':'PASS'})
    assert {r['state'] for r in store.history()}=={'ABORTED','ERROR'}


def test_final_log_commit_failure_never_returns_pass(tmp_path,monkeypatch):
    store=ProductionStore(tmp_path)
    run=store.begin('SN','op','station',{})
    def broken(): raise sqlite3.OperationalError('disk full')
    monkeypatch.setattr(store,'_connect',broken)
    with pytest.raises(sqlite3.Error): store.finish(run['run_id'],'PASS',{'verdict':'PASS'})
    fresh=ProductionStore(tmp_path)
    assert fresh.history()[0]['state']=='RUNNING'


def test_export_cannot_overwrite_authoritative_database(tmp_path):
    store=ProductionStore(tmp_path)
    r=store.begin('SN','op','line',{})
    before=store.path.read_bytes()
    with pytest.raises(ValueError): store.export_csv(store.path)
    assert store.path.read_bytes()==before
    assert store.history()[0]['state']=='RUNNING'


def test_history_csv_does_not_call_inconsistent_snapshot_pass(tmp_path):
    store=ProductionStore(tmp_path);run=store.begin('TEST','','',{})
    report={'verdict':'PASS','spec':{'confirmed':True},'rows':[{'status':'PASS'}],
            'capture':{'valid_1khz_return':False}}
    store.finish(run['run_id'],'PASS',report)
    with pytest.raises(ValueError):store.verified_report(run['run_id'])
    target=tmp_path/'history.csv';store.export_csv(target)
    with target.open(encoding='utf-8-sig') as f:row=next(csv.DictReader(f))
    assert row['state']=='PASS' and row['final_result']=='FAIL'
