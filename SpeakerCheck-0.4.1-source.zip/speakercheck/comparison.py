"""Display-only original digital tone versus returned audio; never changes metrics."""
import numpy as np
from scipy.signal import periodogram


def tone_comparison(samples, rate, frequency, level_dbfs):
    samples=np.asarray(samples,dtype=float)
    if samples.ndim==1: samples=samples[:,None]
    width=min(len(samples),max(2,round(rate*5/frequency)))
    start=max(0,(len(samples)-width)//2)
    segment=samples[start:start+width]
    t=np.arange(width)/rate
    basis=np.column_stack([np.sin(2*np.pi*frequency*t),np.cos(2*np.pi*frequency*t),np.ones(width)])
    coeff=np.linalg.lstsq(basis,segment[:,0],rcond=None)[0]
    phase=float(np.arctan2(coeff[1],coeff[0]))
    amplitude=10**(level_dbfs/20)
    original=amplitude*np.sin(2*np.pi*frequency*t+phase)
    # Same sample count, window, scaling and frequency bins for all curves.
    n=min(len(samples),max(256,round(rate*.1)))
    center=max(0,(len(samples)-n)//2)
    ref=amplitude*np.sin(2*np.pi*frequency*np.arange(n)/rate)
    hz,ref_power=periodogram(ref,rate,window='hann',scaling='spectrum')
    _,power=periodogram(samples[center:center+n],rate,window='hann',scaling='spectrum',axis=0)
    db=lambda p:(10*np.log10(np.maximum(p,1e-18))).tolist()
    return {'time_ms':(t*1000).tolist(),'original':original.tolist(),'input':segment.T.tolist(),
            'window_start_seconds':start/rate,
            'provenance':{'reference_kind':'generated_digital_sine','frequency_hz':frequency,
                'level_dbfs_peak':level_dbfs,'phase_alignment':'fit to input CH1, display only; not latency',
                'phase_radians':phase,'gain_normalized':False,'physical_output_measured':False},
            'spectrum':{'hz':hz.tolist(),'original_db':db(ref_power),'input_db':db(power.T)}}
