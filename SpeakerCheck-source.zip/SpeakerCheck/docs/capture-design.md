# 자동 녹음 및 양산 로그 확장

사용자 승인 범위: PC 1kHz 출력 → 스피커 소리를 디바이스가 수집 → PC 오디오 입력. 자동 녹음·판정·양산 로그를 기존 앱에 추가하고 Test 저장소 ZIP을 갱신한다.
가정: 디바이스가 Windows의 표준 녹음 장치로 노출된다. UART/독자 USB packet 프로토콜은 제공되지 않았으므로 지원하지 않는다.

구현: PortAudio(sounddevice)로 입출력 장치를 각각 선택. SoX는 저장 WAV의 기존 검증/분석에 사용. 대안 SoX의 Windows recording backend는 배포별 지원/장치 열거 차이가 커 선택하지 않는다.
1kHz는 원클릭 연속 재생 가능. 자동 검사 시 기존 tone session을 재사용하거나 새로 시작한다. 새 세션이면 시험 후 중지하며 기존 연속 세션은 성공 시 유지. Stop/오류는 톤도 종료한다. 입력 monitoring은 출력으로 보내지 않는다.
기본 peak level -24dBFS, 48kHz, mono 입력, 녹음 3초, 안정화 1초. 입력/출력 channels/rate/level/duration 설정. 상태와 입력레벨 표시. 녹음 입력 callback buffer가 overflow하거나 출력 underflow하면 유효 판정 금지. 취소/장치 오류/무신호는 PASS가 될 수 없다.
무음 옵션 기본 해제. 켜면 출력 mute→안정화→무음1초→unmute→안정화→신호 녹음. 기존 tone은 이 옵션에서 잠깐 중단됨을 UI 명시. 버린 안정화 구간은 WAV에 포함하지 않는다. 실제 signal/noise 구간은 자동으로 분석 설정에 기록.
1kHz 전용 Spec 버튼은 enabled 항목만 조정(응답 off, noise/SNR은 무음 옵션과 일치, balance는 stereo만, SPL은 교정 시), 수치 한계 유지, confirmed 해제. 기본 Spec을 생산 기준으로 임의 승인하지 않는다. 주파수 응답은 광대역 시험 필요.

로그: 제품번호 필수(바코드 Enter 시작), 작업자와 station 필드. 선택한 결과 폴더에 UTC run ID/시각 및 KST 날짜 디렉터리 WAV, SQLite production.sqlite3, 일자별 events.jsonl. SQLite synchronous FULL, run 시작 전 RUNNING row commit. 원본 sha, 장치 이름/id/host, 파라미터, Spec snapshot, 측정값/사유 포함 report JSON을 최종 트랜잭션에 저장한다. authoritative log는 SQLite. 결과 JSON/CSV는 DB로부터 UI에서 export. 취소 ABORTED, 오류 ERROR, 비정상 종료 RUNNING/PENDING은 PASS 아님. 결과 저장 commit 전 UI에 PASS 표시 금지. 실패 시 최대한 ERROR 기록하고 저장 오류 표시.
이력 탭: 제품번호 검색, 최신1000건, 선택 run 상세 JSON 및 전체 CSV export. 별도 음성 장치 없는 Linux에서는 합성 input/backend test와 Qt 통합 검증. 실제 Windows 스피커/디바이스 체인 검증은 별도이며 완료 주장 금지.

수집 유효성: 전체 구간 100ms FFT 1kHz(980~1020Hz bin) 에너지 비율60%, 20ms power/median≥0.1 및 median power≥1e-12, 전체 THD window의 모델 적합 여부. 약1초 window별 THD 최댓값으로 뒤쪽 왜곡도 판정. 취소는 finalizing event/fsync 이후 최종 DB UPDATE 직전까지 수락하고, 그 지점 이후에는 commit 완료를 기다린다. decision lock은 상태 변경에만 사용하며 UI에서 디스크 I/O를 잠그지 않는다. 상단 오디오 중지/Esc로 출력 즉시 중지 가능.
