from speakercheck.audio import CapturePlan


class DeviceBackend:
    def query_devices(self):
        return [
            {'name':'USB Microphone','hostapi':0,'max_input_channels':2,'max_output_channels':0},
            {'name':'PC Speakers','hostapi':0,'max_input_channels':0,'max_output_channels':2},
            {'name':'USB Microphone','hostapi':1,'max_input_channels':2,'max_output_channels':0},
            {'name':'PC Speakers','hostapi':1,'max_input_channels':0,'max_output_channels':2},
            {'name':'Laptop Mono Mic','hostapi':1,'max_input_channels':1,'max_output_channels':0}]
    def query_hostapis(self):
        return [{'name':'MME','default_input_device':0,'default_output_device':1},
                {'name':'Windows WASAPI','default_input_device':2,'default_output_device':3}]


def test_simple_devices_prefer_wasapi_remove_driver_duplicates_and_mono():
    from speakercheck.devices import device_choices
    choices=device_choices(DeviceBackend())
    assert [d['id'] for d in choices['input']]==[2]
    assert [d['id'] for d in choices['output']]==[3]
    assert choices['input'][0]['default']
    assert '[2]' not in choices['input'][0]['text']
    assert len(device_choices(DeviceBackend(),advanced=True)['input'])==3


def test_restore_identity_does_not_use_stale_numeric_index_or_default_on_missing():
    from speakercheck.devices import device_choices,choose_device
    rows=device_choices(DeviceBackend())['input']
    identity=rows[0]['identity']
    changed=[dict(rows[0],id=19)]
    assert choose_device(changed,identity)==19
    assert choose_device(rows,dict(identity,name='unplugged')) is None
    assert choose_device(rows+[dict(rows[0],id=20)],identity) is None
    assert choose_device(rows,None)==2


def test_input_check_receives_stereo_levels_and_closes_without_output():
    import numpy as np
    from speakercheck.device_check import InputCheckWorker
    class Backend:
        closed=False
        def check_input_settings(self,**kwargs): pass
        def InputStream(self,**kwargs):
            parent=self
            class Stream:
                def start(self):
                    t=np.arange(1024)/48000
                    x=.1*np.sin(2*np.pi*1000*t)
                    kwargs['callback'](np.column_stack([x,x*.5]),1024,None,False)
                def stop(self): pass
                def close(self):parent.closed=True
            return Stream()
    backend=Backend();levels=[];errors=[];completed=[]
    worker=InputCheckWorker(2,48000,backend=backend,duration=.12)
    worker.levels.connect(levels.append);worker.failed.connect(errors.append);worker.completed.connect(completed.append)
    worker.run()
    assert not errors and completed==[True] and backend.closed
    assert abs(levels[0][0]-levels[0][1]-6.0206)<.001


def test_input_check_failure_never_emits_completed():
    from speakercheck.device_check import InputCheckWorker
    class Broken:
        def check_input_settings(self,**kwargs):pass
        def InputStream(self,**kwargs):raise OSError('Error opening InputStream: invalid device')
    errors=[];completed=[]
    worker=InputCheckWorker(2,48000,backend=Broken(),duration=.1)
    worker.failed.connect(errors.append);worker.completed.connect(completed.append);worker.run()
    assert errors and 'invalid device' in errors[0] and not completed


def test_input_check_does_not_show_stale_levels_as_live_connection():
    import numpy as np
    from speakercheck.device_check import InputCheckWorker
    class Stalled:
        closed=False
        def check_input_settings(self,**kwargs): pass
        def InputStream(self,**kwargs):
            parent=self
            class Stream:
                def start(self):kwargs['callback'](np.full((1024,2),.01),1024,None,False)
                def stop(self):pass
                def close(self):parent.closed=True
            return Stream()
    backend=Stalled();errors=[];completed=[]
    worker=InputCheckWorker(2,48000,backend=backend,duration=1.2)
    worker.failed.connect(errors.append);worker.completed.connect(completed.append);worker.run()
    assert errors and '중단' in errors[0] and not completed and backend.closed
