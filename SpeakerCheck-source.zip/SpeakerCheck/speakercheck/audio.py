"""PortAudio acquisition; captured input is never routed to the output."""
from dataclasses import dataclass, replace, asdict
from queue import Queue, Empty, Full
import math
import threading
import time
import numpy as np
from .analysis import AnalysisSettings
from .spec import validate_spec


class AudioError(RuntimeError):
    pass


def audio_backend():
    try:
        import sounddevice
        return sounddevice
    except (ImportError,OSError) as exc:
        raise AudioError('오디오 엔진을 열 수 없습니다. setup.bat를 다시 실행하고 오디오 드라이버를 확인하세요.') from exc


@dataclass(frozen=True)
class CapturePlan:
    input_device: int
    output_device: int
    channels: int = 1
    output_channels: int = 2
    rate: int = 48000
    frequency: float = 1000.
    level_dbfs: float = -24.
    duration: float = 3.
    settle: float = 1.
    noise_duration: float = 0.

    def replace(self,**kwargs):
        return replace(self,**kwargs)

    def validate(self):
        for name in ('input_device','output_device'):
            v=getattr(self,name)
            if type(v) is not int or v < 0:
                raise ValueError('PC 출력 장치와 디바이스 입력 장치를 명시적으로 선택하세요.')
        for name in ('duration','settle','noise_duration','level_dbfs','frequency'):
            v=getattr(self,name)
            if isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v):
                raise ValueError('녹음 설정에는 유한한 숫자를 입력하세요.')
        if type(self.rate) is not int or self.rate not in (44100,48000,96000):
            raise ValueError('지원 샘플레이트: 44.1/48/96 kHz')
        if self.channels not in (1,2) or self.output_channels not in (1,2):
            raise ValueError('입출력은 1 또는 2채널을 선택하세요.')
        if not .1 <= self.duration <= 60 or not .02 <= self.settle <= 10 or not 0 <= self.noise_duration <= 10:
            raise ValueError('녹음 0.1~60초, 안정화 0.02~10초, 무음 0~10초 범위를 확인하세요.')
        if not -60 <= self.level_dbfs <= -3 or self.frequency != 1000:
            raise ValueError('출력은 1 kHz, Peak -60~-3 dBFS 범위입니다.')
        return self


class ToneGenerator:
    def __init__(self,rate,channels,frequency,level_dbfs):
        self.rate=rate;self.channels=channels;self.frequency=frequency
        self.amplitude=10**(level_dbfs/20)
        self.phase=0;self.envelope=0.;self.muted=False

    def render(self,frames):
        n=np.arange(frames)
        target=0. if self.muted else 1.
        step=1/max(1,round(self.rate*.005))
        envelope=np.clip(self.envelope+(n+1)*step*(1 if target else -1),0,1)
        self.envelope=float(envelope[-1]) if frames else self.envelope
        values=self.amplitude*envelope*np.sin(2*np.pi*(self.phase+n)*self.frequency/self.rate)
        self.phase=(self.phase+frames)%self.rate
        return np.repeat(values[:,None],self.channels,axis=1).astype(np.float32)


class ToneOutput:
    def __init__(self,plan,backend=None,muted=False):
        self.plan=plan.validate()
        self.backend=backend if backend is not None else audio_backend()
        self.generator=ToneGenerator(plan.rate,plan.output_channels,plan.frequency,plan.level_dbfs)
        self.generator.muted=muted
        self.stream=None
        self.error=None

    @property
    def active(self):
        return self.stream is not None

    def set_muted(self,muted):
        self.generator.muted=bool(muted)

    def start(self):
        if self.active:
            return
        self.backend.check_output_settings(device=self.plan.output_device,samplerate=self.plan.rate,
            channels=self.plan.output_channels,dtype='float32')
        def callback(outdata,frames,time_info,status):
            if status:
                self.error='PC 출력 오류: '+str(status)
            outdata[:]=self.generator.render(frames)
        stream=self.backend.OutputStream(device=self.plan.output_device,samplerate=self.plan.rate,
            channels=self.plan.output_channels,dtype='float32',callback=callback,blocksize=1024)
        try:
            stream.start()
            self.stream=stream
        except BaseException:
            stream.close()
            raise

    def stop(self):
        stream,self.stream=self.stream,None
        if stream is not None:
            try:
                stream.stop()
            finally:
                stream.close()


class _InputBuffer:
    def __init__(self,plan,backend):
        self.queue=Queue(maxsize=128)
        self.error=None
        self.pending=np.empty((0,plan.channels),np.float32)
        def callback(indata,frames,time_info,status):
            if status:
                self.error='입력 overflow/장치 오류: '+str(status)
            try:
                self.queue.put_nowait(indata.copy())
            except Full:
                self.error='입력 overflow: 녹음 버퍼가 가득 찼습니다.'
        self.stream=backend.InputStream(device=plan.input_device,samplerate=plan.rate,
            channels=plan.channels,dtype='float32',callback=callback,blocksize=1024)

    def take(self,frames,cancel,tone,progress,stage,rate,discard=False):
        blocks=[];remaining=frames;last_data=time.monotonic()
        while remaining:
            if cancel.is_set():
                raise InterruptedError('사용자가 검사를 중단했습니다.')
            if self.error or tone.error:
                raise AudioError(self.error or tone.error)
            if not len(self.pending):
                try:
                    self.pending=self.queue.get(timeout=.05)
                    last_data=time.monotonic()
                except Empty:
                    if time.monotonic()-last_data > 5:
                        raise AudioError('5초 동안 PC 입력 데이터가 없습니다. 장치 연결을 확인하세요.')
                    continue
            n=min(remaining,len(self.pending))
            block=self.pending[:n]
            if not np.all(np.isfinite(block)) or np.any(np.abs(block)>1):
                raise AudioError('입력 표본이 유효한 float 오디오 범위를 벗어났습니다.')
            if not discard:
                blocks.append(block.copy())
            self.pending=self.pending[n:]
            remaining-=n
            if progress:
                power=float(np.mean(block.astype(float)**2))
                db=10*math.log10(power) if power>0 else None
                progress(stage,(frames-remaining)/max(1,frames),db)
        return np.concatenate(blocks) if blocks else None


@dataclass
class CapturedAudio:
    samples: np.ndarray
    settings: AnalysisSettings
    metadata: dict


def capture_audio(plan,cancel,progress=None,backend=None,tone=None,calibration_db=None):
    plan.validate()
    if cancel.is_set():
        raise InterruptedError('사용자가 검사를 중단했습니다.')
    backend=backend if backend is not None else audio_backend()
    backend.check_input_settings(device=plan.input_device,samplerate=plan.rate,channels=plan.channels,dtype='float32')
    owns_tone=tone is None
    tone=tone or ToneOutput(plan,backend,muted=plan.noise_duration>0)
    fields=('output_device','output_channels','rate','frequency','level_dbfs')
    if any(getattr(plan,k)!=getattr(tone.plan,k) for k in fields):
        raise AudioError('연속 재생 중인 출력 설정과 검사 설정이 다릅니다. 톤을 중지하고 다시 시작하세요.')
    recorder=None;started=False;success=False
    try:
        tone.set_muted(plan.noise_duration>0)
        tone.start()
        recorder=_InputBuffer(plan,backend)
        recorder.stream.start();started=True
        def take(seconds,stage,discard=False):
            return recorder.take(round(seconds*plan.rate),cancel,tone,progress,stage,plan.rate,discard)
        noise=None
        if plan.noise_duration:
            take(plan.settle,'무음 안정화',True)
            noise=take(plan.noise_duration,'무음 녹음')
        tone.set_muted(False)
        take(plan.settle,'1 kHz 안정화',True)
        recorded=take(plan.duration,'신호 녹음')
        if cancel.is_set():
            raise InterruptedError('사용자가 검사를 중단했습니다.')
        if recorder.error or tone.error:
            raise AudioError(recorder.error or tone.error)
        noise_frames=0 if noise is None else len(noise)
        signal_start=noise_frames/plan.rate
        samples=recorded if noise is None else np.concatenate([noise,recorded])
        settings=AnalysisSettings(signal_start=signal_start,signal_end=len(samples)/plan.rate,
            noise_start=0. if noise_frames else None,noise_end=signal_start if noise_frames else None,
            tone_hz=plan.frequency,calibration_db=calibration_db)
        success=True
        return CapturedAudio(samples,settings,{'plan':asdict(plan),'discarded_settle_seconds':plan.settle*(2 if noise_frames else 1),
            'uses_existing_continuous_tone':not owns_tone})
    finally:
        try:
            if recorder is not None:
                try:
                    if started:
                        recorder.stream.stop()
                finally:
                    recorder.stream.close()
        finally:
            if owns_tone or not success or cancel.is_set():
                tone.stop()
            else:
                tone.set_muted(False)


def one_khz_spec(spec,channels,noise,calibrated):
    result=validate_spec(spec)
    result['confirmed']=False
    for key,enabled in {'response_db':False,'balance_db':channels==2,
                         'noise_dbfs':noise,'snr_db':noise,'spl_db':calibrated}.items():
        result['metrics'][key]['enabled']=enabled
    return result


def validate_returned_tone(samples,rate):
    """Acquisition gate over the whole signal, independent of optional Spec rows."""
    x=np.asarray(samples,dtype=float)
    if x.ndim!=2 or len(x)<round(.1*rate) or not np.all(np.isfinite(x)):
        return {'valid':False,'reason':'유효한 1 kHz 녹음 표본이 부족합니다.'}
    minimum_share=1.
    count=max(1,int(math.ceil(len(x)/(rate*.1))))
    for part in np.array_split(x,count):
        ac=part-np.mean(part,axis=0)
        spectrum=np.abs(np.fft.rfft(ac*np.hanning(len(ac))[:,None],axis=0))**2
        spectrum[0]=0
        f=np.fft.rfftfreq(len(part),1/rate)
        peak=np.argmax(spectrum,axis=0)
        for channel,index in enumerate(peak):
            total=float(np.sum(spectrum[:,channel]))
            if not 980<=f[index]<=1020 or total<1e-16:
                return {'valid':False,'reason':'녹음 중 1 kHz 신호가 없거나 주파수가 범위를 벗어났습니다.'}
            share=float(np.sum(spectrum[max(1,index-1):index+2,channel])/total)
            minimum_share=min(minimum_share,share)
            if share<.6:
                return {'valid':False,'reason':'녹음 중 1 kHz 톤의 에너지가 부족합니다.','minimum_tone_energy_fraction':minimum_share}
    # 20 ms RMS windows catch short gaps hidden by long-window energy/THD.
    small_count=max(1,int(math.ceil(len(x)/(rate*.02))))
    power=np.array([np.mean((p-np.mean(p,axis=0))**2,axis=0) for p in np.array_split(x,small_count)])
    median=np.median(power,axis=0)
    if np.any(median<1e-12):
        return {'valid':False,'reason':'디바이스 입력의 신호 레벨이 너무 낮습니다.'}
    ratio=float(np.min(power/median))
    if ratio<.1:
        return {'valid':False,'reason':'녹음 중 신호 단절 또는 급격한 레벨 저하가 감지되었습니다.','minimum_short_window_power_ratio':ratio}
    return {'valid':True,'reason':'녹음 전체에서 연속적인 1 kHz 입력을 확인했습니다.',
            'minimum_tone_energy_fraction':minimum_share,'minimum_short_window_power_ratio':ratio}
