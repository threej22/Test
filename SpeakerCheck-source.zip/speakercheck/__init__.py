"""SpeakerCheck — SoX based speaker verification."""
__version__ = '0.3.0'
