@echo off
setlocal
cd /d "%~dp0"
set "SCX_SETUP_RC=1"
set "SCX_PY="
set "SCX_LOG=%~dp0setup.log"
> "%SCX_LOG%" echo SpeakerCheck setup log
if errorlevel 1 goto LogFailed
if not exist "%~dp0speakercheck\ui.py" goto MissingFiles
where py >nul 2>nul
if errorlevel 1 goto TryPython
for %%V in (3.12 3.11 3.13 3.14) do call :FindPython %%V
if defined SCX_PY goto PythonReady
:TryPython
python -c "import sys,struct; assert (3,11) <= sys.version_info[:2] <= (3,14) and struct.calcsize('P') == 8" >> "%SCX_LOG%" 2>&1
if errorlevel 1 goto PythonMissing
set "SCX_PY=python"
:PythonReady
echo Python found. Preparing local environment...
if exist "%~dp0.venv\Scripts\python.exe" goto CheckVenv
%SCX_PY% -m venv "%~dp0.venv" >> "%SCX_LOG%" 2>&1
if errorlevel 1 goto Failed
:CheckVenv
"%~dp0.venv\Scripts\python.exe" -c "import sys,struct; assert (3,11) <= sys.version_info[:2] <= (3,14) and struct.calcsize('P') == 8" >> "%SCX_LOG%" 2>&1
if errorlevel 1 goto BadVenv
echo Installing application packages. This can take several minutes.
echo Details: "%SCX_LOG%"
"%~dp0.venv\Scripts\python.exe" -m pip install -r "%~dp0requirements.txt" >> "%SCX_LOG%" 2>&1
if errorlevel 1 goto Failed
echo Setup complete. Run start.bat or build_windows.bat.
set "SCX_SETUP_RC=0"
goto Finish
:MissingFiles
>> "%SCX_LOG%" echo The speakercheck folder is missing. Extract the entire ZIP first.
goto Failed
:PythonMissing
>> "%SCX_LOG%" echo Install 64-bit Python 3.12 on this BUILD PC, then run again.
>> "%SCX_LOG%" echo Python 3.11 through 3.14 is supported. Python is not required on portable target PCs.
goto Failed
:BadVenv
>> "%SCX_LOG%" echo The existing .venv is broken or incompatible. Rename .venv and run setup again.
goto Failed
:LogFailed
echo Cannot write setup.log. Extract the ZIP to a writable folder.
goto Finish
:Failed
echo Setup failed. Details follow:
type "%SCX_LOG%"
echo Log saved to "%SCX_LOG%"
:Finish
if /i "%~1"=="--no-pause" goto Return
pause
:Return
exit /b %SCX_SETUP_RC%
:FindPython
if defined SCX_PY exit /b 0
py -%~1 -c "import sys,struct; assert (3,11) <= sys.version_info[:2] <= (3,14) and struct.calcsize('P') == 8" >> "%SCX_LOG%" 2>&1
if errorlevel 1 exit /b 0
set "SCX_PY=py -%~1"
exit /b 0
