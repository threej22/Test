"""Friendly PortAudio endpoint lists and stable, unambiguous saved identities."""


def device_choices(backend,advanced=False):
    devices=backend.query_devices();hosts=backend.query_hostapis()
    result={}
    for direction in ('input','output'):
        field='max_'+direction+'_channels'
        rows=[]
        for index,device in enumerate(devices):
            channels=int(device[field])
            if channels<=0:continue
            host=hosts[device['hostapi']]
            identity={'name':device['name'],'host':host['name'],'direction':direction}
            default=host.get('default_'+direction+'_device',-1)==index
            rows.append({'id':index,'name':device['name'],'host':host['name'],'channels':channels,
                         'default':default,'identity':identity})
        if not advanced:
            rows=[r for r in rows if r['channels']>=2]
            wasapi=[r for r in rows if 'wasapi' in r['host'].lower()]
            if wasapi:rows=wasapi
        for row in rows:
            row['text']=row['name']+(' · 기본' if row['default'] else '')
            if advanced:row['text']+=' · '+row['host']
            if row['channels']<2:row['text']+=' · 1채널 (좌우 검사 불가)'
        result[direction]=rows
    return result


def choose_device(rows,identity=None):
    if identity is not None:
        matches=[r for r in rows if r['identity']==identity]
        return matches[0]['id'] if len(matches)==1 else None
    defaults=[r for r in rows if r['default']]
    if len(defaults)==1:return defaults[0]['id']
    return rows[0]['id'] if len(rows)==1 else None
