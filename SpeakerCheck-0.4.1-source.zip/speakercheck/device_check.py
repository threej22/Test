"""Short input connection check; no inspection verdict or production log."""
import threading
import time
import numpy as np
from PySide6.QtCore import QThread,Signal
from .audio import audio_backend,AudioError


class InputCheckWorker(QThread):
    levels=Signal(object)
    failed=Signal(str)
    completed=Signal(bool)

    def __init__(self,device,rate,channels=2,backend=None,duration=8.):
        super().__init__()
        self.device=device;self.rate=rate;self.channels=channels
        self.backend=backend;self.duration=duration;self.cancel=threading.Event()

    def stop(self):
        self.cancel.set()

    def run(self):
        stream=None;started=False;seen=False
        latest=None;error=None;last_data=None
        try:
            if type(self.device) is not int or self.device<0:
                raise ValueError('입력 장치를 먼저 선택하세요.')
            backend=self.backend or audio_backend()
            backend.check_input_settings(device=self.device,samplerate=self.rate,channels=self.channels,dtype='float32')
            def callback(data,frames,time_info,status):
                nonlocal latest,error,last_data
                if status:
                    error='입력 장치 오류: '+str(status)
                    return
                if data.ndim!=2 or not len(data) or data.shape[1]!=self.channels or not np.all(np.isfinite(data)) or np.any(np.abs(data)>1):
                    error='유효하지 않은 입력 오디오입니다.'
                    return
                last_data=time.monotonic()
                power=np.mean(data.astype(float)**2,axis=0)
                latest=[float(10*np.log10(p)) if p>0 else None for p in power]
            stream=backend.InputStream(device=self.device,samplerate=self.rate,channels=self.channels,
                dtype='float32',callback=callback,blocksize=1024)
            stream.start();started=True
            began=time.monotonic();deadline=began+self.duration
            while not self.cancel.is_set() and time.monotonic()<deadline:
                if error:raise AudioError(error)
                if last_data is not None and time.monotonic()-last_data>1.:
                    raise AudioError('입력 데이터 수신이 중단되었습니다. 장치 연결을 확인하세요.')
                if latest is not None:
                    seen=True;self.levels.emit(latest)
                self.cancel.wait(.1)
            if error:raise AudioError(error)
            if not self.cancel.is_set() and not seen:
                raise AudioError('입력 데이터가 없습니다. 마이크 연결과 Windows 마이크 접근 권한을 확인하세요.')
            # Closing errors are connection failures too; emit completed only afterwards.
            if started:stream.stop();started=False
            stream.close();stream=None
            self.completed.emit(seen and not self.cancel.is_set())
        except Exception as exc:
            self.failed.emit(str(exc))
        finally:
            if stream is not None:
                try:
                    if started:stream.stop()
                except Exception:pass
                try:stream.close()
                except Exception:pass
