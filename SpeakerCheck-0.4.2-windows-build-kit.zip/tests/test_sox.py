import os
from pathlib import Path
import numpy as np
import pytest
from scipy.io import wavfile
from speakercheck.sox import SoxEngine
from speakercheck.report import make_report, export_json, export_csv
from speakercheck.analysis import AnalysisSettings
from speakercheck.spec import default_spec

SOX = os.environ.get('SOX_BINARY', 'sox')


def test_real_sox_unicode_stereo_and_report(tmp_path):
    path = tmp_path/'검사 sample 01.wav'
    t = np.arange(48000)/48000
    samples = np.column_stack([.1*np.sin(2*np.pi*1000*t), .1*np.sin(2*np.pi*1000*t)])
    wavfile.write(path, 48000, (samples*32767).astype(np.int16))
    engine = SoxEngine(SOX)
    audio = engine.read(path)
    assert audio.rate == 48000
    assert audio.samples.shape == (48000, 2)
    assert np.max(audio.samples) == pytest.approx(.1, abs=1/32768)
    assert 'RMS' in audio.sox_stats
    assert len(audio.sha256) == 64
    report = make_report(engine, path, AnalysisSettings(), default_spec())
    export_json(report, tmp_path/'result.json')
    export_csv(report, tmp_path/'result.csv')
    assert 'SPEC REQUIRED' in (tmp_path/'result.json').read_text('utf-8')
    assert 'RMS' in (tmp_path/'result.csv').read_text('utf-8-sig')
    assert report['source']['sha256'] == audio.sha256


def test_normalized_float_wav_preserves_full_scale(tmp_path):
    path = tmp_path/'float.wav'
    wavfile.write(path, 48000, np.tile(np.array([0., .5, -.5, 1.], np.float32), 256))
    x = SoxEngine(SOX).read(path)
    assert x.samples[:4,0] == pytest.approx([0,.5,-.5,1.], abs=1e-7)


def test_24_bit_pcm(tmp_path):
    import wave
    path = tmp_path/'24.wav'
    values = [0, 4194304, -4194304]*512
    raw = b''.join((v & 0xffffff).to_bytes(3,'little') for v in values)
    with wave.open(str(path),'wb') as f:
        f.setparams((1,3,48000,0,'NONE','not compressed'))
        f.writeframes(raw)
    x = SoxEngine(SOX).read(path)
    assert x.samples[:3,0] == pytest.approx([0,.5,-.5], abs=1e-7)


def test_invalid_wav_and_missing_executable(tmp_path):
    p = tmp_path/'bad.wav'
    p.write_text('not a WAV')
    with pytest.raises(ValueError):
        SoxEngine(SOX).read(p)
    with pytest.raises(ValueError):
        SoxEngine(str(tmp_path/'absent.exe'))


def test_reference_rate_mismatch_rejected(tmp_path):
    a, b = tmp_path/'a.wav', tmp_path/'b.wav'
    wavfile.write(a,48000,np.zeros(4800,dtype=np.int16))
    wavfile.write(b,44100,np.zeros(4410,dtype=np.int16))
    with pytest.raises(ValueError, match='샘플레이트'):
        make_report(SoxEngine(SOX), a, AnalysisSettings(), default_spec(), reference=b)


@pytest.mark.parametrize('bad_value',[np.nan,np.inf,-np.inf,1.5])
def test_float_input_sox_would_saturate_is_rejected(tmp_path,bad_value):
    path = tmp_path/'bad_float.wav'
    x = np.zeros(4800,np.float32)
    x[0] = bad_value
    wavfile.write(path,48000,x)
    with pytest.raises(ValueError,match='float WAV'):
        SoxEngine(SOX).read(path)


def test_source_changed_during_decode_is_rejected(tmp_path,monkeypatch):
    path = tmp_path/'changing.wav'
    wavfile.write(path,48000,np.zeros(4800,np.int16))
    engine = SoxEngine(SOX)
    real = engine._run
    def change_after_decode(args):
        result = real(args)
        if 'raw' in args:
            with path.open('ab') as f:
                f.write(b'changed')
        return result
    monkeypatch.setattr(engine,'_run',change_after_decode)
    with pytest.raises(ValueError,match='변경'):
        engine.read(path)


def test_timeout_has_actionable_error(tmp_path,monkeypatch):
    import subprocess
    path = tmp_path/'normal.wav'
    wavfile.write(path,48000,np.zeros(4800,np.int16))
    engine = SoxEngine(SOX)
    def timeout(*args,**kwargs):
        raise subprocess.TimeoutExpired('sox',60)
    monkeypatch.setattr(subprocess,'run',timeout)
    with pytest.raises(ValueError,match='60초'):
        engine.read(path)


def test_decode_budget_checked_before_allocation(tmp_path,monkeypatch):
    import speakercheck.sox as adapter
    path = tmp_path/'over_budget.wav'
    wavfile.write(path,48000,np.zeros(4800,np.int16))
    monkeypatch.setattr(adapter,'MAX_DECODE_BYTES',1024)
    with pytest.raises(ValueError,match='디코딩 크기'):
        SoxEngine(SOX).read(path)


def test_truncated_wav_rejected(tmp_path):
    path = tmp_path/'truncated.wav'
    wavfile.write(path,48000,np.zeros(4800,np.int16))
    payload = path.read_bytes()
    path.write_bytes(payload[:-2400])
    with pytest.raises(ValueError):
        SoxEngine(SOX).read(path)


def test_legacy_cli_filename_encoding_does_not_break_unicode_wav(tmp_path,monkeypatch):
    import subprocess
    path=tmp_path/'검사 녹음.wav'
    wavfile.write(path,48000,np.zeros(4800,np.int16))
    real=subprocess.run
    def legacy_cli(command,**kwargs):
        if any('검사' in str(part) for part in command):
            raise OSError('legacy executable cannot encode Unicode filename')
        return real(command,**kwargs)
    monkeypatch.setattr(subprocess,'run',legacy_cli)
    audio=SoxEngine(SOX).read(path)
    assert audio.path==str(path.resolve()) and audio.samples.shape==(4800,1)
