"""SIMULATION preview: synthetic hardware boundary with actual SoX and SQLite."""
import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
from pathlib import Path
import sys
import time
from datetime import datetime
sys.path[:0]=[str(Path(__file__).resolve().parents[1]),str(Path(__file__).resolve().parents[1]/'tests')]
from PySide6.QtWidgets import QApplication
from speakercheck.ui import MainWindow
from speakercheck.audio import one_khz_spec
from speakercheck.spec import default_spec
from speakercheck.production import ProductionStore
from test_capture import SyntheticBackend

base=Path(__file__).resolve().parents[1]
out=base/'output'
out.mkdir(exist_ok=True)
# New folder for each preview avoids changing an earlier evidence database.
logs=out/('simulation-'+datetime.now().strftime('%Y%m%d-%H%M%S'))
app=QApplication([])
w=MainWindow();w.resize(1440,1080)
p=w.capture_panel;p.backend=SyntheticBackend()
p.input_combo.addItem('SIMULATED device audio input',2);p.input_combo.setCurrentIndex(1)
p.output_combo.addItem('SIMULATED PC speaker output',3);p.output_combo.setCurrentIndex(1)
p.serial_edit.setText('SIMULATION-0001');p.operator_edit.setText('DEMO');p.station_edit.setText('SIMULATED I/O - real SoX')
p.directory_edit.setText(str(logs));p.duration.setValue(3);p.settle.setValue(.05)
spec=one_khz_spec(default_spec(),1,False,False)
spec['name']='SIMULATION ONLY - not product qualification'
spec['confirmed']=True  # Controlled test fixture only.
w.spec_editor.set_spec(spec);w.sox_edit.setText(os.environ.get('SOX_BINARY','sox'))
w.show();w.run_button.click()
deadline=time.monotonic()+30
while w.worker is not None and time.monotonic()<deadline:
    app.processEvents();time.sleep(.01)
if w.report is None:
    raise RuntimeError(p.live_status.text())
w.local_badge.setText('SIMULATION · real SoX')
app.processEvents();w.grab().save(str(out/'SpeakerCheck-auto-preview.png'))
w.navigate(2);w.settings_tabs.setCurrentIndex(2);app.processEvents();w.grab().save(str(out/'SpeakerCheck-history-preview.png'))
store=ProductionStore(logs);store.export_csv(out/'production-log-example.csv')
print('SIMULATED acquisition + real SoX:',w.report['verdict'],'persisted rows:',len(store.history()))
w.close()
