"""Bounded, shell-free SoX adapter; no network or audio hardware access."""
from dataclasses import dataclass
from contextlib import ExitStack
from pathlib import Path
import hashlib
import os
import shutil
import subprocess
import sys
import numpy as np
from .paths import resource_root

MAX_DECODE_BYTES = 512*1024*1024
MAX_FILE_BYTES = 512*1024*1024


@dataclass
class AudioData:
    path: str
    samples: np.ndarray
    rate: int
    bits: int
    sha256: str
    sox_stats: str


def locate_sox():
    roots=[resource_root()]
    if getattr(sys,'frozen',False) and Path(sys.executable).parent not in roots:
        roots.append(Path(sys.executable).parent)
    for base in roots:
        for candidate in [base/'tools'/'sox'/'sox.exe',base/'tools'/'sox.exe',base/'sox.exe']:
            if candidate.is_file():
                return str(candidate)
    return shutil.which('sox') or 'sox.exe'


class SoxEngine:
    def __init__(self, executable=None):
        requested = str(executable or locate_sox()).strip()
        resolved = shutil.which(requested)
        if not resolved:
            raise ValueError('SoX를 찾을 수 없습니다. 설정에서 sox.exe 경로를 지정하세요.')
        self.executable = str(Path(resolved).resolve())
        self.version = self._run(['--version']).stdout.decode('utf-8', errors='replace').strip()
        if 'sox' not in self.version.lower():
            raise ValueError('지정한 프로그램은 SoX가 아닙니다.')

    def _run(self, args):
        try:
            # Legacy Windows SoX cannot represent Unicode filenames in argv.
            # Python opens the WAV and passes the seekable file descriptor as stdin.
            # Metadata, decoding, and stats still use actual SoX; no full-file copy.
            with ExitStack() as stack:
                stdin=None;command=[self.executable]
                for arg in args:
                    if isinstance(arg,Path):
                        if stdin is not None:raise ValueError('Only one WAV input is supported per SoX command.')
                        stdin=stack.enter_context(arg.open('rb'));command.append('-')
                    else:command.append(str(arg))
                result = subprocess.run(command, stdin=stdin, capture_output=True,
                                        timeout=60, check=False,
                                        creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
        except subprocess.TimeoutExpired as exc:
            raise ValueError('SoX 분석 제한 시간(60초)을 초과했습니다.') from exc
        except OSError as exc:
            raise ValueError(f'SoX 실행 실패: {exc}') from exc
        if result.returncode:
            detail = result.stderr.decode('utf-8', errors='replace')[-2500:]
            raise ValueError(f'SoX 오류: {detail}')
        return result

    def read(self, path):
        path = Path(path).resolve(strict=True)
        original_stat = path.stat()
        if original_stat.st_size > MAX_FILE_BYTES:
            raise ValueError('WAV 파일 크기는 512 MiB 이하여야 합니다.')
        with path.open('rb') as f:
            header = f.read(12)
        if len(header) < 12 or header[:4] not in (b'RIFF', b'RIFX', b'RF64') or header[8:12] != b'WAVE':
            raise ValueError('RIFF/RIFX/RF64 WAV 파일만 지원합니다.')
        try:
            info = [int(self._run(['--i', flag, path]).stdout.strip()) for flag in ('-r', '-c', '-s', '-b')]
        except (TypeError, ValueError) as exc:
            raise ValueError(f'WAV 정보를 읽을 수 없습니다: {exc}') from exc
        rate, channels, frames, bits = info
        if rate < 1000 or rate > 768000 or not 1 <= channels <= 32 or frames < 32:
            raise ValueError('지원 범위 밖의 샘플레이트·채널·표본 수입니다.')
        expected_bytes = frames*channels*8
        if expected_bytes > MAX_DECODE_BYTES:
            raise ValueError('디코딩 크기가 512 MiB를 초과합니다. WAV를 짧게 잘라 사용하세요.')
        encoding = self._run(['--i', '-e', path]).stdout.decode('utf-8', errors='replace').lower()
        if 'floating' in encoding:
            # SoX uses fixed-point internals and can turn NaN/Inf or >FS into
            # finite clipped samples. Validate original floats before decoding.
            from scipy.io import wavfile
            try:
                _, original = wavfile.read(path, mmap=True)
                try:
                    if not np.issubdtype(original.dtype, np.floating) or not np.all(np.isfinite(original)) or np.any(original > 1) or np.any(original < -1):
                        raise ValueError('float WAV는 유한하며 -1~+1 범위로 정규화된 표본이어야 합니다.')
                finally:
                    del original
            except (OSError, ValueError) as exc:
                raise ValueError(f'float WAV 원본 검증 실패: {exc}') from exc
        # SoX trim bounds output even if a malformed header understates the frame count.
        out = self._run(['-D', path, '-t', 'raw', '-e', 'floating-point', '-b', '64', '-L', '-',
                         'trim', '0', f'{frames}s'])
        if len(out.stdout) != expected_bytes:
            raise ValueError('WAV 헤더의 표본 수와 실제 디코딩 길이가 다릅니다(손상/잘림).')
        samples = np.frombuffer(out.stdout, dtype='<f8').reshape(frames, channels)
        if not np.all(np.isfinite(samples)):
            raise ValueError('WAV에 NaN 또는 무한대 표본이 있습니다.')
        stats = self._run(['-D', path, '-n', 'stats']).stderr.decode('utf-8', errors='replace')
        digest = hashlib.sha256()
        with path.open('rb') as f:
            for block in iter(lambda: f.read(1024*1024), b''):
                digest.update(block)
        final_stat = path.stat()
        attrs = ('st_size', 'st_mtime_ns', 'st_ctime_ns', 'st_ino', 'st_dev')
        if any(getattr(original_stat, k) != getattr(final_stat, k) for k in attrs):
            raise ValueError('분석 도중 원본 WAV가 변경되었습니다. 다시 분석하세요.')
        return AudioData(str(path), samples, rate, bits, digest.hexdigest(), stats)
