import json


def test_portable_diagnostic_uses_actual_sox_and_isolated_ledger(tmp_path,monkeypatch):
    from speakercheck import selftest
    from speakercheck.sox import SoxEngine
    import os
    monkeypatch.setattr(selftest,'audio_backend',lambda:object())
    monkeypatch.setattr(selftest,'SoxEngine',lambda:SoxEngine(os.environ.get('SOX_BINARY','sox')))
    path=tmp_path/'diagnostic.json'
    assert selftest.run_self_test(path)==0
    result=json.loads(path.read_text())
    assert result['status']=='ok' and result['sqlite_verified']
    assert result['single_tone']=='PASS' and result['two_tones']=='FAIL'
    assert result['physical_audio_tested'] is False
