STYLE = '''
QWidget { background: #101722; color: #d9e4f1; font-family: "Malgun Gothic", "Noto Sans CJK KR", "Segoe UI"; font-size: 12px; }
QMainWindow { background: #101722; }
QFrame#sidebar { background: #0b111b; border-right: 1px solid #253043; }
QFrame#card { background: #172231; border: 1px solid #2a374b; border-radius: 12px; }
QFrame#card QLabel { background: transparent; border: none; }
QLabel#brand { color: #f3f8ff; font-size: 21px; font-weight: 700; }
QLabel#eyebrow { color: #59dcb9; font-size: 10px; font-weight: 700; letter-spacing: 2px; }
QLabel#title { font-size: 27px; font-weight: 700; color: #f2f6fc; }
QLabel#section { font-size: 14px; font-weight: 700; color: #eef5ff; }
QLabel#muted { color: #8fa2bc; }
QLabel#badge { background: #16332f; color: #69e4c5; border: 1px solid #24574a; border-radius: 9px; padding: 7px 12px; }
QLabel#verdict { font-size: 24px; font-weight: 700; color: #73e5c4; }
QLabel#metric { font-size: 23px; font-weight: 600; color: #f0f6ff; }
QLineEdit, QDoubleSpinBox, QComboBox { background: #101a28; border: 1px solid #344359; border-radius: 6px; padding: 7px; min-height: 19px; selection-background-color: #337767; }
QLineEdit:focus, QDoubleSpinBox:focus { border: 1px solid #58d5b5; }
QLineEdit:disabled, QDoubleSpinBox:disabled { color: #58687f; background: #131c28; }
QPushButton { background: #223249; border: 1px solid #364961; border-radius: 7px; padding: 8px 14px; font-weight: 600; }
QPushButton:hover { background: #2d425c; border-color: #608099; }
QPushButton:disabled { background: #182231; border-color: #263245; color: #5d6d83; }
QPushButton#primary { background: #5ee1bc; color: #08291f; border: none; padding: 12px 20px; font-size: 14px; }
QPushButton#primary:hover { background: #8af0d2; }
QPushButton#primary:disabled { background: #284a43; color: #7e9b93; }
QPushButton#nav { text-align: left; border: none; background: transparent; color: #8fa3be; padding: 14px; font-size: 14px; }
QPushButton#nav:checked { background: #16342f; color: #7befcf; }
QPushButton#nav:hover { background: #182a37; }
QTableWidget { background: #131e2d; alternate-background-color: #182535; gridline-color: #29374a; border: 1px solid #29374a; border-radius: 6px; selection-background-color: #25473f; selection-color: #effff9; }
QTableWidget::item { padding: 6px; }
QHeaderView::section { background: #1c2a3c; color: #95aac5; padding: 8px; border: none; border-bottom: 1px solid #35445a; font-weight: 600; }
QTabWidget::pane { border: 1px solid #2a394d; border-radius: 7px; background: #131e2d; }
QTabBar::tab { color: #8fa4c1; background: #131e2d; padding: 9px 22px; border-bottom: 2px solid transparent; }
QTabBar::tab:selected { color: #6de5c5; border-bottom: 2px solid #6de5c5; }
QCheckBox { spacing: 8px; padding: 4px 0; }
QCheckBox::indicator { width: 16px; height: 16px; border: 1px solid #52667e; border-radius: 3px; background: #101a28; }
QCheckBox::indicator:checked { background: #5ee1bc; border: 1px solid #88f3d5; image: none; }
QScrollArea { border: none; background: transparent; }
QScrollBar:vertical { background: #111b28; width: 10px; }
QScrollBar::handle:vertical { background: #34485e; min-height: 30px; border-radius: 5px; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0px; }
QProgressBar { border: none; background: #233246; border-radius: 2px; height: 4px; }
QProgressBar::chunk { background: #5ee1bc; }
QToolTip { color: #e0edf9; background: #24344a; border: 1px solid #566e89; }
QTextBrowser { border: 1px solid #293b50; background: #142030; padding: 20px; border-radius: 10px; }
QSplitter::handle { background: #101722; }
'''
