@echo off
setlocal
cd /d "%~dp0"
if not exist "%~dp0speakercheck\ui.py" goto MissingFiles
if exist "%~dp0.venv\Scripts\python.exe" goto Run
call "%~dp0setup.bat" --no-pause
if errorlevel 1 goto Failed
:Run
"%~dp0.venv\Scripts\python.exe" "%~dp0launch.py"
set "SCX_START_RC=%ERRORLEVEL%"
if not "%SCX_START_RC%"=="0" pause
exit /b %SCX_START_RC%
:MissingFiles
echo Application folder is missing. Extract the entire ZIP first.
:Failed
pause
exit /b 1
