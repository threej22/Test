"""Qt chart canvas; labels use ASCII so font fallback stays portable."""
import numpy as np
from matplotlib.figure import Figure
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg


class MeasurementPlot(FigureCanvasQTAgg):
    def __init__(self, kind):
        self.kind = kind
        fig = Figure(figsize=(7, 2.6), dpi=100, facecolor='#131e2d')
        super().__init__(fig)
        self.ax = fig.add_subplot(111)
        self.setMinimumHeight(210)
        self.render(None)

    def render(self, report):
        ax = self.ax
        ax.clear()
        ax.set_facecolor('#131e2d')
        ax.tick_params(colors='#8ea5bf', labelsize=8)
        for spine in ax.spines.values():
            spine.set_color('#304158')
        ax.xaxis.label.set_color('#8ea5bf')
        ax.yaxis.label.set_color('#8ea5bf')
        ax.grid(color='#304158', alpha=.45, linewidth=.6)
        data = report['plots'].get(self.kind) if report else None
        if data is None:
            message = 'Select a WAV and run analysis' if not report else 'Reference / broadband interval required'
            ax.text(.5,.5,message, color='#8ea5bf', ha='center',va='center',transform=ax.transAxes,fontsize=10)
            ax.set_xticks([])
            ax.set_yticks([])
        elif self.kind == 'waveform':
            ax.fill_between(data['time'], data['min'], data['max'], color='#60dfbb', alpha=.65, linewidth=.5)
            ax.set_xlabel('Time (s)')
            ax.set_ylabel('Amplitude (FS)')
            s = report['settings']
            end = s['signal_end'] or report['source']['duration_seconds']
            ax.axvspan(s['signal_start'],end,color='#60dfbb',alpha=.06)
            if s['noise_start'] is not None and s['noise_end'] is not None:
                ax.axvspan(s['noise_start'],s['noise_end'],color='#eabb66',alpha=.12)
            ax.set_xlim(0,report['source']['duration_seconds'])
        elif self.kind == 'spectrum':
            ax.semilogx(data['hz'],data['db'],color='#64dec0',linewidth=1.1)
            ax.set_xlabel('Frequency (Hz)')
            ax.set_ylabel('PSD (dBFS/Hz)')
            ax.set_xlim(20,report['source']['sample_rate']/2)
        else:
            vals = [np.nan if v is None else v for v in data['db']]
            ax.semilogx(data['hz'],vals,'o-',color='#65e1bd',markersize=4,linewidth=1.5)
            for bound in ('lower','upper'):
                lim = [np.nan if v is None else v for v in data[bound]]
                ax.semilogx(data['hz'],lim,'--',color='#e8b46b',linewidth=1)
            if all(v is not None for v in data['lower']+data['upper']):
                ax.fill_between(data['hz'],data['lower'],data['upper'],color='#62dcb5',alpha=.06)
            ax.axhline(0,color='#6c8198',linewidth=.5)
            ax.set_xlabel('Frequency (Hz) · 1/6 octave bands')
            ax.set_ylabel('Relative level (dB)')
        self.figure.subplots_adjust(left=.10,right=.97,bottom=.23,top=.94)
        self.draw_idle()
