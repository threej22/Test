import sys
from pathlib import Path


def test_frozen_onefile_sox_prefers_extracted_internal_copy(tmp_path,monkeypatch):
    from speakercheck.sox import locate_sox
    bundle=tmp_path/'_MEI123';exe_dir=tmp_path/'app'
    (bundle/'tools/sox').mkdir(parents=True);exe_dir.mkdir()
    inner=bundle/'tools/sox/sox.exe';inner.write_bytes(b'internal')
    (exe_dir/'sox.exe').write_bytes(b'external')
    monkeypatch.setattr(sys,'frozen',True,raising=False)
    monkeypatch.setattr(sys,'_MEIPASS',str(bundle),raising=False)
    monkeypatch.setattr(sys,'executable',str(exe_dir/'SpeakerCheck.exe'))
    assert Path(locate_sox())==inner


def test_onefile_resource_root_and_legacy_onedir_fallback(tmp_path,monkeypatch):
    from speakercheck.paths import resource_root
    monkeypatch.setattr(sys,'frozen',True,raising=False)
    monkeypatch.setattr(sys,'executable',str(tmp_path/'SpeakerCheck.exe'))
    monkeypatch.setattr(sys,'_MEIPASS',str(tmp_path/'extracted'),raising=False)
    assert resource_root()==tmp_path/'extracted'
    monkeypatch.delattr(sys,'_MEIPASS')
    assert resource_root()==tmp_path
