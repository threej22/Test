"""Launch works independently of cwd and Python safe-path defaults."""
from pathlib import Path
import shutil
import subprocess
import sys
import pytest

LAUNCH=Path(__file__).resolve().parents[1]/'launch.py'

@pytest.mark.parametrize('nested',[False,True])
def test_launcher_finds_package_in_fully_extracted_layout_with_isolated_python(tmp_path,nested):
    root=tmp_path/'SpeakerCheck 실행 폴더';root.mkdir()
    shutil.copyfile(LAUNCH,root/'launch.py')
    package_root=root/'SpeakerCheck' if nested else root
    p=package_root/'speakercheck';p.mkdir(parents=True)
    (p/'__init__.py').write_text('')
    (p/'ui.py').write_text("def main():\n    print('BOOTSTRAP_OK')\n")
    result=subprocess.run([sys.executable,'-I',str(root/'launch.py')],cwd=tmp_path,capture_output=True,text=True,timeout=5)
    assert result.returncode==0, result.stderr
    assert 'BOOTSTRAP_OK' in result.stdout


def test_missing_package_gives_extract_instructions(tmp_path):
    shutil.copyfile(LAUNCH,tmp_path/'launch.py')
    r=subprocess.run([sys.executable,str(tmp_path/'launch.py')],cwd=tmp_path,capture_output=True,text=True,timeout=5)
    assert r.returncode!=0
    assert 'Extract the entire ZIP' in r.stdout
    assert 'speakercheck' in r.stdout


def test_self_test_option_writes_diagnostic_instead_of_opening_normal_ui(tmp_path):
    shutil.copyfile(LAUNCH,tmp_path/'launch.py')
    pkg=tmp_path/'speakercheck';pkg.mkdir();(pkg/'__init__.py').write_text('')
    (pkg/'ui.py').write_text("def main():\n    raise RuntimeError('normal UI must not start')\n")
    (pkg/'selftest.py').write_text("from pathlib import Path\ndef run_self_test(path):\n    Path(path).write_text('SELF_TEST_OK')\n    return 0\n")
    target=tmp_path/'diagnostic.json'
    r=subprocess.run([sys.executable,'-I',str(tmp_path/'launch.py'),'--self-test',str(target)],cwd=tmp_path,capture_output=True,text=True)
    assert r.returncode==0,r.stdout+r.stderr
    assert target.read_text()=='SELF_TEST_OK'


@pytest.mark.skipif(sys.platform!='win32',reason='requires native cmd.exe')
def test_windows_setup_missing_files_returns_error_without_hanging(tmp_path):
    import os
    root=LAUNCH.parent
    shutil.copyfile(root/'setup.bat',tmp_path/'setup.bat')
    r=subprocess.run([os.environ.get('COMSPEC','cmd.exe'),'/d','/c','call setup.bat --no-pause'],
                     cwd=tmp_path,capture_output=True,text=True,timeout=10)
    assert r.returncode!=0
    assert 'missing' in (tmp_path/'setup.log').read_text(errors='replace').lower()


@pytest.mark.skipif(sys.platform!='win32',reason='requires native cmd.exe')
def test_windows_setup_missing_python_has_actionable_log(tmp_path):
    import os
    root=LAUNCH.parent
    shutil.copyfile(root/'setup.bat',tmp_path/'setup.bat')
    (tmp_path/'speakercheck').mkdir();(tmp_path/'speakercheck/ui.py').write_text('')
    env=os.environ.copy();env['PATH']=str(Path(os.environ['SystemRoot'])/'System32')
    r=subprocess.run([os.environ.get('COMSPEC','cmd.exe'),'/d','/c','call setup.bat --no-pause'],
                     cwd=tmp_path,env=env,capture_output=True,text=True,timeout=20)
    assert r.returncode!=0
    assert '64-bit Python 3.12' in (tmp_path/'setup.log').read_text(errors='replace')
