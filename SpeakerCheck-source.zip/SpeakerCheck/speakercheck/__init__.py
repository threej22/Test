"""SpeakerCheck — SoX based speaker verification."""
__version__ = '0.1.0'
