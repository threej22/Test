# 0.3.0 단일 분석 실행 및 시작 오류 대응

사용자 요청: 자동 녹음·양산 별도 메뉴 제거, WAV 분석의 분석 실행 한 번으로 PC1kHz 출력→녹음→WAV 생성→분석→양불 판정. 기존 자동 로그 유지.

메인은 장치2개/선택 제품번호/분석 실행/결과. 그래프와 중복 측정 카드는 기본 접힘. 상세 녹음/기존파일/이력/안내는 설정 탭. CapturePanel은 보이지 않는 acquisition controller로 재사용하며 메뉴/페이지로 표시하지 않는다. device/product widgets reparent, busy 시 메인 입력카드 잠금. 제품번호가 없으면 TEST ID를 생성하고 serial_source를 로그에 구별. 기본 Spec은 미확인1kHz 프로필이며 사용자 확인 없이 PASS 금지.

기존 WAV 모드는 명시적 설정 checkbox로 유지한다. 기본 분석 실행은 파일 경로 존재 여부와 무관하게 새로 녹음한다. 생성 WAV 경로는 UI source_edit에 signal block으로 기록해 결과를 무효화하지 않는다. 단일 capture worker와 final DB commit/취소/입력 유효성 로직은 유지.

사용자 시작 오류의 Windows 환경은 직접 확인할 수 없다. 기존 ZIP에는 speakercheck 패키지 파일이 포함되어 있었다. 재현한 결함: Python -I/safe-path에서 script directory가 sys.path에 없으면 같은 오류 발생, launch.py만 분리하면 패키지 누락 오류 발생. launch.py가 자신의 경로 기준으로 앱 패키지를 확인·sys.path 등록하며 nested SpeakerCheck 구조도 지원. frozen PyInstaller는 PYZ import를 그대로 사용. 누락 시 전체 압축 해제 안내 및 임시 폴더 시작 로그. ZIP 내부의 중간 wrapper폴더를 제거해 launch.py와패키지의 위치를 명확히 한다. Windows batch에도 패키지 preflight와 인용된 절대 경로 추가.

테스트: safe-path 격리 실행/공백·한국어 경로/중첩구조/패키지 누락, 메인1회click→합성입력→실제SoX→파일/DB/판정, 제품번호없는시험로그, 초기3메뉴/상세숨김/그래프접힘, 장치조회오류표시.
