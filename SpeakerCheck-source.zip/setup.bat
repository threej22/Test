@echo off
setlocal
cd /d "%~dp0"
if not exist "%~dp0speakercheck\ui.py" (
    echo Application folder "speakercheck" is missing.
    echo Extract the entire ZIP into a new folder before running setup.bat.
    pause
    exit /b 1
)
where py >nul 2>nul
if errorlevel 1 (
    echo Python 3.11 or newer is required. Install Python from python.org first.
    pause
    exit /b 1
)
py -3 -c "import sys; assert sys.version_info >= (3,11), 'Python 3.11+ required'"
if errorlevel 1 exit /b 1
if not exist .venv\Scripts\python.exe py -3 -m venv .venv
if errorlevel 1 exit /b 1
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 (
    pause
    exit /b 1
)
echo Setup complete. Run start.bat.
