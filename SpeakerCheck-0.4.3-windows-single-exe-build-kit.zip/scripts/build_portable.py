"""Windows x64 single-EXE build; targets need no sibling DLL/library/SoX files."""
from pathlib import Path
import argparse
import hashlib
import importlib.metadata
import json
import os
import shutil
import struct
import subprocess
import sys
import tempfile
import zipfile


def stage_assets(sox_path,stage,system):
    sox=Path(sox_path).resolve(strict=True)
    if sox.name.lower()!='sox.exe':raise ValueError('Select the actual sox.exe from its original distribution folder.')
    version=subprocess.run([str(sox),'--version'],check=True,capture_output=True,text=True).stdout.strip()
    if 'sox' not in version.lower():raise ValueError('The selected executable is not SoX.')
    bundled=stage/'tools'/'sox';bundled.mkdir(parents=True)
    for pattern in ('sox.exe','*.dll','COPYING*','LICENSE*','README*','AUTHORS*'):
        for file in sox.parent.glob(pattern):
            if file.is_file():shutil.copy2(file,bundled/file.name)
    # Stage BEFORE PyInstaller clears dist, including when SoX is in an older dist.
    for pattern in ('msvcp140*.dll','vcruntime140*.dll','concrt140.dll'):
        for file in system.glob(pattern):
            if file.is_file():shutil.copy2(file,stage/file.name)
    licenses=stage/'licenses';licenses.mkdir()
    python_license=Path(sys.base_prefix)/'LICENSE.txt'
    if python_license.is_file():shutil.copy2(python_license,licenses/'Python-LICENSE.txt')
    versions={}
    for name in ('PySide6','numpy','scipy','matplotlib','sounddevice','pyinstaller'):
        dist=importlib.metadata.distribution(name);versions[name]=dist.version
        for file in dist.files or []:
            text=str(file).replace('\\','/')
            if '.dist-info/' in text and any(x in text.lower() for x in ('license','copying','notice')):
                source=Path(dist.locate_file(file))
                if source.is_file():
                    target=licenses/name/text.split('.dist-info/',1)[1]
                    target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
    (licenses/'components.json').write_text(json.dumps(versions,indent=2),encoding='utf-8')
    (licenses/'SoX-source.txt').write_text(version+'\nhttps://sourceforge.net/projects/sox/files/sox/\nhttps://github.com/chirlu/sox\nSelected SoX and adjacent runtime DLL/license files are bundled inside this EXE.\n',encoding='utf-8')


def verify_exe(exe,system,out):
    with tempfile.TemporaryDirectory(prefix='SpeakerCheck-exe-only-') as folder:
        clean=Path(folder);target=clean/'EXE 하나 실행 확인';target.mkdir()
        copied=target/'SpeakerCheck.exe';shutil.copy2(exe,copied)
        env=os.environ.copy()
        for key in ('PYTHONPATH','PYTHONHOME','SOX_BINARY','QT_PLUGIN_PATH','QT_QPA_PLATFORM_PLUGIN_PATH'):
            env.pop(key,None)
        env['PATH']=str(system)+os.pathsep+str(system.parent)
        for platform in ('offscreen','windows'):
            env['QT_QPA_PLATFORM']=platform
            diagnostic=clean/('diagnostic-'+platform+'.json')
            proc=subprocess.run([str(copied),'--self-test',str(diagnostic)],cwd=clean,env=env,timeout=180)
            result=json.loads(diagnostic.read_text('utf-8')) if diagnostic.exists() else {}
            if proc.returncode or result.get('status')!='ok' or not result.get('frozen') or result.get('pointer_bits')!=64 or result.get('qt_platform')!=platform:
                raise RuntimeError('Single EXE '+platform+' self-test failed: '+json.dumps(result,ensure_ascii=False))
            bundle=Path(result['resource_root']);sox=Path(result['sox_path'])
            if bundle==target or not sox.is_relative_to(bundle/'tools'/'sox'):
                raise RuntimeError('Single EXE self-test did not use its internal extracted SoX.')
            name='portable-diagnostic.json' if platform=='offscreen' else 'portable-windows-gui-diagnostic.json'
            shutil.copy2(diagnostic,out/name)


def checksum(path):
    with path.open('rb') as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
    (path.parent/(path.name+'.sha256')).write_text(digest+'  '+path.name+'\n',encoding='ascii')
    return digest


def build(sox_path):
    if sys.platform!='win32' or struct.calcsize('P')!=8:
        raise RuntimeError('Build requires 64-bit Python running on Windows.')
    root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root))
    from speakercheck import __version__
    if not (root/'examples'/'demo_composite.wav').is_file():
        subprocess.run([sys.executable,str(root/'scripts'/'generate_demo.py')],cwd=root,check=True)
    out=root/'output';out.mkdir(exist_ok=True)
    system=Path(os.environ['SystemRoot'])/'System32'
    with tempfile.TemporaryDirectory(prefix='SpeakerCheck-build-assets-') as folder:
        stage=Path(folder);stage_assets(sox_path,stage,system)
        subprocess.run([sys.executable,'-m','PyInstaller','--noconfirm','--clean','--onefile','--windowed',
            '--name','SpeakerCheck','--hidden-import','sounddevice','--collect-all','_sounddevice_data',
            '--exclude-module','tkinter','--exclude-module','PyQt5','--exclude-module','PyQt6',
            '--add-data',str(stage)+os.pathsep+'.','--add-data',str(root/'examples')+os.pathsep+'examples',
            str(root/'launch.py')],cwd=root,check=True)
    built=root/'dist'/'SpeakerCheck.exe'
    verify_exe(built,system,out)
    final=out/f'SpeakerCheck-{__version__}-windows-x64.exe'
    partial=final.with_suffix('.exe.partial');shutil.copy2(built,partial);partial.replace(final)
    digest=checksum(final)
    archive_path=out/f'SpeakerCheck-{__version__}-windows-x64-single-exe.zip'
    staged_zip=archive_path.with_suffix('.zip.partial')
    with zipfile.ZipFile(staged_zip,'w',zipfile.ZIP_DEFLATED) as archive:
        archive.write(final,'SpeakerCheck.exe')
    with zipfile.ZipFile(staged_zip) as archive:
        if archive.testzip() or archive.namelist()!=['SpeakerCheck.exe']:
            raise RuntimeError('Single EXE ZIP validation failed.')
    staged_zip.replace(archive_path);checksum(archive_path)
    print(json.dumps({'exe':str(final),'zip':str(archive_path),'sha256':digest,'size':final.stat().st_size}))


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--sox');args=parser.parse_args()
    if not args.sox:
        from PySide6.QtWidgets import QApplication,QFileDialog
        app=QApplication.instance() or QApplication([])
        args.sox,_=QFileDialog.getOpenFileName(None,'EXE 안에 포함할 기존 sox.exe 선택','','SoX (sox.exe)')
        if not args.sox:raise RuntimeError('Build canceled: no sox.exe was selected.')
    build(args.sox)
