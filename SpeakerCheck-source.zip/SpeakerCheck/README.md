# SpeakerCheck

SoX(sox.exe) 기반 **Windows 데스크톱 WAV 스피커 검증 도구**입니다. 한국어 UI에서 WAV를 선택하고 제품 Spec과 비교해 항목별·최종 PASS/NG를 표시합니다.

## Windows에서 실행

1. Python **3.11 이상(64 bit)**을 설치합니다. Python Launcher(`py`)도 설치하세요.
2. 이 폴더에서 `setup.bat`를 실행합니다. 최초 설치 시 인터넷이 필요합니다.
3. `start.bat`를 실행합니다.
4. **설정 · 측정 안내**에서 설치한 `sox.exe`를 선택합니다. 또는 SoX 배포본 전체를 `tools/sox/`에 놓습니다(sox.exe와 DLL 포함).
5. **Spec 관리**에서 실제 제품 기준과 사용 항목을 설정하고 Spec을 확인합니다.
6. WAV와 측정 구간을 지정하고 **분석 실행**을 누릅니다. JSON 또는 CSV로 저장할 수 있습니다.

SoX는 별도 설치가 필요하며 배포 파일에 포함하지 않습니다. 공식 프로젝트: https://sourceforge.net/projects/sox/

## 빠른 시연

**합성 샘플 열기 → 분석 실행**을 누릅니다. SoX 경로가 먼저 설정되어야 합니다.

- 신호: 0~1초, 단일 톤 1000 Hz
- 무음: 1~2초
- 주파수 응답: 2~4초, `demo_reference.wav`와 비교
- 교정 offset: 110 dB, **시연용 수치이며 실제 장비 교정값이 아닙니다.**
- `demo_ng.wav`로 DUT만 바꾸면 THD·좌우차 NG를 볼 수 있습니다.

초기 Spec은 **EXAMPLE**입니다. 제품 기준을 확인하기 전에는 최종 `SPEC REQUIRED`를 표시합니다. 샘플의 항목별 PASS는 실제 스피커의 품질 인증이 아닙니다.

## 검사 항목

| 항목 | 측정 방법 / 필요 조건 |
|---|---|
| RMS | 신호 구간 채널별 RMS, dBFS |
| Peak | 파일 전체 채널별 최대 절대 레벨, dBFS |
| 클리핑 근접 표본 | 전체 파일에서 `abs(x) >= 1-1/32768`인 비율. 아날로그 clipping 검출 기능은 아님 |
| THD | 정상상태 단일 톤, 지정 주파수 ±2% 추정, 2~5차 harmonic 동시 적합. 20 Hz 이상·fs/10 미만. 앞 1초까지 사용 |
| 노이즈 | 신호와 겹치지 않는 별도 무음 구간 RMS, dBFS |
| SNR | `10 log10((P_signal-P_noise)/P_noise)`, 무가중 전체 대역. 디지털 0 무음은 측정 불가 |
| 좌우차 | 2채널 신호 RMS 레벨 차이의 절댓값 |
| SPL | RMS(dBFS) + 교정 offset. 동일 마이크/게인/경로 필요. 모든 채널에 같은 offset 적용, Z/무가중 |
| 주파수 응답 | 기준 WAV 대비 Welch PSD 비율, 1/6 octave 대역. 광대역 기준·동일 sample rate 필요. 주파수별 상·하한 |

THD용 단일 톤과 주파수 응답용 광대역은 서로 다른 신호입니다. 하나의 WAV에 결합했다면 **응답 구간 별도 지정**을 사용하세요. 응답 비교의 같은 구간이 기준 WAV에도 적용됩니다. 두 녹음은 같은 시험 조건/시간 구성이어야 합니다. 위상·지연·sweep deconvolution·마이크 주파수 EQ는 지원하지 않습니다.

SPL 교정: 알려진 교정기 음압이 94 dB SPL이고 동일 체인의 교정 녹음 RMS가 -20 dBFS이면 offset은 114 dB입니다. dBFS 자체를 dB SPL로 취급하면 안 됩니다. A/C 가중치는 적용하지 않습니다.

## 판정 규칙

- `PASS`: 활성 항목 모두 측정됨 + 모든 한계 이내 + 제품 Spec 확인됨.
- `NG`: 활성 항목 하나 이상이 한계를 벗어남.
- `INCOMPLETE`: 활성 항목이 없거나 필수 항목 측정 불가. 다른 항목에 NG가 있으면 최종 NG.
- `SPEC REQUIRED`: 제품 Spec 미확인. 이 상태에서도 항목별 NG는 표에 표시됩니다.
- `SKIP`: Spec에서 사용하지 않는 항목.

상·하한은 경계값을 포함합니다. 다채널 항목은 모든 채널이 기준을 만족해야 합니다. 응답은 대역별 최악 채널 값을 표시하며 나머지 항목은 채널별 값을 보존합니다. Spec 한계값을 수정하면 제품 Spec 확인이 해제됩니다.

## 결과와 입력 제한

JSON: 파일 경로·SHA256·SoX 버전/원본 통계·Spec·교정/구간·측정값·그래프 데이터·판정.
CSV: Excel 호환 UTF-8 BOM, 채널/주파수별 측정값과 기준 및 사유. 항목의 모든 행에 항목 전체의 판정을 표시합니다.

입력/Spec 변경 시 이전 결과가 무효화됩니다. 분석 중 설정은 잠기며 종료 후 창을 닫을 수 있습니다. 녹음 중인 파일 대신 완성된 파일을 사용하세요. 분석 중 원본이 바뀌면 오류 처리합니다.

RIFF/RIFX/RF64 WAV, 1~32채널, 1~768 kHz, 최소 32표본, 파일 및 float64 디코딩 크기 각각 최대 512 MiB입니다. SoX 각 명령 제한 시간은 60초입니다. PCM 16/24 bit와 정규화 float 입력을 검증했습니다. float 원본은 유한하고 -1~+1 범위여야 하며 NaN/Inf/초과 표본은 거부합니다. SoX 내부 표본 정밀도(일반적으로 32 bit)의 영향을 받으므로 디지털 극저레벨 측정용으로 사용하기 전 검증이 필요합니다.

## EXE 빌드

Windows에서 `build_windows.bat`를 실행하면 PyInstaller로 `dist/SpeakerCheck/SpeakerCheck.exe`를 만듭니다. **dist/SpeakerCheck 폴더 전체**를 배포하세요. `tools/sox/`가 있으면 배포 폴더로 복사합니다. SoX 재배포 시 해당 라이선스 조건을 확인하세요.

이 프로젝트는 Linux에서 실제 SoX와 Qt offscreen으로 검증했습니다. **Windows EXE는 빌드하거나 Windows 실기기에서 실행 검증하지 않았습니다.** `setup.bat`, `start.bat`, `build_windows.bat`는 Windows용으로 제공됩니다.

## 개발 및 검증

```bash
python -m pip install -r requirements-dev.txt
# sox를 PATH에 넣거나 SOX_BINARY 환경 변수에 전체 경로 지정
python -m pytest tests -q
python -m speakercheck
```

Linux CI에서는 `QT_QPA_PLATFORM=offscreen`을 지정할 수 있습니다. 샘플 재생성: `python scripts/generate_demo.py`. 화면 및 보고서 생성: `python scripts/preview.py`(SoX 필요).

구조: `sox.py` 실행/디코딩, `analysis.py` 계산, `spec.py` 검증/판정, `report.py` 저장, `ui.py` 화면, `spec_editor.py` 기준 편집, `plots.py` 그래프. 설계/검증 기록은 `docs/`에 있습니다.
