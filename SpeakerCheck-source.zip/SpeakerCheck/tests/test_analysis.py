import numpy as np
import pytest
from speakercheck.analysis import analyze_pcm, AnalysisSettings
from speakercheck.spec import default_spec

FS = 48000

def tone(f=1000, amp=.1, sec=1):
    return amp*np.sin(2*np.pi*f*np.arange(int(FS*sec))/FS)


def test_known_stereo_levels_and_balance():
    x = np.column_stack([tone(amp=.1), tone(amp=.05)])
    r = analyze_pcm(x, FS, AnalysisSettings(), default_spec())
    assert r.metrics['rms_dbfs'] == pytest.approx([-23.0103, -29.0309], abs=.002)
    assert r.metrics['peak_dbfs'] == pytest.approx([-20, -26.0206], abs=.002)
    assert r.metrics['balance_db'] == pytest.approx(6.0206, abs=.002)
    assert r.metrics['spl_db'] is None
    assert r.metrics['thd_percent'] is None


def test_known_thd_off_bin_and_calibrated_spl():
    x = tone(f=1000.37, amp=.2) + tone(f=2000.74, amp=.002)
    r = analyze_pcm(x[:, None], FS, AnalysisSettings(tone_hz=1000, calibration_db=110), default_spec())
    assert r.metrics['thd_percent'][0] == pytest.approx(1., abs=.04)
    assert r.metrics['spl_db'][0] == pytest.approx(93.0107, abs=.01)


def test_noise_segment_and_snr_are_distinct():
    rng = np.random.default_rng(7)
    x = np.r_[tone(amp=.1), rng.normal(0, .001, FS)]
    settings = AnalysisSettings(signal_end=1, noise_start=1, noise_end=2)
    r = analyze_pcm(x[:, None], FS, settings, default_spec())
    assert r.metrics['noise_dbfs'][0] == pytest.approx(-60., abs=.1)
    assert r.metrics['snr_db'][0] == pytest.approx(36.99, abs=.15)


def test_overlap_noise_and_mono_do_not_fake_metrics():
    s = AnalysisSettings(signal_end=1, noise_start=.5, noise_end=1)
    r = analyze_pcm(tone()[:, None], FS, s, default_spec())
    assert r.metrics['snr_db'] is None
    assert r.metrics['noise_dbfs'] is None
    assert r.metrics['balance_db'] is None


def test_silence_and_clipping():
    r = analyze_pcm(np.zeros((FS, 1)), FS, AnalysisSettings(tone_hz=1000), default_spec())
    assert r.metrics['rms_dbfs'] is None
    assert r.metrics['thd_percent'] is None
    x = np.full((FS, 1), .2)
    x[0] = 1
    r = analyze_pcm(x, FS, AnalysisSettings(), default_spec())
    assert r.metrics['clip_percent'] == pytest.approx([100/FS])


def test_broadband_reference_gain_and_tone_rejection():
    rng = np.random.default_rng(5)
    ref = rng.normal(0, .05, (FS*2, 1))
    s = AnalysisSettings()
    r = analyze_pcm(ref*.5, FS, s, default_spec(), reference=ref)
    assert r.metrics['response_db'] == pytest.approx([-6.0206]*len(default_spec()['response_points']), abs=.05)
    r = analyze_pcm(tone()[:, None], FS, s, default_spec(), reference=tone()[:, None])
    assert r.metrics['response_db'][0] is None


def test_invalid_signal_range_rejected():
    with pytest.raises(ValueError):
        analyze_pcm(tone()[:,None], FS, AnalysisSettings(signal_start=2), default_spec())


def test_broadband_not_accepted_as_thd_tone():
    x = np.random.default_rng(1).normal(0,.05,(FS,1))
    r = analyze_pcm(x, FS, AnalysisSettings(tone_hz=1000), default_spec())
    assert r.metrics['thd_percent'] is None


def test_separate_response_interval_supports_composite_test():
    rng = np.random.default_rng(17)
    broad = rng.normal(0,.05,FS*2)
    x = np.r_[tone(amp=.1), rng.normal(0,.0001,FS), broad]
    ref = np.r_[tone(amp=.1), rng.normal(0,.0001,FS), broad]
    settings = AnalysisSettings(signal_end=1, noise_start=1, noise_end=2,
                                tone_hz=1000, calibration_db=110,
                                response_start=2, response_end=4)
    r = analyze_pcm(x[:,None],FS,settings,default_spec(),reference=ref[:,None])
    assert r.metrics['response_db'] == pytest.approx([0.]*8, abs=.001)
    assert r.metrics['thd_percent'][0] < .01
