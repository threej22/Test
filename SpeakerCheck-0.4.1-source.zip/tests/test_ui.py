import os
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
import time
import numpy as np
import pytest
from scipy.io import wavfile
from PySide6.QtWidgets import QApplication
from speakercheck.ui import MainWindow

@pytest.fixture(scope='module')
def app():
    return QApplication.instance() or QApplication([])


def test_real_async_measurement_and_stale_export_invalidation(app, tmp_path):
    path = tmp_path/'test.wav'
    t = np.arange(48000)/48000
    wavfile.write(path,48000,(np.sin(2*np.pi*1000*t)*3000).astype(np.int16))
    w = MainWindow()
    w.sox_edit.setText(os.environ.get('SOX_BINARY','sox'))
    w.source_edit.setText(str(path))
    w.existing_file_check.setChecked(True)
    w.start_analysis()
    assert not w.sox_card.isEnabled()
    deadline = time.monotonic()+15
    while w.worker is not None and time.monotonic() < deadline:
        app.processEvents()
        time.sleep(.01)
    assert w.report is not None
    assert w.result_table.rowCount() == 9
    assert w.report['verdict'] == 'SPEC REQUIRED'
    assert w.export_json_button.isEnabled()
    w.signal_start.setValue(.1)
    assert w.report is None
    assert not w.export_json_button.isEnabled()
    assert w.result_table.rowCount() == 0
    w.close()


def test_limit_edit_resets_confirmation(app):
    w = MainWindow()
    w.spec_editor.confirmed.setChecked(True)
    w.spec_editor.table.item(0,2).setText('-40')
    assert not w.spec_editor.confirmed.isChecked()
    assert w.spec_editor.read_spec()['metrics']['rms_dbfs']['lower'] == -40
    w.close()


def test_confirm_toggle_invalidates_existing_report(app):
    w = MainWindow()
    w.spec_editor.confirmed.setChecked(True)
    from pathlib import Path
    from speakercheck.sox import SoxEngine
    from speakercheck.report import make_report
    from speakercheck.analysis import AnalysisSettings
    from speakercheck.spec import default_spec
    base = Path(__file__).resolve().parents[1]/'examples'
    spec = default_spec()
    spec['confirmed'] = True
    report = make_report(SoxEngine(os.environ.get('SOX_BINARY','sox')),base/'demo_composite.wav',
        AnalysisSettings(signal_end=1,noise_start=1,noise_end=2,tone_hz=1000,calibration_db=110,response_start=2,response_end=4),
        spec,base/'demo_reference.wav')
    w.show_report(report)
    assert w.report['verdict'] == 'PASS'
    w.spec_editor.confirmed.setChecked(False)
    assert w.report is None
    assert not w.export_json_button.isEnabled()
    w.close()


def test_imported_limits_keep_full_precision(app):
    from speakercheck.spec import default_spec, evaluate
    w = MainWindow()
    spec = default_spec()
    spec['confirmed'] = True
    for key,r in spec['metrics'].items():
        r['enabled'] = key == 'rms_dbfs'
    spec['metrics']['rms_dbfs']['lower'] = -23.01029995
    w.spec_editor.set_spec(spec)
    restored = w.spec_editor.read_spec()
    assert evaluate(restored, {'rms_dbfs':[-23.010299956639813]})[1] == 'NG'
    w.close()


def test_measurement_inputs_and_chart_fit_visible_widgets(app):
    w = MainWindow()
    w.navigate(0)
    w.show()
    app.processEvents()
    assert w.signal_end.lineEdit().width() >= 80
    w.graph_toggle.click()
    app.processEvents()
    assert w.plots['waveform'].height() < w.plot_tabs.height()
    w.close()


def test_production_ui_capture_to_sox_to_durable_history(app,tmp_path):
    from test_capture import SyntheticBackend
    from speakercheck.audio import one_khz_spec
    from speakercheck.spec import default_spec
    w=MainWindow()
    panel=w.capture_panel
    panel.backend=SyntheticBackend()
    panel.input_combo.addItem('DEVICE USB INPUT',2);panel.input_combo.setCurrentIndex(1)
    panel.output_combo.addItem('PC SPEAKER OUTPUT',3);panel.output_combo.setCurrentIndex(1)
    panel.serial_edit.setText('SN-BARCODE-01')
    panel.directory_edit.setText(str(tmp_path))
    panel.duration.setValue(.2);panel.settle.setValue(.05)
    spec=one_khz_spec(default_spec(),1,False,False);spec['confirmed']=True
    w.spec_editor.set_spec(spec)
    w.sox_edit.setText(os.environ.get('SOX_BINARY','sox'))
    panel.start_capture()
    assert w.worker is not None
    assert not panel.record_button.isEnabled()
    assert panel.stop_button.isEnabled()
    deadline=time.monotonic()+15
    while w.worker is not None and time.monotonic()<deadline:
        app.processEvents();time.sleep(.01)
    assert w.report is not None
    assert w.report['verdict']=='PASS'
    assert w.report['production']['serial']=='SN-BARCODE-01'
    assert panel.history_table.rowCount()==1
    assert panel.history_rows[0]['state']=='PASS'
    w.close()


def test_production_verdict_invalidated_by_new_product(app):
    w=MainWindow()
    w.capture_panel.test_verdict.setText('PASS')
    w.capture_panel.serial_edit.setText('NEXT-PRODUCT')
    assert w.capture_panel.test_verdict.text()=='READY'
    w.close()


def test_escape_stops_continuous_tone_without_recording(app):
    from PySide6.QtTest import QTest
    from PySide6.QtCore import Qt
    from test_capture import SyntheticBackend
    w=MainWindow();p=w.capture_panel;p.backend=SyntheticBackend()
    p.input_combo.addItem('INPUT',2);p.input_combo.setCurrentIndex(1)
    p.output_combo.addItem('OUTPUT',3);p.output_combo.setCurrentIndex(1)
    w.show();app.processEvents()
    p.toggle_tone()
    assert p.tone.active
    QTest.keyClick(w,Qt.Key.Key_Escape);app.processEvents()
    assert not p.tone.active
    w.close()


@pytest.mark.parametrize('noise',[False,True])
def test_single_analysis_button_records_creates_wav_and_logs_without_product_number(app,tmp_path,noise):
    from test_capture import SyntheticBackend
    from speakercheck.audio import one_khz_spec
    from speakercheck.spec import default_spec
    from pathlib import Path
    w=MainWindow();p=w.capture_panel;p.backend=SyntheticBackend()
    p.input_combo.addItem('DEVICE INPUT',2);p.input_combo.setCurrentIndex(1)
    p.output_combo.addItem('PC OUTPUT',3);p.output_combo.setCurrentIndex(1)
    p.directory_edit.setText(str(tmp_path));p.duration.setValue(.2);p.settle.setValue(.05)
    w.sox_edit.setText(os.environ.get('SOX_BINARY','sox'))
    spec=one_khz_spec(default_spec(),1,False,False);spec['confirmed']=True;w.spec_editor.set_spec(spec)
    w.inspection_mode.setCurrentIndex(int(noise))
    w.show();app.processEvents()
    assert w.pages.count()==3
    assert w.pages.currentIndex()==0
    assert w.run_button.isVisible()
    assert not w.conditions.isVisible()
    assert not any('양산' in b.text() or '자동 녹음' in b.text() for b in w.nav_buttons)
    w.run_button.click()
    assert w.worker is not None
    deadline=time.monotonic()+15
    while w.worker is not None and time.monotonic()<deadline:
        app.processEvents();time.sleep(.01)
    assert w.report is not None
    assert w.report['verdict']=='PASS'
    assert Path(w.report['source']['path']).is_file()
    assert p.history_rows[0]['state']=='PASS'
    assert w.report['production']['capture']['serial_source']=='generated_test_id'
    assert w.verdict_label.text()=='PASS'
    assert w.report['final_result']=='PASS'
    assert w.report['spec']['metrics']['balance_db']['enabled']
    assert w.report['spec']['metrics']['noise_dbfs']['enabled']==noise
    assert w.report['plots']['comparison']['provenance']['gain_normalized'] is False
    assert len(w.report['plots']['comparison']['input'])==2
    w.graph_toggle.click();app.processEvents()
    assert w.graph_panel.height()>=430
    assert len(w.plots['waveform'].ax.lines)==3
    assert w.plots['waveform'].ax.get_xlim()[1]<=5
    w.close()


def test_device_refresh_failure_is_visible_on_main_screen(app):
    class BrokenBackend:
        def query_devices(self):
            raise OSError('driver unavailable')
    w=MainWindow();w.capture_panel.backend=BrokenBackend()
    w.capture_panel.refresh_devices()
    assert 'driver unavailable' in w.status.text()
    w.close()


def test_main_keeps_graphs_collapsed_until_requested(app):
    w=MainWindow();w.show();app.processEvents()
    assert not w.plot_tabs.isVisible()
    w.graph_toggle.click();app.processEvents()
    assert w.plot_tabs.isVisible()
    w.close()


def test_simple_main_has_modes_and_devices_only_in_settings(app):
    w=MainWindow();w.show();app.processEvents();p=w.capture_panel
    assert p.input_channels.currentData()==2
    assert not p.input_combo.isVisible() and not p.output_combo.isVisible()
    assert not p.serial_edit.isVisible()
    assert w.inspection_mode.count()==2 and w.inspection_mode.isVisible()
    w.inspection_mode.setCurrentIndex(1)
    assert p.noise_check.isChecked()
    w.navigate(2);app.processEvents()
    assert p.input_combo.isVisible() and p.output_combo.isVisible()
    w.analysis_error('test failure')
    assert w.verdict_label.text()=='FAIL'
    w.close()


def test_mono_configuration_cannot_bypass_required_balance(app,tmp_path):
    w=MainWindow();p=w.capture_panel
    p.input_combo.addItem('INPUT',2);p.input_combo.setCurrentIndex(1)
    p.output_combo.addItem('OUTPUT',3);p.output_combo.setCurrentIndex(1)
    p.input_channels.setCurrentIndex(0);p.directory_edit.setText(str(tmp_path))
    w.run_button.click()
    assert w.worker is None and w.verdict_label.text()=='FAIL'
    assert '2채널' in w.verdict_caption.text()
    w.close()


def test_expanded_comparison_chart_is_not_clipped(app):
    w=MainWindow();w.resize(1440,1080);w.show();w.graph_toggle.click();app.processEvents()
    assert w.graph_panel.height()>=430
    assert w.plots['waveform'].height()>=210
    w.close()


def test_graph_unfold_does_not_accumulate_height(app):
    from pathlib import Path
    from speakercheck.sox import SoxEngine
    from speakercheck.report import make_report
    from speakercheck.analysis import AnalysisSettings
    from speakercheck.spec import default_spec
    root=Path(__file__).resolve().parents[1]
    report=make_report(SoxEngine(os.environ.get('SOX_BINARY','sox')),root/'examples/demo_composite.wav',AnalysisSettings(signal_end=1,tone_hz=1000),default_spec())
    w=MainWindow();w.resize(1440,900);w.show_report(report);w.show()
    heights=[]
    for _ in range(12):
        w.graph_toggle.setChecked(True)
        for _ in range(10):app.processEvents()
        heights.append(w.plots['waveform'].height())
        w.graph_toggle.setChecked(False)
        for _ in range(3):app.processEvents()
    assert max(heights)-min(heights)<=2,heights
    w.close()


def test_capture_pass_cannot_override_error_in_same_stored_run(app,tmp_path):
    from pathlib import Path
    from speakercheck.sox import SoxEngine
    from speakercheck.report import make_report
    from speakercheck.analysis import AnalysisSettings
    from speakercheck.spec import default_spec
    from speakercheck.production import ProductionStore
    spec=default_spec();spec['confirmed']=True
    report=make_report(SoxEngine(os.environ.get('SOX_BINARY','sox')),Path(__file__).resolve().parents[1]/'examples/demo_composite.wav',AnalysisSettings(tone_hz=1000,signal_end=1),spec)
    report['verdict']='PASS';report['capture']={'plan':{}}
    store=ProductionStore(tmp_path);run=store.begin('TEST','op','station',{})
    store.finish(run['run_id'],'ERROR',None,'Error opening InputStream')
    report['production']={'database':str(store.path),'run_id':run['run_id']}
    w=MainWindow();w.show_report(report)
    assert w.verdict_label.text()=='FAIL'
    assert w.report is None and not w.export_json_button.isEnabled()
    assert 'ERROR' in w.verdict_caption.text()
    w.close()


def test_friendly_device_selection_and_saved_names_survive_refresh(app,tmp_path):
    from PySide6.QtCore import QSettings
    from test_devices import DeviceBackend
    w=MainWindow();p=w.capture_panel;p.backend=DeviceBackend()
    p.device_settings=QSettings(str(tmp_path/'devices.ini'),QSettings.Format.IniFormat)
    p.refresh_devices()
    assert p.input_combo.count()==2 and p.output_combo.count()==2
    assert p.input_combo.currentData()==2 and p.output_combo.currentData()==3
    p.save_device_choices()
    p.input_combo.setCurrentIndex(0);p.output_combo.setCurrentIndex(0)
    p.refresh_devices()
    assert p.input_combo.currentData()==2 and p.output_combo.currentData()==3
    assert p.output_check_button.text().startswith('스피커')
    assert p.input_check_button.text().startswith('입력')
    w.close()


def test_output_check_needs_no_mic_and_stops_automatically(app):
    from test_capture import SyntheticBackend
    w=MainWindow();p=w.capture_panel;p.backend=SyntheticBackend()
    p.output_combo.addItem('PC SPEAKER',3);p.output_combo.setCurrentIndex(p.output_combo.count()-1)
    p.test_output()
    assert p.tone.active and p._output_probe
    assert not w.run_button.isEnabled()
    p.output_check_timer.start(30)
    deadline=time.monotonic()+2
    while p._output_probe and time.monotonic()<deadline:app.processEvents();time.sleep(.01)
    assert not p.tone.active and not p._output_probe and w.run_button.isEnabled()
    assert w.verdict_label.text()!='PASS'
    w.close()


def test_input_open_error_after_pass_clears_result_and_matches_history(app,tmp_path):
    from test_capture import SyntheticBackend
    from speakercheck.spec import default_spec
    from speakercheck.production import ProductionStore
    w=MainWindow();p=w.capture_panel;p.backend=SyntheticBackend()
    for combo,index in ((p.input_combo,2),(p.output_combo,3)):
        combo.addItem('DEVICE',index);combo.setCurrentIndex(combo.count()-1)
    p.directory_edit.setText(str(tmp_path));p.duration.setValue(.2);p.settle.setValue(.05)
    spec=default_spec();spec['confirmed']=True;w.spec_editor.set_spec(spec)
    w.sox_edit.setText(os.environ.get('SOX_BINARY','sox'))
    w.start_analysis()
    deadline=time.monotonic()+15
    while w.worker is not None and time.monotonic()<deadline:app.processEvents();time.sleep(.01)
    assert w.verdict_label.text()=='PASS'
    previous=w.report
    class BrokenInput(SyntheticBackend):
        def InputStream(self,**kwargs):raise OSError('Error opening InputStream: unanticipated host error')
    p.backend=BrokenInput();w.start_analysis()
    deadline=time.monotonic()+15
    while w.worker is not None and time.monotonic()<deadline:app.processEvents();time.sleep(.01)
    assert w.verdict_label.text()=='FAIL' and w.report is None
    assert w.result_table.rowCount()==0 and not w.export_json_button.isEnabled()
    latest=ProductionStore(tmp_path).history()[0]
    assert latest['state']=='ERROR' and w.current_run_id==latest['run_id']
    assert latest['run_id'] in w.run_identity.text()
    assert 'unanticipated host error' in w.verdict_caption.text()
    w.show_report(previous)
    assert w.verdict_label.text()=='FAIL'  # queued/cached previous PASS cannot replace current ERROR.
    p.find_current_run()
    assert p.history_rows[p.history_table.currentRow()]['run_id']==latest['run_id']
    assert p.history_table.item(p.history_table.currentRow(),2).text()=='FAIL'
    w.close()
