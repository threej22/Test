# SpeakerCheck Implementation Plan

> 실행: 이 세션에서 직접 구현하고 전체 검증 후 리뷰한다.

**Goal:** SoX 기반 WAV 스피커 판정 데스크톱 도구.
**Architecture:** SoX adapter → scientific analysis → strict Spec evaluation → Qt UI/report.
**Tech Stack:** Python, PySide6, NumPy, SciPy, Matplotlib.
**Spec:** design.md

## Global Constraints
- Windows sox.exe 지원, shell=False, 실제 Spec을 임의로 제품 기준이라 주장하지 않는다.
- 측정 불가 항목이 있으면 최종 PASS 금지.

## Review Focus
- 비 ASCII/공백 파일 경로, 오류/타임아웃: SoX 통합 테스트.
- 무음/clip/mono/비동기 UI: 분석 및 offscreen Qt 테스트.
- float WAV와 invalid/oversized WAV: decoder 검증.
- Spec NaN/역전 범위/unknown keys: schema 검증.
- 설정 변경 후 stale result export: UI 검증.

## Tasks
- [x] 1. tests/test_analysis.py, tests/test_spec.py: known RMS/THD/SNR/FR, missing conditions, malformed bounds. RED → implement spec.py/analysis.py → GREEN.
- [x] 2. tests/test_sox.py: actual SoX PCM/float, unicode, invalid file. RED → implement sox.py/report.py → GREEN.
- [x] 3. tests/test_ui.py: actual offscreen Qt measurement/export invalidation. RED → implement ui.py/styles.py/__main__.py → GREEN.
- [x] 4. README, requirements, launch/build scripts, examples. Run all tests, generate screenshots, zip deliverable and record limitations.
