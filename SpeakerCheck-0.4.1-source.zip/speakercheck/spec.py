"""Validated measurement limits and conservative aggregate verdicts."""
from copy import deepcopy
import math

METRICS = {
    'rms_dbfs': ('RMS 레벨', 'dBFS', -35., -10.),
    'peak_dbfs': ('Peak 레벨', 'dBFS', None, -1.),
    'clip_percent': ('클리핑 근접 표본', '%', None, 0.),
    'thd_percent': ('THD · 2–5차', '%', None, 3.),
    'noise_dbfs': ('무음 노이즈', 'dBFS', None, -55.),
    'snr_db': ('SNR', 'dB', 35., None),
    'balance_db': ('좌우 레벨 차이', 'dB', None, 1.5),
    'spl_db': ('음압 · Z / 무가중', 'dB SPL', 75., 95.),
    'response_db': ('기준 대비 주파수 응답', 'dB', -3., 3.),
}


def default_spec():
    return {'version': 1, 'name': 'EXAMPLE · 제품 기준으로 수정', 'confirmed': False,
            'metrics': {k: {'enabled': True, 'lower': v[2], 'upper': v[3]} for k, v in METRICS.items()},
            'response_points': [{'hz': f, 'lower': -3., 'upper': 3.} for f in [100, 200, 500, 1000, 2000, 5000, 10000, 16000]]}


def _number(x):
    return isinstance(x, (float, int)) and not isinstance(x, bool) and math.isfinite(x)


def _bounds(rule):
    lo, hi = rule.get('lower'), rule.get('upper')
    if lo is None and hi is None:
        raise ValueError('하한 또는 상한을 입력하세요.')
    if any(x is not None and not _number(x) for x in (lo, hi)):
        raise ValueError('Spec 한계는 유한한 숫자여야 합니다.')
    if lo is not None and hi is not None and lo > hi:
        raise ValueError('Spec 하한이 상한보다 큽니다.')


def validate_spec(spec):
    if not isinstance(spec, dict) or spec.get('version') != 1:
        raise ValueError('지원하지 않는 Spec 형식입니다.')
    if not isinstance(spec.get('name'), str) or not spec['name'].strip():
        raise ValueError('Spec 이름을 입력하세요.')
    if type(spec.get('confirmed')) is not bool:
        raise ValueError('Spec 확인 상태가 잘못되었습니다.')
    if not isinstance(spec.get('metrics'), dict) or set(spec['metrics']) != set(METRICS):
        raise ValueError('Spec 검사 항목이 누락되었거나 알 수 없는 항목이 있습니다.')
    for rule in spec['metrics'].values():
        if not isinstance(rule, dict) or set(rule) != {'enabled', 'lower', 'upper'} or type(rule['enabled']) is not bool:
            raise ValueError('Spec 항목 형식이 잘못되었습니다.')
        _bounds(rule)
    pts = spec.get('response_points')
    if not isinstance(pts, list) or not 1 <= len(pts) <= 200:
        raise ValueError('응답 기준점을 1~200개 입력하세요.')
    previous = 0
    for p in pts:
        if not isinstance(p, dict) or set(p) != {'hz', 'lower', 'upper'} or not _number(p['hz']) or p['hz'] <= previous:
            raise ValueError('응답 주파수는 양수이며 오름차순이고 중복이 없어야 합니다.')
        previous = p['hz']
        _bounds(p)
    return deepcopy(spec)


def evaluate(spec, metrics, reasons=None):
    spec = validate_spec(spec)
    rows = []
    reasons = reasons or {}
    for key, rule in spec['metrics'].items():
        value = metrics.get(key)
        vals = value if isinstance(value, (list, tuple)) else [value]
        limits = spec['response_points'] if key == 'response_db' else [rule]*len(vals)
        missing = not vals or len(vals) != len(limits) or any(not _number(v) for v in vals)
        fail = any(_number(v) and ((r['lower'] is not None and v < r['lower']) or
                   (r['upper'] is not None and v > r['upper'])) for v, r in zip(vals, limits))
        status = 'SKIP' if not rule['enabled'] else 'NG' if fail else 'UNAVAILABLE' if missing else 'PASS'
        if status == 'UNAVAILABLE':
            reason = reasons.get(key, '필수 측정 조건 또는 유효한 측정값이 없습니다.')
        elif status == 'NG':
            failed = []
            for i, (v, r) in enumerate(zip(vals, limits)):
                if _number(v) and ((r['lower'] is not None and v < r['lower']) or (r['upper'] is not None and v > r['upper'])):
                    label = f"{r['hz']:g} Hz" if key == 'response_db' else f'CH{i+1}'
                    failed.append(f'{label} {v:.3f}')
            reason = '허용 범위 벗어남: ' + ', '.join(failed)
        else:
            reason = '사용 안 함' if status == 'SKIP' else '설정한 허용 범위 이내'
        rows.append({'key': key, 'name': METRICS[key][0], 'unit': METRICS[key][1],
                     'value': value, 'lower': rule['lower'], 'upper': rule['upper'],
                     'status': status, 'reason': reason})
    active = [r for r in rows if r['status'] != 'SKIP']
    verdict = ('NG' if any(r['status'] == 'NG' for r in active) else
               'INCOMPLETE' if not active or any(r['status'] == 'UNAVAILABLE' for r in active) else 'PASS')
    if not spec['confirmed']:
        verdict = 'SPEC REQUIRED'
    return rows, verdict


def inspection_spec(spec, noise=False):
    """The two automatic inspection modes share the same mandatory checks."""
    result=validate_spec(spec)
    required={'balance_db','rms_dbfs','peak_dbfs','clip_percent','thd_percent'}
    for key,rule in result['metrics'].items():
        rule['enabled']=key in required or (noise and key=='noise_dbfs')
    return result
