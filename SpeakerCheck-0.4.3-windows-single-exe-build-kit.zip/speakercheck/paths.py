"""Read-only bundled resources; user recordings/logs live outside this directory."""
from pathlib import Path
import sys


def resource_root():
    if getattr(sys,'frozen',False):
        return Path(getattr(sys,'_MEIPASS',Path(sys.executable).parent))
    return Path(__file__).resolve().parent.parent
