"""Snapshot reports preserve the exact limits and measurement conditions."""
import csv
import json
from datetime import datetime, timezone
from pathlib import Path
from . import __version__
from .analysis import analyze_pcm


def _source(audio):
    return {'path': audio.path, 'sha256': audio.sha256, 'sample_rate': audio.rate,
            'channels': audio.samples.shape[1], 'bits': audio.bits,
            'frames': len(audio.samples), 'duration_seconds': len(audio.samples)/audio.rate,
            'sox_stats': audio.sox_stats}


def make_report(engine, path, settings, spec, reference=None):
    audio = engine.read(path)
    ref = engine.read(reference) if reference else None
    if ref is not None and ref.rate != audio.rate:
        raise ValueError('DUT와 기준 WAV의 샘플레이트가 다릅니다.')
    result = analyze_pcm(audio.samples, audio.rate, settings, spec,
                         reference=ref.samples if ref else None)
    return {'schema_version': 1, 'app_version': __version__,
            'created_utc': datetime.now(timezone.utc).isoformat(),
            'source': _source(audio), 'reference': _source(ref) if ref else None,
            'sox': {'executable': engine.executable, 'version': engine.version},
            'spec': result.spec, 'settings': result.settings,
            'final_result': 'PASS' if result.verdict=='PASS' else 'FAIL',
            'verdict': result.verdict, 'metrics': result.metrics,
            'rows': result.rows, 'reasons': result.reasons, 'plots': result.plots}


def export_json(report, path):
    Path(path).write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')


def _safe(value):
    if isinstance(value, str) and value.lstrip().startswith(('=', '+', '-', '@')):
        return "'"+value
    return value


def export_csv(report, path):
    with Path(path).open('w', newline='', encoding='utf-8-sig') as f:
        writer = csv.writer(f)
        def row(*values):
            writer.writerow([_safe(v) for v in values])
        row('SpeakerCheck', report['app_version'])
        row('UTC', report['created_utc'])
        row('WAV', report['source']['path'])
        row('SHA256', report['source']['sha256'])
        row('Spec', report['spec']['name'])
        row('Confirmed Spec', report['spec']['confirmed'])
        row('Final Result', 'PASS' if report['verdict']=='PASS' else 'FAIL')
        row('Detailed state', report['verdict'])
        production=report.get('production')
        if production:
            for key in ('run_id','serial','operator','station','started_utc','ended_utc'):
                row(key,production.get(key,''))
            row('Capture',json.dumps(production.get('capture',{}),ensure_ascii=False,allow_nan=False))
        row('Settings', json.dumps(report['settings'], ensure_ascii=False, allow_nan=False))
        row('Reference', report['reference']['path'] if report['reference'] else '')
        row('Reference SHA256', report['reference']['sha256'] if report['reference'] else '')
        row('SoX', report['sox']['version'])
        row()
        row('항목', '채널/주파수', '측정값', '단위', '하한', '상한', '판정', '사유')
        for item in report['rows']:
            vals = item['value'] if isinstance(item['value'], list) else [item['value']]
            if item['key'] == 'response_db':
                vals = vals if len(vals) == len(report['spec']['response_points']) else [None]*len(report['spec']['response_points'])
            for i, val in enumerate(vals):
                limit = report['spec']['response_points'][i] if item['key'] == 'response_db' else item
                label = f"{limit['hz']:g} Hz" if item['key'] == 'response_db' else f'CH{i+1}'
                row(item['name'], label, '' if val is None else val, item['unit'],
                    limit['lower'], limit['upper'], item['status'], item['reason'])
