@echo off
setlocal
cd /d "%~dp0"
call setup.bat
if errorlevel 1 exit /b 1
.venv\Scripts\python.exe -m pip install "pyinstaller>=6.8,<7"
if errorlevel 1 exit /b 1
.venv\Scripts\python.exe -m PyInstaller --noconfirm --clean --onedir --windowed --contents-directory . --name SpeakerCheck --hidden-import sounddevice --collect-all _sounddevice_data --add-data "examples;examples" launch.py
if errorlevel 1 (
    pause
    exit /b 1
)
if exist tools\sox xcopy /E /I /Y tools\sox dist\SpeakerCheck\tools\sox >nul
echo Build complete: dist\SpeakerCheck\SpeakerCheck.exe
echo Distribute the entire dist\SpeakerCheck folder, not only the exe.
pause
