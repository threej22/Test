"""Editable limits with explicit product-spec confirmation."""
import json
from pathlib import Path
from PySide6.QtCore import Signal, Qt
from PySide6.QtWidgets import (QWidget,QVBoxLayout,QHBoxLayout,QLabel,QLineEdit,
    QCheckBox,QTableWidget,QTableWidgetItem,QHeaderView,QPushButton,QFileDialog,QMessageBox)
from .spec import METRICS, default_spec, validate_spec


def item(text, editable=True):
    x = QTableWidgetItem(str(text))
    if not editable:
        x.setFlags(x.flags() & ~Qt.ItemFlag.ItemIsEditable)
    return x


class SpecEditor(QWidget):
    changed = Signal()

    def __init__(self):
        super().__init__()
        self.loading = False
        self.base = default_spec()
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0,0,0,0)
        title = QLabel('제품별 검사 기준')
        title.setObjectName('section')
        layout.addWidget(title)
        hint = QLabel('예시 기준을 실제 제품 Spec으로 수정하세요. 한계값을 변경하면 Spec 확인이 해제됩니다. 빈칸은 제한 없음입니다.')
        hint.setWordWrap(True)
        hint.setObjectName('muted')
        layout.addWidget(hint)
        row = QHBoxLayout()
        self.name = QLineEdit()
        row.addWidget(QLabel('Spec 이름'))
        row.addWidget(self.name)
        self.load_button = QPushButton('불러오기')
        self.save_button = QPushButton('JSON 저장')
        row.addWidget(self.load_button)
        row.addWidget(self.save_button)
        layout.addLayout(row)
        self.confirmed = QCheckBox('실제 제품에 적용할 Spec임을 확인했습니다')
        layout.addWidget(self.confirmed)
        self.table = QTableWidget(9,5)
        self.table.setHorizontalHeaderLabels(['사용','검사 항목','하한','상한','단위'])
        self.table.horizontalHeader().setSectionResizeMode(1,QHeaderView.ResizeMode.Stretch)
        self.table.setColumnWidth(0,64)
        for col in (2,3):
            self.table.setColumnWidth(col,120)
        self.table.setAlternatingRowColors(True)
        self.table.verticalHeader().hide()
        self.table.setMinimumHeight(370)
        layout.addWidget(self.table)
        label = QLabel('주파수별 응답 한계 · 기준 WAV 대비 상대 레벨(dB)')
        label.setObjectName('section')
        layout.addWidget(label)
        band_row = QHBoxLayout()
        self.add_band = QPushButton('기준점 추가')
        self.del_band = QPushButton('선택 삭제')
        band_row.addWidget(self.add_band)
        band_row.addWidget(self.del_band)
        band_row.addStretch()
        layout.addLayout(band_row)
        self.bands = QTableWidget(0,3)
        self.bands.setHorizontalHeaderLabels(['주파수 (Hz)','하한 (dB)','상한 (dB)'])
        self.bands.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.bands.verticalHeader().hide()
        self.bands.setAlternatingRowColors(True)
        self.bands.setMinimumHeight(230)
        layout.addWidget(self.bands)
        self.table.itemChanged.connect(self._edit)
        self.bands.itemChanged.connect(self._edit)
        self.name.textChanged.connect(self._edit)
        self.confirmed.toggled.connect(lambda checked: self.changed.emit())
        self.load_button.clicked.connect(self.load_dialog)
        self.save_button.clicked.connect(self.save_dialog)
        self.add_band.clicked.connect(self.append_band)
        self.del_band.clicked.connect(self.remove_band)
        self.set_spec(default_spec())

    def _edit(self, *args):
        if not self.loading:
            self.confirmed.setChecked(False)
            self.changed.emit()

    def set_spec(self, spec):
        spec = validate_spec(spec)
        self.loading = True
        self.base = spec
        self.name.setText(spec['name'])
        for i,(key,meta) in enumerate(METRICS.items()):
            rule = spec['metrics'][key]
            check = item('')
            check.setFlags(Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable)
            check.setCheckState(Qt.CheckState.Checked if rule['enabled'] else Qt.CheckState.Unchecked)
            self.table.setItem(i,0,check)
            self.table.setItem(i,1,item(meta[0],False))
            for j,bound in enumerate(('lower','upper'),2):
                text = '주파수별 표' if key == 'response_db' else '' if rule[bound] is None else str(rule[bound])
                self.table.setItem(i,j,item(text,key != 'response_db'))
            self.table.setItem(i,4,item(meta[1],False))
            self.table.setRowHeight(i,36)
        self.bands.setRowCount(len(spec['response_points']))
        for i,p in enumerate(spec['response_points']):
            for j,key in enumerate(('hz','lower','upper')):
                self.bands.setItem(i,j,item('' if p[key] is None else str(p[key])))
        self.confirmed.setChecked(spec['confirmed'])
        self.loading = False
        self.changed.emit()

    def read_spec(self):
        spec = {'version':1,'name':self.name.text().strip(), 'confirmed':self.confirmed.isChecked(),
                'metrics':{},'response_points':[]}
        def number(table,r,c):
            cell = table.item(r,c)
            text = cell.text().strip() if cell else ''
            try:
                return float(text) if text else None
            except ValueError as exc:
                raise ValueError('Spec 한계와 주파수에는 숫자를 입력하세요.') from exc
        for i,key in enumerate(METRICS):
            spec['metrics'][key] = {'enabled':self.table.item(i,0).checkState() == Qt.CheckState.Checked,
                'lower':self.base['metrics'][key]['lower'] if key == 'response_db' else number(self.table,i,2),
                'upper':self.base['metrics'][key]['upper'] if key == 'response_db' else number(self.table,i,3)}
        for i in range(self.bands.rowCount()):
            spec['response_points'].append({key:number(self.bands,i,j) for j,key in enumerate(('hz','lower','upper'))})
        return validate_spec(spec)

    def append_band(self):
        r = self.bands.rowCount()
        self.bands.insertRow(r)
        for c,text in enumerate(('', '-3','3')):
            self.bands.setItem(r,c,item(text))
        self._edit()

    def remove_band(self):
        r = self.bands.currentRow()
        if r >= 0:
            self.bands.removeRow(r)
            self._edit()

    def load_dialog(self):
        path,_ = QFileDialog.getOpenFileName(self,'Spec 불러오기','','Spec JSON (*.json)')
        if path:
            try:
                self.set_spec(json.loads(Path(path).read_text('utf-8-sig')))
            except (ValueError,OSError) as exc:
                QMessageBox.warning(self,'Spec 오류',str(exc))

    def save_dialog(self):
        try:
            spec = self.read_spec()
            path,_ = QFileDialog.getSaveFileName(self,'Spec 저장','speaker-spec.json','JSON (*.json)')
            if path:
                Path(path).write_text(json.dumps(spec,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
        except (ValueError,OSError) as exc:
            QMessageBox.warning(self,'Spec 오류',str(exc))
