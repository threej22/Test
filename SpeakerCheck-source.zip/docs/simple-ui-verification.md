# 0.3.0 검증

2026-10-23, Linux / 실제 SoX14.4.2 / SQLite / Qt offscreen. 오디오 경계는 SyntheticBackend. 실제 Windows 실행/오디오 장치는 미검증.

`python -m pytest tests -q`: 69 passed (4.44s).

새 재현/회귀:
- `launch.py`가 Python -I에서 기존 bare import로 실패하는 것을 재현 → 앱 경로 직접 등록 후 공백/한국어 폴더 및중첩추출구조 실행 성공.
- 패키지 누락 시 traceback 대신 전체 ZIP 추출 안내와 시작 로그.
- 메인3메뉴/별도생산페이지없음/기본그래프접힘.
- 메인 분석 실행 한 번 → 합성오디오수집 → WAV생성 → 실제SoX → SQLite최종commit → UI PASS.
- 제품번호 미입력 시 생성시험번호를 serial_source로 구별해 저장.
- 기존파일모드 명시, 장치조회오류가 메인상태에 표시.
- 기존 63개 분석/로그/오디오/취소 회귀 유지.

독립 리뷰: Important 없음. Minor인 장치조회오류가 숨겨진controller라벨에만 표시되는 문제를 재현 테스트 RED→GREEN으로 수정. 기존파일분석 테스트는 새 명시적 모드선택을 추가.

`preview_capture.py`는 분석 실행 버튼을 실제 클릭하여 합성 장치입력+실제SoX/DB로 PASS 및 이력1건을 확인했다. 화면 SIMULATION 표기. 그래프접힌메인/설정의시험이력PNG를 확인.

사용자 Windows 오류의 정확한 환경 원인은 확인되지 않았다. 기존ZIP에도패키지는포함되어있었으며, 같은예외를재현하는safe-path와부분추출에대한부트스트랩/진단을 보완했다. ZIP 루트에 launch.py/start.bat/speakercheck 폴더를 직접 넣어 전체추출구조를 단순화했다.
