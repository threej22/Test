# 0.2.0 자동 녹음·양산 Log 검증

날짜: 2026-10-23. Linux Python3.12 + actual SoX14.4.2 + Qt offscreen + SQLite.

전체 테스트 `python -m pytest tests -q`: **63 passed** (3.45s).
입출력 장치는 tests/test_capture.py SyntheticBackend로 시뮬레이션하며 실제 OS 오디오/스피커/디바이스를 검증한 결과가 아니다. PortAudio library가 이 Linux 환경에 없어 실제 오디오 열거/stream은 검증하지 않았다. Windows sounddevice wheel은 PortAudio DLL을 포함하며 build_windows.bat는 해당 데이터를 수집하도록 설정했다. Windows 실행 및 EXE 빌드 미검증.

확인 항목:
- 1kHz generator 연속 위상/채널/-24dBFS amplitude/mute.
- 자동 noise+signal 구간, exact frame count, queue overflow/cancel 시 중지.
- 실제 SoX decoder/분석을 호출하는 CaptureWorker → SQLite → UI end-to-end.
- RUNNING 선기록, serial 필수, 재검사 unique run ID, snapshot float 보존, terminal state 덮어쓰기 금지.
- final DB commit 실패 시 성공 signal 없음, ERROR/ABORTED 기록.
- CSV quoting/formula 방어/기본 측정 컬럼/DB 자기 덮어쓰기 방지.
- Qt 비동기 진행/입력 lock/결과 invalidation/바코드 입력/장치 선택/ESC 출력 중지.
- 기존 WAV 분석 38개 테스트 유지.

독립 리뷰에서 Important 2건 발견 후 재현 테스트 RED→GREEN:
1. 첫1초 정상+뒤2초 무음인데 평균 RMS/첫1초 THD가 PASS: 전체100ms FFT tone-energy/20ms dropout guard 및 명시적 입력 연속성 결과 행 추가.
2. run.finalizing fsync 중 취소를 무시하고 PASS commit: final DB UPDATE 직전 cancellation/commit 상태 전환을 짧은 lock으로 원자적으로 결정. 그 전 취소는 ABORTED, 그 후 UI를 block하지 않고 commit 완료.

추가로 전체 신호를 약1초 window로 분할해 THD 최댓값을 사용하도록 수정했다. 뒤쪽 harmonic distortion 재현 테스트 통과. 새 제품번호 입력 시 생산 화면 PASS를 READY로 무효화. CSV 측정 보고서에도 제품번호/run ID/작업자/스테이션 포함.

시연: scripts/preview_capture.py는 합성 입력 경계+실제 SoX/SQLite로 PASS와 저장 이력 1건을 생성. 화면에 SIMULATION 명시. examples/production-log-example.csv는 이 합성 시연 데이터이며 실제 양산 데이터가 아니다.

공장 승인 전 별도 실기기 인수 필요: 장치/드라이버/샘플레이트별 동작, 시스템 음량/AGC/마이크 교정 고정, 실제 지연에 맞는 안정화 시간, 전원/디스크/USB 재연결 장애, 로그 백업 및 설비 트리거 통합. 무기한 실시간 판정이나 설비 프로토콜은 이번 범위에 포함하지 않았다.
