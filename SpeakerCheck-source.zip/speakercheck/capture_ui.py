"""Automatic acquisition and per-product production history."""
from pathlib import Path
from dataclasses import asdict
from datetime import datetime
import json
import os
import socket
import tempfile
import threading
import uuid
from PySide6.QtCore import Qt,QThread,Signal,QStandardPaths,QTimer
from PySide6.QtWidgets import (QWidget,QVBoxLayout,QHBoxLayout,QFormLayout,QLineEdit,
    QComboBox,QPushButton,QCheckBox,QLabel,QFileDialog,QTableWidget,QTableWidgetItem,
    QHeaderView,QAbstractItemView,QTabWidget,QMessageBox)
from scipy.io import wavfile
from .audio import CapturePlan,ToneOutput,audio_backend,capture_audio,one_khz_spec,validate_returned_tone
from .production import ProductionStore,KST
from .sox import SoxEngine
from .report import make_report,export_json
from .ui import card,label,spin


class CaptureWorker(QThread):
    succeeded=Signal(object)
    failed=Signal(str)
    cancelled=Signal(str)
    progress=Signal(str,float,object)

    def __init__(self,store,run,plan,spec,sox,calibration_db=None,tone=None,backend=None):
        super().__init__()
        self.store=store;self.record=run;self.plan=plan;self.spec=spec;self.sox=sox
        self.calibration_db=calibration_db;self.tone=tone;self.backend=backend
        self.cancel_event=threading.Event()
        self._decision_lock=threading.Lock()
        self._committing=False

    def request_cancel(self):
        with self._decision_lock:
            if self._committing:
                return False
            self.cancel_event.set()
            return True

    def _enter_commit(self):
        # Linearization point: cancellation is accepted up to the final DB write.
        # Lock protects only this quick state change, never disk I/O on the UI thread.
        with self._decision_lock:
            if self.cancel_event.is_set():
                raise InterruptedError('검사가 중단되었습니다. 최종 판정은 저장하지 않았습니다.')
            self._committing=True

    def run(self):
        temporary=None
        try:
            self.store.event(self.record['run_id'],'capture.begin')
            # Validate SoX before starting physical playback/recording.
            engine=SoxEngine(self.sox)
            captured=capture_audio(self.plan,self.cancel_event,self.progress.emit,self.backend,self.tone,self.calibration_db)
            if self.cancel_event.is_set():
                raise InterruptedError('검사가 중단되었습니다.')
            target=Path(self.record['wav_path'])
            if target.exists():
                raise FileExistsError('같은 WAV 파일이 이미 있습니다. 기존 파일을 덮어쓰지 않습니다.')
            with tempfile.NamedTemporaryFile(mode='w+b',suffix='.partial',dir=target.parent,delete=False) as f:
                temporary=Path(f.name)
                wavfile.write(f,self.plan.rate,captured.samples)
                f.flush();os.fsync(f.fileno())
            if self.cancel_event.is_set():
                raise InterruptedError('검사가 중단되었습니다.')
            os.replace(temporary,target);temporary=None
            self.store.event(self.record['run_id'],'capture.saved',{'wav':str(target)})
            self.progress.emit('SoX 분석 및 판정',1.,None)
            report=make_report(engine,target,captured.settings,self.spec)
            report['capture']=captured.metadata
            report['capture']['devices']=json.loads(self.record['capture_json']).get('devices',{})
            thd=report['metrics'].get('thd_percent')
            first=round(captured.settings.signal_start*self.plan.rate)
            quality=validate_returned_tone(captured.samples[first:],self.plan.rate)
            valid_tone=quality['valid'] and isinstance(thd,list) and len(thd)==self.plan.channels and all(v is not None for v in thd)
            report['capture']['valid_1khz_return']=valid_tone
            report['capture']['signal_quality']=quality
            reason=quality['reason'] if not quality['valid'] or valid_tone else '정상상태 1 kHz 톤 모델에 맞지 않는 입력입니다.'
            report['rows'].append({'key':'capture_integrity','name':'1 kHz 입력 연속성','unit':'','value':1 if valid_tone else 0,
                'lower':1,'upper':1,'status':'PASS' if valid_tone else 'UNAVAILABLE','reason':reason})
            if not valid_tone:
                report['capture']['invalid_reason']=reason
                if report['verdict']=='PASS':
                    report['verdict']='INCOMPLETE'
            if self.cancel_event.is_set():
                raise InterruptedError('검사가 중단되었습니다. 판정은 저장하지 않았습니다.')
            # A success signal can never precede the durable product log commit.
            report=self.store.finish(self.record['run_id'],report['verdict'],report,before_commit=self._enter_commit)
            self.succeeded.emit(report)
        except Exception as exc:
            message=str(exc)
            if self.tone is not None:
                try:
                    self.tone.stop()
                except Exception as stop_error:
                    message+=' | 출력 중지 오류: '+str(stop_error)
            state='ABORTED' if isinstance(exc,InterruptedError) else 'ERROR'
            try:
                self.store.finish(self.record['run_id'],state,None,message)
            except Exception as log_error:
                message+=' | 양산 로그 저장 실패: '+str(log_error)+' (PASS 처리하지 않음)'
            (self.cancelled if state=='ABORTED' else self.failed).emit(message)
        finally:
            if temporary is not None:
                try:
                    temporary.unlink(missing_ok=True)
                except OSError:
                    pass


class CapturePanel(QWidget):
    started=Signal(object)
    result_ready=Signal(object)
    failed=Signal(str)
    cancelled=Signal(str)
    progress_message=Signal(str)

    def __init__(self,owner):
        super().__init__()
        self.owner=owner;self.worker=None;self.tone=None;self.history_rows=[];self.backend=None
        outer=QVBoxLayout(self);outer.setContentsMargins(0,0,0,0);outer.setSpacing(12)
        top=QHBoxLayout()
        top.addWidget(label('자동 녹음 · 양산 검사','section'))
        top.addStretch()
        self.test_verdict=label('READY','verdict');top.addWidget(self.test_verdict)
        outer.addLayout(top)
        outer.addWidget(label('PC 출력 → 스피커 → 디바이스 → PC 녹음 장치 → SoX 판정 → 제품 이력 저장','muted',True))
        self.tabs=QTabWidget();outer.addWidget(self.tabs,1)
        self._controls();self._history()
        self.timer=QTimer(self);self.timer.setInterval(300);self.timer.timeout.connect(self.check_tone)
        self.timer.start()

    def _controls(self):
        page=QWidget();layout=QVBoxLayout(page);layout.setSpacing(12)
        self.identity_box,identity=card()
        identity.addWidget(label('제품 식별 · 바코드 Enter로 검사 시작','section'))
        form=QFormLayout()
        self.identity_form=form
        self.serial_edit=QLineEdit();self.serial_edit.setMaxLength(200)
        self.serial_edit.setPlaceholderText('제품번호 필수 · 스캐너 입력 후 Enter')
        self.operator_edit=QLineEdit();self.operator_edit.setPlaceholderText('작업자 이름 또는 사번')
        self.station_edit=QLineEdit(socket.gethostname())
        for text,w in [('제품번호',self.serial_edit),('작업자',self.operator_edit),('검사 스테이션',self.station_edit)]:
            form.addRow(text,w);w.textChanged.connect(self.owner.invalidate)
        identity.addLayout(form);layout.addWidget(self.identity_box)
        self.serial_edit.returnPressed.connect(self.owner.start_analysis)
        self.audio_box,audio=card()
        head=QHBoxLayout();head.addWidget(label('오디오 장치 · 자동 녹음 조건','section'));head.addStretch()
        self.refresh_button=QPushButton('장치 새로고침');head.addWidget(self.refresh_button);audio.addLayout(head)
        self.refresh_button.clicked.connect(self.refresh_devices)
        form=QFormLayout()
        self.device_form=form
        self.output_combo=QComboBox();self.input_combo=QComboBox()
        for w in (self.output_combo,self.input_combo):
            w.addItem('장치 새로고침 후 선택',None);w.setMinimumContentsLength(30)
            w.currentIndexChanged.connect(self.owner.invalidate)
        form.addRow('PC 스피커 출력',self.output_combo);form.addRow('디바이스 → PC 입력',self.input_combo)
        self.rate_combo=QComboBox()
        for rate in (48000,44100,96000): self.rate_combo.addItem(f'{rate:,} Hz',rate)
        self.input_channels=QComboBox();self.output_channels=QComboBox()
        for w in (self.input_channels,self.output_channels):
            w.addItem('1 채널',1);w.addItem('2 채널',2)
        self.output_channels.setCurrentIndex(1)
        self.duration=spin(3,60,.1,2);self.duration.setSuffix(' 초')
        self.settle=spin(1,10,.02,2);self.settle.setSuffix(' 초')
        self.level=spin(-24,-3,-60,1);self.level.setSuffix(' dBFS Peak')
        self.noise_check=QCheckBox('무음 1초 추가 · 톤을 잠시 중지하여 Noise/SNR 측정')
        for text,w in [('샘플레이트',self.rate_combo),('입력 채널',self.input_channels),('출력 채널',self.output_channels),
                       ('1 kHz 출력 레벨',self.level),('안정화 대기',self.settle),('신호 녹음 시간',self.duration)]:
            form.addRow(text,w)
            (w.currentIndexChanged if isinstance(w,QComboBox) else w.valueChanged).connect(self.owner.invalidate)
        self.capture_calibration_enabled=QCheckBox('SPL 교정 적용')
        self.capture_calibration_enabled.setChecked(self.owner.calibration_enabled.isChecked())
        self.capture_calibration_db=spin(self.owner.calibration_db.value(),250,-100,2)
        self.capture_calibration_db.setSuffix(' dB offset')
        self.capture_calibration_db.setEnabled(self.capture_calibration_enabled.isChecked())
        self.capture_calibration_enabled.toggled.connect(self.owner.calibration_enabled.setChecked)
        self.owner.calibration_enabled.toggled.connect(self.capture_calibration_enabled.setChecked)
        self.capture_calibration_enabled.toggled.connect(self.capture_calibration_db.setEnabled)
        self.capture_calibration_db.valueChanged.connect(self.owner.calibration_db.setValue)
        self.owner.calibration_db.valueChanged.connect(self.capture_calibration_db.setValue)
        form.addRow(self.capture_calibration_enabled,self.capture_calibration_db)
        audio.addLayout(form);audio.addWidget(self.noise_check);self.noise_check.toggled.connect(self.owner.invalidate)
        audio.addWidget(label('디바이스가 Windows 녹음 장치로 인식되어야 합니다. 장치 지연이 크면 안정화 시간을 늘리세요. 입력 소리는 PC 출력으로 되돌려 보내지 않습니다.','muted',True))
        layout.addWidget(self.audio_box)
        self.storage_box,storage=card()
        storage.addWidget(label('WAV · 양산 로그 저장 폴더','section'))
        row=QHBoxLayout()
        base=QStandardPaths.writableLocation(QStandardPaths.StandardLocation.AppLocalDataLocation)
        self.directory_edit=QLineEdit(str(Path(base)/'results'))
        self.directory_edit.textChanged.connect(self.owner.invalidate);row.addWidget(self.directory_edit,1)
        browse=QPushButton('폴더 선택');browse.clicked.connect(self.browse_directory);row.addWidget(browse)
        storage.addLayout(row)
        storage.addWidget(label('SQLite에 제품별 시작/종료/Spec/장치/측정값/판정/오류를 자동 기록합니다. 로그 저장 완료 전에는 PASS를 표시하지 않습니다.','muted',True))
        layout.addWidget(self.storage_box)
        buttons=QHBoxLayout()
        self.profile_button=QPushButton('1 kHz 검사 항목 적용');self.profile_button.clicked.connect(self.apply_profile)
        self.tone_button=QPushButton('1 kHz 연속 재생');self.tone_button.clicked.connect(self.toggle_tone)
        self.record_button=QPushButton('자동 녹음 → 판정');self.record_button.setObjectName('primary');self.record_button.clicked.connect(self.start_capture)
        self.stop_button=QPushButton('■ 중지');self.stop_button.setEnabled(False);self.stop_button.clicked.connect(self.stop_all)
        for w in (self.profile_button,self.tone_button,self.record_button,self.stop_button): buttons.addWidget(w)
        layout.addLayout(buttons)
        self.live_status=label('제품번호와 입출력 장치를 선택하세요. 초기 Spec은 예시입니다.','muted',True)
        layout.addWidget(self.live_status)
        layout.addWidget(label('1 kHz만으로 전체 주파수 응답은 측정할 수 없습니다. ‘1 kHz 검사 항목 적용’은 한계값을 유지하고 사용 항목을 조정하며 Spec 확인을 해제합니다.','muted',True))
        layout.addStretch();self.tabs.addTab(page,'자동 검사')

    def _history(self):
        page=QWidget();layout=QVBoxLayout(page)
        row=QHBoxLayout();self.search_edit=QLineEdit();self.search_edit.setPlaceholderText('제품번호 정확히 검색 · 빈칸은 전체')
        row.addWidget(self.search_edit,1)
        refresh=QPushButton('이력 조회');refresh.clicked.connect(self.refresh_history);row.addWidget(refresh)
        export=QPushButton('검색 이력 CSV 저장');export.clicked.connect(self.export_history);row.addWidget(export)
        json_button=QPushButton('선택 보고서 JSON');json_button.clicked.connect(self.export_history_report);row.addWidget(json_button)
        layout.addLayout(row);self.search_edit.returnPressed.connect(self.refresh_history)
        self.history_table=QTableWidget(0,6)
        self.history_table.setHorizontalHeaderLabels(['검사 시각 (KST)','제품번호','판정','작업자','Run ID','오류/사유'])
        self.history_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.history_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.history_table.setAlternatingRowColors(True);self.history_table.verticalHeader().hide()
        self.history_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        layout.addWidget(self.history_table,1)
        layout.addWidget(label('화면은 최신 1,000건, CSV는 검색 조건에 해당하는 전체 이력입니다. RUNNING은 진행 중 또는 비정상 종료된 검사이며 합격이 아닙니다. SQLite가 최종 판정의 원본입니다.','muted',True))
        self.tabs.addTab(page,'제품별 시험 이력')

    def selected_plan(self):
        return CapturePlan(input_device=self.input_combo.currentData(),output_device=self.output_combo.currentData(),
            channels=self.input_channels.currentData(),output_channels=self.output_channels.currentData(),rate=self.rate_combo.currentData(),
            duration=self.duration.value(),settle=self.settle.value(),level_dbfs=self.level.value(),noise_duration=1. if self.noise_check.isChecked() else 0.).validate()

    def refresh_devices(self):
        try:
            backend=self.backend or audio_backend()
            devices=backend.query_devices();hosts=backend.query_hostapis()
            for combo in (self.input_combo,self.output_combo):
                combo.clear();combo.addItem('장치 선택',None)
            for i,d in enumerate(devices):
                name=f"[{i}] {d['name']} · {hosts[d['hostapi']]['name']}"
                if d['max_input_channels']>0: self.input_combo.addItem(name,i)
                if d['max_output_channels']>0: self.output_combo.addItem(name,i)
            self.live_status.setText('PC 스피커 출력과 디바이스가 연결된 녹음 입력을 각각 선택하세요.')
        except Exception as exc:
            self.live_status.setText('장치 조회 실패: '+str(exc))
        self.progress_message.emit(self.live_status.text())

    def browse_directory(self):
        path=QFileDialog.getExistingDirectory(self,'WAV 및 양산 이력 저장 폴더',self.directory_edit.text())
        if path: self.directory_edit.setText(path)

    def apply_profile(self):
        if self.worker or self.owner.worker:
            return
        try:
            self.owner.spec_editor.set_spec(one_khz_spec(self.owner.spec_editor.read_spec(),
                self.input_channels.currentData(),self.noise_check.isChecked(),self.owner.calibration_enabled.isChecked()))
            self.live_status.setText('1 kHz 항목을 적용했습니다. Spec 관리에서 실제 제품 기준과 확인 상태를 검토하세요.')
        except ValueError as exc:
            self.live_status.setText(str(exc))
        self.progress_message.emit(self.live_status.text())

    def toggle_tone(self):
        try:
            if self.tone and self.tone.active:
                self.stop_all();return
            if self.owner.worker:
                return
            plan=self.selected_plan()
            self.owner.invalidate()
            self.tone=ToneOutput(plan,self.backend)
            self.tone.start()
            self.audio_box.setEnabled(False)
            self.tone_button.setText('1 kHz 재생 중지');self.stop_button.setEnabled(True)
            self.owner.audio_stop_button.setEnabled(True)
            self.live_status.setText('1 kHz 연속 출력 중 · 자동 녹음 성공 후에도 계속 재생합니다. 중지 버튼으로 종료하세요.')
        except Exception as exc:
            self.tone=None
            self.live_status.setText('출력 시작 실패: '+str(exc))

    def start_capture(self):
        if self.worker or self.owner.worker:
            return
        try:
            plan=self.selected_plan();spec=self.owner.spec_editor.read_spec()
            path=self.directory_edit.text().strip()
            if not path:
                raise ValueError('양산 로그 저장 폴더를 선택하세요.')
            store=ProductionStore(path)
            capture={'plan':asdict(plan),'spec':spec,'devices':{'input':self.input_combo.currentText(),'output':self.output_combo.currentText()},
                     'calibration_db':self.owner.calibration_db.value() if self.owner.calibration_enabled.isChecked() else None}
            serial=self.serial_edit.text().strip()
            capture['serial_source']='entered_product_id' if serial else 'generated_test_id'
            serial=serial or 'TEST-'+datetime.now(KST).strftime('%Y%m%d-%H%M%S')+'-'+uuid.uuid4().hex[:8]
            run=store.begin(serial,self.operator_edit.text(),self.station_edit.text(),capture)
            self.worker=CaptureWorker(store,run,plan,spec,self.owner.sox_edit.text(),capture['calibration_db'],
                self.tone if self.tone and self.tone.active else None,self.backend)
            self.worker.progress.connect(self.update_progress)
            self.worker.succeeded.connect(self._success)
            self.worker.failed.connect(self._failure)
            self.worker.cancelled.connect(self._cancelled)
            self.worker.finished.connect(self._finished)
            self.set_busy(True)
            self.owner.invalidate()
            self.test_verdict.setText('RECORDING')
            self.test_verdict.setStyleSheet('color: #8ba3bd;')
            self.started.emit(self.worker)
            self.worker.start()
        except Exception as exc:
            self.live_status.setText('검사 시작 실패: '+str(exc))
            self._failure('검사 시작 실패: '+str(exc))

    def set_busy(self,busy):
        tone_active=self.tone is not None and self.tone.active
        for w in (self.identity_box,self.storage_box,self.profile_button,self.tone_button,self.record_button): w.setEnabled(not busy)
        self.audio_box.setEnabled(not busy and not tone_active)
        self.stop_button.setEnabled(self.worker is not None or tone_active)
        self.owner.audio_stop_button.setEnabled(self.worker is not None or tone_active)

    def update_progress(self,stage,fraction,db):
        meter='—' if db is None else f'{db:.1f} dBFS'
        message=f'{stage} · {fraction*100:.0f}% · 입력 RMS {meter}'
        self.live_status.setText(message);self.progress_message.emit(message)

    def _success(self,report):
        self.test_verdict.setText(report['verdict'])
        color='#70e4be' if report['verdict']=='PASS' else '#ff8995' if report['verdict']=='NG' else '#efc27a'
        self.test_verdict.setStyleSheet('color: '+color+';')
        self.live_status.setText(f"{report['verdict']} · 제품 {report['production']['serial']} · 이력 저장 완료 · {report['source']['path']}")
        issues=[r['name']+': '+r['reason'] for r in report['rows'] if r['status'] in ('NG','UNAVAILABLE')]
        if report['verdict']=='SPEC REQUIRED': issues.insert(0,'실제 제품 Spec 확인 필요')
        if issues: self.live_status.setText(self.live_status.text()+' | '+'; '.join(issues[:3]))
        self.result_ready.emit(report)

    def _failure(self,message):
        self.test_verdict.setText('ERROR');self.test_verdict.setStyleSheet('color: #ff8995;')
        self.live_status.setText('ERROR · '+message);self.failed.emit(message)

    def _cancelled(self,message):
        self.test_verdict.setText('ABORTED');self.test_verdict.setStyleSheet('color: #efc27a;')
        self.live_status.setText('ABORTED · '+message);self.cancelled.emit(message)

    def _finished(self):
        self.worker=None;self.set_busy(False)
        self.refresh_history(silent=True)
        self.serial_edit.setFocus();self.serial_edit.selectAll()
        self.check_tone()

    def stop_all(self):
        if self.worker:
            accepted=self.worker.request_cancel()
            if not accepted:
                self.live_status.setText('녹음은 끝났으며 최종 결과 저장 중입니다. 완료를 기다려 주세요.')
        if self.tone:
            try:
                self.tone.stop()
            except Exception as exc:
                self.live_status.setText('출력 중지 오류: '+str(exc))
        if not self.worker:
            self.set_busy(False)
            self.live_status.setText('출력 중지됨')
        self.tone_button.setText('1 kHz 연속 재생')

    def check_tone(self):
        if self.worker:
            return
        if self.tone and self.tone.error:
            message=self.tone.error;self.stop_all();self.live_status.setText(message)
        if not self.tone or not self.tone.active:
            self.tone_button.setText('1 kHz 연속 재생')
            self.audio_box.setEnabled(self.owner.worker is None)
            self.stop_button.setEnabled(False)
            self.owner.audio_stop_button.setEnabled(False)

    def refresh_history(self,checked=False,silent=False):
        try:
            root=Path(self.directory_edit.text())
            if not (root/'production.sqlite3').is_file():
                self.history_table.setRowCount(0)
                if not silent: self.live_status.setText('선택한 폴더에 생산 이력이 없습니다.')
                return
            self.history_rows=ProductionStore(root).history(self.search_edit.text().strip())
            self.history_table.setRowCount(len(self.history_rows))
            for i,r in enumerate(self.history_rows):
                when=datetime.fromisoformat(r['started_utc']).astimezone(KST).strftime('%Y-%m-%d %H:%M:%S')
                reason=r['error']
                if not reason and r['report_json']:
                    report=json.loads(r['report_json'])
                    reason='; '.join(v['name']+': '+v['reason'] for v in report['rows'] if v['status'] in ('NG','UNAVAILABLE'))
                    if r['state']=='SPEC REQUIRED': reason='제품 Spec 확인 필요 · '+reason
                for j,value in enumerate((when,r['serial'],r['state'],r['operator'],r['run_id'],reason)):

                    cell=QTableWidgetItem(value);cell.setToolTip(value);self.history_table.setItem(i,j,cell)
        except Exception as exc:
            self.live_status.setText('이력 조회 실패: '+str(exc))
            if not silent: self.progress_message.emit(self.live_status.text())

    def export_history(self):
        try:
            path,_=QFileDialog.getSaveFileName(self,'생산 이력 CSV 저장','production-history.csv','CSV (*.csv)')
            if path:
                ProductionStore(self.directory_edit.text()).export_csv(path,self.search_edit.text().strip())
                self.live_status.setText('이력 CSV 저장 완료 · '+path)
        except Exception as exc:
            QMessageBox.warning(self,'이력 저장 실패',str(exc))

    def export_history_report(self):
        try:
            i=self.history_table.currentRow()
            if i<0:
                raise ValueError('보고서를 저장할 이력을 선택하세요.')
            r=self.history_rows[i]
            report=ProductionStore(self.directory_edit.text()).get_report(r['run_id'])
            path,_=QFileDialog.getSaveFileName(self,'선택 보고서 저장',r['run_id']+'.json','JSON (*.json)')
            if path: export_json(report,path)
        except Exception as exc:
            QMessageBox.warning(self,'보고서 저장 실패',str(exc))
