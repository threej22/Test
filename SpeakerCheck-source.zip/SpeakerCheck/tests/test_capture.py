import threading
import numpy as np
import pytest
from speakercheck.audio import CapturePlan, ToneGenerator, capture_audio, AudioError


def test_tone_phase_continuity_and_amplitude():
    g = ToneGenerator(rate=48000, channels=2, frequency=1000, level_dbfs=-24)
    a = g.render(701)
    b = g.render(915)
    got = np.r_[a[:,0],b[:,0]]
    want = 10**(-24/20)*np.sin(2*np.pi*1000*np.arange(len(got))/48000)
    assert got[300:] == pytest.approx(want[300:], abs=1e-6)
    assert np.max(np.abs(got)) == pytest.approx(.063095734,abs=1e-6)
    assert a[:,0] == pytest.approx(a[:,1])
    g.muted = True
    assert np.max(np.abs(g.render(800)[300:])) == 0


@pytest.mark.parametrize('kwargs',[{'duration':0},{'duration':float('nan')},{'level_dbfs':0},{'channels':0},{'input_device':None}])
def test_invalid_capture_plan_rejected(kwargs):
    with pytest.raises(ValueError):
        CapturePlan(input_device=2,output_device=3,**({} if 'input_device' in kwargs else {})).replace(**kwargs).validate()


class SyntheticBackend:
    """Hardware-boundary simulator: return samples from the actual tone callback."""
    def __init__(self,overflow=False):
        self.output=None
        self.overflow=overflow
        self.closed=[]
    def check_input_settings(self,**kwargs): pass
    def check_output_settings(self,**kwargs): pass
    def OutputStream(self,**kwargs):
        parent=self
        class Output:
            def start(self): parent.output=kwargs['callback']
            def stop(self): pass
            def close(self): parent.closed.append('output')
        return Output()
    def InputStream(self,**kwargs):
        parent=self
        class Input:
            active=False
            def start(self):
                self.active=True
                def feed():
                    while self.active:
                        output=np.zeros((256,2),np.float32)
                        parent.output(output,256,None,False)
                        # Device returns output at .5 gain plus deterministic ambient noise.
                        noise=.0001*np.sin(np.arange(256)*.83)
                        recorded=output[:,:kwargs['channels']]*.5+noise[:,None]
                        kwargs['callback'](recorded,256,None,'overflow' if parent.overflow else False)
                        threading.Event().wait(.0005)
                self.thread=threading.Thread(target=feed,daemon=True)
                self.thread.start()
            def stop(self):
                self.active=False
                self.thread.join(1)
            def close(self): parent.closed.append('input')
        return Input()


def test_auto_capture_returns_exact_noise_signal_windows_and_closes():
    backend=SyntheticBackend()
    plan=CapturePlan(input_device=2,output_device=3,duration=.2,settle=.05,noise_duration=.1,channels=1)
    r=capture_audio(plan,threading.Event(),backend=backend)
    assert r.samples.shape==(14400,1)
    assert r.settings.signal_start==pytest.approx(.1)
    assert r.settings.signal_end==pytest.approx(.3)
    assert r.settings.noise_start==0
    assert r.settings.noise_end==pytest.approx(.1)
    assert r.settings.tone_hz==1000
    assert np.sqrt(np.mean(r.samples[:4800]**2)) < .0002
    assert np.sqrt(np.mean(r.samples[4800:]**2)) == pytest.approx(.0223,abs=.0002)
    assert set(backend.closed)=={'input','output'}


def test_overflow_and_cancel_do_not_produce_qualified_audio():
    with pytest.raises(AudioError,match='overflow'):
        capture_audio(CapturePlan(input_device=2,output_device=3,duration=.2),threading.Event(),backend=SyntheticBackend(True))
    stop=threading.Event();stop.set()
    with pytest.raises(InterruptedError):
        capture_audio(CapturePlan(input_device=2,output_device=3),stop,backend=SyntheticBackend())


def test_full_recording_tone_presence_rejects_late_dropout():
    from speakercheck.audio import validate_returned_tone
    t=np.arange(48000*3)/48000
    x=(.063*np.sin(2*np.pi*1000*t))[:,None]
    assert validate_returned_tone(x,48000)['valid']
    x[48000:]=0
    assert not validate_returned_tone(x,48000)['valid']
    noise=np.random.default_rng(22).normal(0,.02,(48000,1))
    assert not validate_returned_tone(noise,48000)['valid']


def test_small_dropout_cannot_hide_in_long_average():
    from speakercheck.audio import validate_returned_tone
    t=np.arange(48000*3)/48000
    x=(.063*np.sin(2*np.pi*1000*t))[:,None]
    x[72000:74400]=0  # 50ms gap halfway through, RMS/first-second THD alone would pass.
    assert not validate_returned_tone(x,48000)['valid']
