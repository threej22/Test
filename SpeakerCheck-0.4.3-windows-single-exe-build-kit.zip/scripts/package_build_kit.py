"""Small complete source kit: demo WAVs are generated locally during the build."""
from pathlib import Path
import hashlib
import json
import zipfile
import sys

root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root))
from speakercheck import __version__
out=root/'output';out.mkdir(exist_ok=True)
target=out/f'SpeakerCheck-{__version__}-windows-single-exe-build-kit.zip'
fixed={'README.md','WINDOWS_BUILD.md','launch.py','setup.bat','start.bat','build_windows.bat','requirements.txt','requirements-dev.txt'}
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(root.rglob('*')):
        if not path.is_file():continue
        rel=path.relative_to(root);name=rel.as_posix()
        include=name in fixed or (rel.parts[0] in {'speakercheck','scripts','tests'} and path.suffix=='.py') or (rel.parts[0]=='docs' and path.suffix=='.md') or name in {'examples/example_spec.json','examples/README.txt','examples/production-log-example.csv'}
        if not include or any(p in {'__pycache__','output','work','.venv'} for p in rel.parts):continue
        data=path.read_bytes()
        if path.suffix=='.bat':data=data.replace(b'\r\n',b'\n').replace(b'\n',b'\r\n')
        archive.writestr(name,data)
with zipfile.ZipFile(target) as archive:assert archive.testzip() is None
b=target.read_bytes();metadata={'path':str(target),'size':len(b),'git_blob_sha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'sha256':hashlib.sha256(b).hexdigest()}
(out/f'build-kit-{__version__}-meta.json').write_text(json.dumps(metadata,indent=2));print(json.dumps(metadata))
