"""SIMULATION preview: synthetic hardware boundary with actual SoX and SQLite."""
import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
from pathlib import Path
import sys
import time
from datetime import datetime
sys.path[:0]=[str(Path(__file__).resolve().parents[1]),str(Path(__file__).resolve().parents[1]/'tests')]
from PySide6.QtWidgets import QApplication
from speakercheck.ui import MainWindow
from speakercheck.audio import one_khz_spec
from speakercheck.spec import default_spec
from speakercheck.production import ProductionStore
from test_capture import SyntheticBackend
from test_devices import DeviceBackend

class PreviewBackend(SyntheticBackend,DeviceBackend):
    pass

base=Path(__file__).resolve().parents[1]
out=base/'output'
out.mkdir(exist_ok=True)
# New folder for each preview avoids changing an earlier evidence database.
logs=out/('simulation-'+datetime.now().strftime('%Y%m%d-%H%M%S'))
app=QApplication([])
w=MainWindow();w.resize(1440,1400)
p=w.capture_panel;p.backend=PreviewBackend();p.refresh_devices()
p.operator_edit.setText('DEMO');p.station_edit.setText('SIMULATED I/O - real SoX')
p.directory_edit.setText(str(logs));p.duration.setValue(3);p.settle.setValue(.05)
spec=one_khz_spec(default_spec(),2,False,False)
spec['name']='SIMULATION ONLY - not product qualification'
spec['confirmed']=True  # Controlled test fixture only.
w.spec_editor.set_spec(spec);w.sox_edit.setText(os.environ.get('SOX_BINARY','sox'))
w.show();w.run_button.click()
deadline=time.monotonic()+30
while w.worker is not None and time.monotonic()<deadline:
    app.processEvents();time.sleep(.01)
if w.report is None:
    raise RuntimeError(p.live_status.text())
w.local_badge.setText('SIMULATION · real SoX')
w.graph_toggle.click();app.processEvents();w.grab().save(str(out/'SpeakerCheck-auto-preview.png'))
w.plot_tabs.setCurrentIndex(1);app.processEvents();w.grab().save(str(out/'SpeakerCheck-spectrum-preview.png'))
w.navigate(2);w.settings_tabs.setCurrentIndex(0)
p.test_output();p.test_input()
preview_end=time.monotonic()+.4
while time.monotonic()<preview_end:app.processEvents();time.sleep(.01)
w.local_badge.setText('SIMULATION · real SoX')
w.grab().save(str(out/'SpeakerCheck-devices-preview.png'))
p.stop_all()
preview_end=time.monotonic()+3
while p.input_monitor is not None and time.monotonic()<preview_end:app.processEvents();time.sleep(.01)
w.settings_tabs.setCurrentIndex(2);app.processEvents();w.grab().save(str(out/'SpeakerCheck-history-preview.png'))
store=ProductionStore(logs);store.export_csv(out/'production-log-example.csv')
print('SIMULATED acquisition + real SoX:',store.history()[0]['state'],'persisted rows:',len(store.history()))
w.close()
