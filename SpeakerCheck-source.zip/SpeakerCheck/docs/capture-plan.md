# 자동 녹음·양산 로그 구현 계획

Goal: PC1kHz/디바이스 오디오입력 자동 녹음 및 저장 후 SoX 판정, 제품별 감사 이력.
Spec: capture-design.md

- [x] 1. tests/test_capture.py RED: 위상 연속성, -24dBFS amplitude, 무음/신호 구간, cancel, overflow, device errors. Implement audio.py and validate with synthetic backend. No physical hardware claims.
- [x] 2. tests/test_production.py RED: serial required, pre-run RUNNING, PASS snapshot exact roundtrip, ABORTED/ERROR, SQLite persistence failure, CSV quoting and IDs. Implement production.py.
- [x] 3. Qt tests RED: device selection, required serial, async capture→SoX→DB→UI, log failure forbids PASS, profile does not approve itself. Implement capture_ui.py and integrate ui.py. Existing 38 tests remain green.
- [x] 4. Update docs, requirements, Windows packaging. Independent review, fix important findings with regression tests. Full suite + screenshot + ZIP integrity. Upload versioned ZIP and refresh primary ZIP using GitHub fast-forward lease, verify remote blob.
