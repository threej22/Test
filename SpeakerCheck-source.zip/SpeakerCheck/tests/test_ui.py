import os
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
import time
import numpy as np
import pytest
from scipy.io import wavfile
from PySide6.QtWidgets import QApplication
from speakercheck.ui import MainWindow

@pytest.fixture(scope='module')
def app():
    return QApplication.instance() or QApplication([])


def test_real_async_measurement_and_stale_export_invalidation(app, tmp_path):
    path = tmp_path/'test.wav'
    t = np.arange(48000)/48000
    wavfile.write(path,48000,(np.sin(2*np.pi*1000*t)*3000).astype(np.int16))
    w = MainWindow()
    w.sox_edit.setText(os.environ.get('SOX_BINARY','sox'))
    w.source_edit.setText(str(path))
    w.start_analysis()
    assert not w.sox_card.isEnabled()
    deadline = time.monotonic()+15
    while w.worker is not None and time.monotonic() < deadline:
        app.processEvents()
        time.sleep(.01)
    assert w.report is not None
    assert w.result_table.rowCount() == 9
    assert w.report['verdict'] == 'SPEC REQUIRED'
    assert w.export_json_button.isEnabled()
    w.signal_start.setValue(.1)
    assert w.report is None
    assert not w.export_json_button.isEnabled()
    assert w.result_table.rowCount() == 0
    w.close()


def test_limit_edit_resets_confirmation(app):
    w = MainWindow()
    w.spec_editor.confirmed.setChecked(True)
    w.spec_editor.table.item(0,2).setText('-40')
    assert not w.spec_editor.confirmed.isChecked()
    assert w.spec_editor.read_spec()['metrics']['rms_dbfs']['lower'] == -40
    w.close()


def test_confirm_toggle_invalidates_existing_report(app):
    w = MainWindow()
    w.spec_editor.confirmed.setChecked(True)
    from pathlib import Path
    from speakercheck.sox import SoxEngine
    from speakercheck.report import make_report
    from speakercheck.analysis import AnalysisSettings
    from speakercheck.spec import default_spec
    base = Path(__file__).resolve().parents[1]/'examples'
    spec = default_spec()
    spec['confirmed'] = True
    report = make_report(SoxEngine(os.environ.get('SOX_BINARY','sox')),base/'demo_composite.wav',
        AnalysisSettings(signal_end=1,noise_start=1,noise_end=2,tone_hz=1000,calibration_db=110,response_start=2,response_end=4),
        spec,base/'demo_reference.wav')
    w.show_report(report)
    assert w.report['verdict'] == 'PASS'
    w.spec_editor.confirmed.setChecked(False)
    assert w.report is None
    assert not w.export_json_button.isEnabled()
    w.close()


def test_imported_limits_keep_full_precision(app):
    from speakercheck.spec import default_spec, evaluate
    w = MainWindow()
    spec = default_spec()
    spec['confirmed'] = True
    for key,r in spec['metrics'].items():
        r['enabled'] = key == 'rms_dbfs'
    spec['metrics']['rms_dbfs']['lower'] = -23.01029995
    w.spec_editor.set_spec(spec)
    restored = w.spec_editor.read_spec()
    assert evaluate(restored, {'rms_dbfs':[-23.010299956639813]})[1] == 'NG'
    w.close()


def test_measurement_inputs_and_chart_fit_visible_widgets(app):
    w = MainWindow()
    w.show()
    app.processEvents()
    assert w.signal_end.lineEdit().width() >= 80
    assert w.plots['waveform'].height() < w.plot_tabs.height()
    w.close()
