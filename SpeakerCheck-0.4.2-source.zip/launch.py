"""Source launcher: resolve files relative to this script, never the current cwd."""
from pathlib import Path
import sys
import tempfile
import traceback


def application_root():
    base=Path(__file__).resolve().parent
    for root in (base,base/'SpeakerCheck'):
        if (root/'speakercheck'/'__init__.py').is_file() and (root/'speakercheck'/'ui.py').is_file():
            return root
    raise RuntimeError('Application folder "speakercheck" is missing. Extract the entire ZIP, then run start.bat. Keep launch.py and the speakercheck folder together.')


def load_main():
    if not getattr(sys,'frozen',False):
        root=application_root()
        sys.path.insert(0,str(root))
    from speakercheck.ui import main
    return main


def run():
    try:
        main=load_main()
        if len(sys.argv)==3 and sys.argv[1]=='--self-test':
            from speakercheck.selftest import run_self_test
            return run_self_test(sys.argv[2])
        main()
        return 0
    except Exception as exc:
        print('SpeakerCheck could not start: '+str(exc),flush=True)
        if isinstance(exc,ModuleNotFoundError):
            print('Run setup.bat in the fully extracted application folder, then start.bat.',flush=True)
        log=Path(tempfile.gettempdir())/'SpeakerCheck-startup-error.log'
        try:
            log.write_text(traceback.format_exc(),encoding='utf-8')
            print('Startup log: '+str(log),flush=True)
        except OSError:
            pass
        return 1


if __name__=='__main__':
    sys.exit(run())
