# SpeakerCheck 설계

목적: Windows에서 sox.exe로 녹음 WAV를 읽고 스피커 검증 Spec과 비교한다.
승인된 범위: 데스크톱 UI, RMS/Peak/클리핑/주파수 응답/THD/노이즈/SNR/좌우차/SPL, 항목별 및 최종 판정.

## 구현 선택
Python 3.11+ / PySide6 / NumPy / SciPy / Matplotlib. 대안인 웹 UI는 로컬 실행 파일 연동 서버가 필요하며, C#은 DSP 구현량이 커 Python 데스크톱을 선택한다(구현자 판단). 외부 SoX는 사용자 설치본을 선택하며 재배포하지 않는다.

## 화면
측정 화면: 파일 선택, 시험 조건, 분석 실행, 판정 카드, 파형/스펙트럼/응답 탭, 항목별 결과와 사유.
Spec 화면: 항목별 enable/하한/상한, 주파수별 응답 허용 범위 표, JSON 불러오기/저장. 기본값은 EXAMPLE이며 실제 제품 기준 확인 전 최종 PASS 금지.
설정: sox.exe 경로, 신호/무음 구간(초), 단일 톤 여부와 주파수, SPL 교정 offset, 주파수 응답 비교용 기준 WAV.

## 측정 계약
SoX를 shell=False로 실행해 WAV metadata, stats, float64 raw PCM을 얻는다. 512 MiB decode/60초 subprocess 제한. 원본 SHA256와 SoX 버전/통계, Spec, 설정을 결과에 남긴다.
RMS는 선택 신호 구간의 채널별 값이며 최악 채널 판정. Peak와 clipping은 전체 WAV. clipping은 |sample| >= 1-1/32768인 표본 비율(0 dBFS 근접 표본, 아날로그 클리핑 검출 아님).
THD는 명시적으로 선택한 정상상태 단일 톤 구간만 사용. 지정 주파수 주변 ±2% 추정 후 2~5차 harmonic 동시 최소제곱 적합. Nyquist/5 이상은 측정 불가. 기저 신호가 약하거나 모델 잔차가 크면 측정 불가.
노이즈는 사용자 무음 구간 RMS dBFS. SNR은 신호와 별도 무음의 power 차감 후 비율(대역 제한/가중치 없는 값). 구간이 겹치거나 무음 power가 signal 이상이면 측정 불가.
SPL = 신호 RMS dBFS + 동일 체인의 교정 offset. 교정 없으면 측정 불가. 주파수 가중치 없는 값.
응답은 동일 시험의 광대역 기준 녹음과 DUT 녹음의 별도 지정 구간에서 Welch PSD 비율을 1/6 octave band에서 비교한다(위상/지연 추정 기능 없음). 기준으로부터의 상대 레벨이며 절대 무향실 응답 아님. 각 대역 excitation과 DUT 에너지 부족/범위 밖은 측정 불가. sample rate 일치 필요.

## 판정 및 결과
항목 PASS/NG/측정불가/SKIP. 활성 항목 NG가 있으면 NG, 부족한 조건은 INCOMPLETE, 전부 꺼짐도 INCOMPLETE, 예시 Spec이면 SPEC REQUIRED. 활성 항목이 모두 측정되고 한계 이내이며 확인된 Spec일 때 PASS.
JSON/CSV UTF-8 BOM export는 분석 시점의 snapshot을 사용. 파일/설정 변경 시 이전 결과 무효화. 정상 입력·무음·mono·경계값·잘못된 spec·SoX 오류 테스트. GUI 비동기 실행으로 UI block 방지.

## 범위 밖
녹음/재생 제어, swept-sine deconvolution, 마이크 EQ 보정, A-weighting, 생산설비 연동은 포함하지 않는다. Windows exe 빌드 스크립트를 제공하되 Linux 검증과 Windows 실행 검증은 구별한다.
