@echo off
setlocal
cd /d "%~dp0"
if not exist "%~dp0speakercheck\ui.py" (
    echo Application folder "speakercheck" is missing.
    echo Extract the entire ZIP into a new folder, then run start.bat.
    pause
    exit /b 1
)
if not exist "%~dp0.venv\Scripts\python.exe" (
    call "%~dp0setup.bat"
    if errorlevel 1 exit /b 1
)
"%~dp0.venv\Scripts\python.exe" "%~dp0launch.py"
set "SC_EXIT=%ERRORLEVEL%"
if not "%SC_EXIT%"=="0" pause
exit /b %SC_EXIT%
