"""Korean desktop UI. Analysis runs on a worker with immutable input snapshots."""
from pathlib import Path
import sys
from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (QApplication,QMainWindow,QWidget,QFrame,QVBoxLayout,QHBoxLayout,
    QLabel,QPushButton,QLineEdit,QDoubleSpinBox,QCheckBox,QFormLayout,QStackedWidget,
    QScrollArea,QTableWidget,QTableWidgetItem,QHeaderView,QAbstractItemView,QFileDialog,
    QMessageBox,QTabWidget,QProgressBar,QSplitter,QTextBrowser)
from .styles import STYLE
from .spec import default_spec
from .spec_editor import SpecEditor
from .analysis import AnalysisSettings
from .sox import SoxEngine, locate_sox
from .report import make_report, export_json, export_csv
from .plots import MeasurementPlot

STATUS_COLORS = {'PASS':'#70e4be','NG':'#ff8995','UNAVAILABLE':'#efc27a','SKIP':'#879bb6',
                 'INCOMPLETE':'#efc27a','SPEC REQUIRED':'#efc27a','READY':'#8ba3bd'}


def label(text, kind=None, wrap=False):
    w = QLabel(text)
    if kind:
        w.setObjectName(kind)
    w.setWordWrap(wrap)
    return w


def card():
    w = QFrame()
    w.setObjectName('card')
    layout = QVBoxLayout(w)
    layout.setContentsMargins(17,14,17,14)
    layout.setSpacing(9)
    return w,layout


def spin(value=0, maximum=36000, minimum=0, decimals=3):
    w = QDoubleSpinBox()
    w.setRange(minimum,maximum)
    w.setDecimals(decimals)
    w.setValue(value)
    return w


class AnalysisWorker(QThread):
    succeeded = Signal(object)
    failed = Signal(str)

    def __init__(self, sox, path, settings, spec, reference):
        super().__init__()
        self.args = sox,path,settings,spec,reference

    def run(self):
        try:
            sox,path,settings,spec,reference = self.args
            self.succeeded.emit(make_report(SoxEngine(sox),path,settings,spec,reference))
        except Exception as exc:
            self.failed.emit(str(exc))


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.report = None
        self.worker = None
        self._initializing = True
        self.setWindowTitle('SpeakerCheck · SoX Speaker Verification')
        self.resize(1540,1080)
        self.setMinimumSize(1180,800)
        self.setStyleSheet(STYLE)
        central = QWidget()
        self.setCentralWidget(central)
        root = QHBoxLayout(central)
        root.setContentsMargins(0,0,0,0)
        root.setSpacing(0)
        sidebar = QFrame()
        sidebar.setObjectName('sidebar')
        sidebar.setFixedWidth(208)
        nav = QVBoxLayout(sidebar)
        nav.setContentsMargins(18,30,18,22)
        nav.setSpacing(10)
        nav.addWidget(label('◈  SpeakerCheck','brand'))
        nav.addWidget(label('ACOUSTIC VERIFICATION','eyebrow'))
        nav.addSpacing(36)
        self.nav_buttons = []
        for i,text in enumerate(('01   WAV 분석','02   Spec 관리','03   설정 · 측정 안내')):
            button = QPushButton(text)
            button.setObjectName('nav')
            button.setCheckable(True)
            button.clicked.connect(lambda checked=False,index=i:self.navigate(index))
            nav.addWidget(button)
            self.nav_buttons.append(button)
        nav.addStretch()
        nav.addWidget(label('LOCAL ANALYSIS','eyebrow'))
        nav.addWidget(label('WAV → SoX → Spec\n항목별 판정과 결과 추적','muted',True))
        nav.addSpacing(12)
        nav.addWidget(label('SpeakerCheck  0.1.0\nWindows desktop','muted'))
        root.addWidget(sidebar)
        body = QWidget()
        outer = QVBoxLayout(body)
        outer.setContentsMargins(26,22,26,16)
        outer.setSpacing(15)
        header = QHBoxLayout()
        headings = QVBoxLayout()
        headings.addWidget(label('스피커 검증','title'))
        headings.addWidget(label('녹음된 WAV를 분석하고 제품 Spec과 비교합니다.','muted'))
        header.addLayout(headings)
        header.addStretch()
        self.local_badge = label('●  LOCAL · SoX','badge')
        header.addWidget(self.local_badge,0,Qt.AlignmentFlag.AlignTop)
        outer.addLayout(header)
        self.pages = QStackedWidget()
        outer.addWidget(self.pages,1)
        self.status = label('준비됨 · WAV 파일을 선택하고 측정 조건을 설정하세요.','muted')
        outer.addWidget(self.status)
        root.addWidget(body,1)
        self._measurement_page()
        spec_scroll = QScrollArea()
        spec_scroll.setWidgetResizable(True)
        self.spec_editor = SpecEditor()
        spec_scroll.setWidget(self.spec_editor)
        self.pages.addWidget(spec_scroll)
        self._settings_page()
        self.spec_editor.changed.connect(self.invalidate)
        self._initializing = False
        self.navigate(0)

    def navigate(self,index):
        self.pages.setCurrentIndex(index)
        for i,button in enumerate(self.nav_buttons):
            button.setChecked(i == index)

    def _measurement_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0,0,0,0)
        layout.setSpacing(14)
        self.file_card,files = card()
        top = QHBoxLayout()
        top.addWidget(label('측정 파일','section'))
        top.addStretch()
        demo_button = QPushButton('합성 샘플 열기')
        demo_button.clicked.connect(self.load_demo)
        top.addWidget(demo_button)
        files.addLayout(top)
        self.source_edit = QLineEdit()
        self.source_edit.setPlaceholderText('분석할 스피커 녹음 WAV 파일')
        self.reference_edit = QLineEdit()
        self.reference_edit.setPlaceholderText('선택 · 동일 시험의 기준 WAV (주파수 응답 비교용)')
        for title,edit in [('DUT WAV',self.source_edit),('기준 WAV',self.reference_edit)]:
            row = QHBoxLayout()
            tag = label(title,'muted')
            tag.setFixedWidth(72)
            row.addWidget(tag)
            row.addWidget(edit,1)
            button = QPushButton('파일 선택')
            button.clicked.connect(lambda checked=False,e=edit:self.browse_wav(e))
            row.addWidget(button)
            files.addLayout(row)
            edit.textChanged.connect(self.invalidate)
        layout.addWidget(self.file_card)
        split = QSplitter(Qt.Orientation.Horizontal)
        self.conditions,conditions = card()
        conditions.addWidget(label('측정 조건','section'))
        conditions.addWidget(label('단위: 초 · 종료 0 = 파일 끝','muted'))
        conditions.addSpacing(3)
        form = QFormLayout()
        form.setSpacing(9)
        self.signal_start = spin()
        self.signal_end = spin()
        form.addRow('신호 시작',self.signal_start)
        form.addRow('신호 종료',self.signal_end)
        conditions.addLayout(form)
        self.tone_enabled = QCheckBox('THD · 정상상태 단일 톤')
        conditions.addWidget(self.tone_enabled)
        self.tone_hz = spin(1000,maximum=40000,minimum=20,decimals=2)
        self.tone_hz.setSuffix(' Hz')
        conditions.addWidget(self.tone_hz)
        self.noise_enabled = QCheckBox('무음 구간 지정 · Noise / SNR')
        conditions.addWidget(self.noise_enabled)
        nf = QFormLayout()
        self.noise_start = spin(1)
        self.noise_end = spin(2)
        nf.addRow('무음 시작',self.noise_start)
        nf.addRow('무음 종료',self.noise_end)
        conditions.addLayout(nf)
        self.response_enabled = QCheckBox('주파수 응답 구간 별도 지정')
        conditions.addWidget(self.response_enabled)
        rf = QFormLayout()
        self.response_start = spin(2)
        self.response_end = spin(4)
        rf.addRow('응답 시작',self.response_start)
        rf.addRow('응답 종료',self.response_end)
        conditions.addLayout(rf)
        self.calibration_enabled = QCheckBox('교정 offset 적용 · dB SPL')
        conditions.addWidget(self.calibration_enabled)
        self.calibration_db = spin(110,maximum=250,minimum=-100,decimals=2)
        self.calibration_db.setSuffix(' dB')
        conditions.addWidget(self.calibration_db)
        conditions.addWidget(label('교정 offset = 기준 음압 − 교정 녹음 RMS(dBFS). 동일 마이크·게인 조건에만 적용하세요.','muted',True))
        conditions.addStretch()
        conditions.addWidget(label('필수 조건이 부족한 항목은 측정 불가로 표시됩니다.','muted',True))
        self.conditions.setMinimumWidth(278)
        condition_scroll = QScrollArea()
        condition_scroll.setWidgetResizable(True)
        condition_scroll.setWidget(self.conditions)
        split.addWidget(condition_scroll)
        result = QWidget()
        results = QVBoxLayout(result)
        results.setContentsMargins(10,0,0,0)
        results.setSpacing(12)
        self.summary_card,summary = card()
        summary_top = QHBoxLayout()
        verdict_text = QVBoxLayout()
        verdict_text.addWidget(label('FINAL RESULT','eyebrow'))
        self.verdict_label = label('READY','verdict')
        self.verdict_caption = label('분석 대기 · 실제 제품 Spec을 설정하세요.','muted',True)
        verdict_text.addWidget(self.verdict_label)
        verdict_text.addWidget(self.verdict_caption)
        summary_top.addLayout(verdict_text,1)
        self.run_button = QPushButton('▶  분석 실행')
        self.run_button.setObjectName('primary')
        self.run_button.clicked.connect(self.start_analysis)
        summary_top.addWidget(self.run_button)
        summary.addLayout(summary_top)
        self.progress = QProgressBar()
        self.progress.setFixedHeight(4)
        self.progress.setTextVisible(False)
        self.progress.hide()
        summary.addWidget(self.progress)
        results.addWidget(self.summary_card)
        metric_row = QHBoxLayout()
        self.metric_labels = {}
        for key,title,unit in [('rms_dbfs','RMS LEVEL','dBFS'),('thd_percent','THD · H2–H5','%'),('snr_db','SIGNAL / NOISE','dB')]:
            box,box_layout = card()
            box_layout.addWidget(label(title,'muted'))
            value = label('—','metric')
            box_layout.addWidget(value)
            box_layout.addWidget(label(unit,'muted'))
            metric_row.addWidget(box)
            self.metric_labels[key] = value
        results.addLayout(metric_row)
        self.plot_tabs = QTabWidget()
        self.plot_tabs.setMinimumHeight(260)
        self.plots = {}
        for key,title in [('waveform','파형'),('spectrum','주파수 스펙트럼'),('response','주파수 응답')]:
            plot = MeasurementPlot(key)
            self.plots[key] = plot
            self.plot_tabs.addTab(plot,title)
        results.addWidget(self.plot_tabs,2)
        result_top = QHBoxLayout()
        result_top.addWidget(label('항목별 판정','section'))
        result_top.addStretch()
        self.export_json_button = QPushButton('JSON 저장')
        self.export_csv_button = QPushButton('CSV 저장')
        self.export_json_button.clicked.connect(lambda:self.save_result('json'))
        self.export_csv_button.clicked.connect(lambda:self.save_result('csv'))
        for button in (self.export_json_button,self.export_csv_button):
            button.setEnabled(False)
            result_top.addWidget(button)
        results.addLayout(result_top)
        self.result_table = QTableWidget(0,5)
        self.result_table.setHorizontalHeaderLabels(['검사 항목','측정값','허용 범위','판정','사유'])
        self.result_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.result_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.result_table.setAlternatingRowColors(True)
        self.result_table.verticalHeader().hide()
        self.result_table.setColumnWidth(0,167)
        self.result_table.setColumnWidth(1,152)
        self.result_table.setColumnWidth(2,122)
        self.result_table.setColumnWidth(3,104)
        self.result_table.horizontalHeader().setSectionResizeMode(4,QHeaderView.ResizeMode.Stretch)
        self.result_table.setMinimumHeight(260)
        self.result_table.itemSelectionChanged.connect(self.show_reason)
        results.addWidget(self.result_table,3)
        self.reason_label = label('행을 선택하면 상세 사유를 확인할 수 있습니다.','muted',True)
        self.reason_label.setMinimumHeight(34)
        results.addWidget(self.reason_label)
        split.addWidget(result)
        split.setStretchFactor(0,0)
        split.setStretchFactor(1,1)
        split.setSizes([285,1000])
        layout.addWidget(split,1)
        measurement_scroll = QScrollArea()
        measurement_scroll.setWidgetResizable(True)
        measurement_scroll.setWidget(page)
        page.setMinimumHeight(1040)
        self.pages.addWidget(measurement_scroll)
        for control in (self.signal_start,self.signal_end,self.tone_hz,self.noise_start,self.noise_end,
                        self.response_start,self.response_end,self.calibration_db):
            control.valueChanged.connect(self.invalidate)
        for check,controls in [(self.tone_enabled,[self.tone_hz]),(self.noise_enabled,[self.noise_start,self.noise_end]),
                               (self.response_enabled,[self.response_start,self.response_end]),
                               (self.calibration_enabled,[self.calibration_db])]:
            for control in controls:
                control.setEnabled(False)
                check.toggled.connect(control.setEnabled)
            check.toggled.connect(self.invalidate)

    def _settings_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0,0,0,0)
        box,settings = card()
        self.sox_card = box
        settings.addWidget(label('SoX 실행 환경','section'))
        settings.addWidget(label('Windows에서는 설치한 sox.exe를 선택하세요. SoX는 별도로 제공해야 합니다.','muted',True))
        row = QHBoxLayout()
        self.sox_edit = QLineEdit(locate_sox())
        self.sox_edit.textChanged.connect(self.invalidate)
        row.addWidget(self.sox_edit,1)
        browse = QPushButton('실행 파일 선택')
        browse.clicked.connect(self.browse_sox)
        row.addWidget(browse)
        settings.addLayout(row)
        layout.addWidget(box)
        help_view = QTextBrowser()
        help_view.setHtml('''<h2>측정과 판정 안내</h2>
        <p>이 도구는 녹음된 WAV를 분석합니다. 스피커 재생·녹음 제어는 포함하지 않습니다.</p>
        <h3>1. 제품 Spec 설정</h3><p>Spec 관리에서 검사 사용 여부와 상·하한을 설정하세요. 예시 값은 제품 기준이 아닙니다.
        실제 제품 Spec 확인을 선택해야 최종 PASS가 가능합니다.</p>
        <h3>2. 구간과 시험 신호</h3><p>신호 구간: RMS, THD, SPL과 SNR의 신호 레벨에 사용합니다.
        Peak·클리핑은 파일 전체를 검사합니다. 클리핑은 |sample| ≥ 1−1/32768인 표본의 비율이며 아날로그 클리핑을 보장해서 검출하지 않습니다.</p>
        <p>THD: 정상상태 단일 톤을 지정하세요. 기본 주파수 주변 ±2%에서 추정하고 2~5차 왜율을 계산합니다.
        20 Hz 이상·샘플레이트/10 미만이어야 하며, 긴 구간은 앞 1초를 사용합니다. Sweep·음악·광대역 노이즈는 적합하지 않습니다.</p>
        <p>Noise/SNR: 신호와 겹치지 않는 무음 구간이 필요합니다. SNR은 신호 구간 전력에서 무음 전력을 차감한 값과 무음 전력의 비입니다.
        무음이 완전한 디지털 0이면 장비 노이즈를 알 수 없으므로 측정 불가입니다.</p>
        <p>주파수 응답: 동일 샘플레이트의 광대역 기준 녹음과 DUT의 Welch PSD 비율을 1/6 옥타브 대역에서 계산합니다.
        동일한 시간 구간이 두 파일에 적용됩니다. 톤·무음·광대역을 조합했다면 응답 구간을 별도로 지정하세요.
        기준 대비 상대 레벨이며 절대 무향실 응답이나 위상 측정이 아닙니다. 기준의 대역 에너지가 부족하면 측정 불가입니다.</p>
        <p>SPL: 교정 offset = 교정기 음압 − 교정 녹음 RMS(dBFS). 동일 마이크·입력 게인·경로에만 적용합니다.
        한 offset이 모든 채널에 적용되므로 채널별 교정이 필요한 경우 별도로 녹음하세요. A/C 가중치 없이 계산합니다.</p>
        <h3>3. 최종 결과</h3><p><b>PASS</b>: 활성 항목 모두 측정 완료·기준 충족·Spec 확인.<br>
        <b>NG</b>: 활성 항목 중 기준 초과 있음.<br><b>INCOMPLETE</b>: 측정 불가 항목 또는 활성 항목 없음.<br>
        <b>SPEC REQUIRED</b>: 제품 Spec 미확인. 항목별 NG가 있다면 표에서 확인하세요.<br>
        <b>SKIP</b>: Spec에서 사용하지 않는 항목.</p>
        <h3>결과 추적</h3><p>JSON은 측정값·그래프·Spec·구간·교정값·원본 SHA256·SoX 통계를 포함합니다.
        CSV는 Excel에서 열 수 있는 UTF-8 BOM 형식입니다. 입력이나 Spec을 변경하면 이전 결과의 저장이 해제됩니다.</p>
        <p>합성 샘플의 교정값은 시연용입니다. 실제 스피커 성능 검증에는 실제 측정 파일과 확정된 제품 기준이 필요합니다.</p>''')
        layout.addWidget(help_view,1)
        self.pages.addWidget(page)

    def browse_wav(self, edit):
        path,_ = QFileDialog.getOpenFileName(self,'WAV 선택','','WAV (*.wav *.WAV)')
        if path:
            edit.setText(path)

    def browse_sox(self):
        path,_ = QFileDialog.getOpenFileName(self,'SoX 실행 파일 선택','','실행 파일 (*.exe);;모든 파일 (*)')
        if path:
            self.sox_edit.setText(path)

    def settings(self):
        return AnalysisSettings(signal_start=self.signal_start.value(),signal_end=self.signal_end.value() or None,
            noise_start=self.noise_start.value() if self.noise_enabled.isChecked() else None,
            noise_end=self.noise_end.value() if self.noise_enabled.isChecked() else None,
            tone_hz=self.tone_hz.value() if self.tone_enabled.isChecked() else None,
            calibration_db=self.calibration_db.value() if self.calibration_enabled.isChecked() else None,
            response_start=self.response_start.value() if self.response_enabled.isChecked() else None,
            response_end=(self.response_end.value() or None) if self.response_enabled.isChecked() else None)

    def invalidate(self,*args):
        if self._initializing:
            return
        had_report = self.report is not None
        self.report = None
        self.export_json_button.setEnabled(False)
        self.export_csv_button.setEnabled(False)
        self.result_table.setRowCount(0)
        self.verdict_label.setText('READY')
        self.verdict_label.setStyleSheet('color: #8ba3bd;')
        self.verdict_caption.setText('조건 변경됨 · 분석을 실행하세요.')
        self.status.setText('준비됨 · 입력과 Spec을 확인한 뒤 분석하세요.')
        self.reason_label.setText('행을 선택하면 상세 사유를 확인할 수 있습니다.')
        source = Path(self.source_edit.text().strip())
        base = Path(sys.executable).parent if getattr(sys,'frozen',False) else Path(__file__).resolve().parent.parent
        is_demo = source.parent == base/'examples' and source.name in ('demo_composite.wav','demo_ng.wav')
        self.local_badge.setText('●  DEMO · 합성 데이터' if is_demo else '●  LOCAL · SoX')
        for value in self.metric_labels.values():
            value.setText('—')
        if had_report:
            for plot in self.plots.values():
                plot.render(None)

    def start_analysis(self):
        if self.worker is not None:
            return
        try:
            path = self.source_edit.text().strip()
            if not path or not Path(path).is_file():
                raise ValueError('분석할 WAV 파일을 선택하세요.')
            spec = self.spec_editor.read_spec()
            settings = self.settings()
        except (ValueError,OSError) as exc:
            self.analysis_error(str(exc))
            return
        self.invalidate()
        self.verdict_label.setText('ANALYZING')
        self.verdict_caption.setText('SoX 분석 중 · 잠시 기다려 주세요.')
        self.status.setText('분석 중 · 입력 파일과 Spec의 snapshot으로 계산합니다.')
        self.set_running(True)
        self.worker = AnalysisWorker(self.sox_edit.text(),path,settings,spec,self.reference_edit.text().strip() or None)
        self.worker.succeeded.connect(self.show_report)
        self.worker.failed.connect(self.analysis_error)
        self.worker.finished.connect(self.analysis_finished)
        self.worker.start()

    def set_running(self,running):
        self.run_button.setEnabled(not running)
        for w in (self.file_card,self.conditions,self.spec_editor,self.sox_card):
            w.setEnabled(not running)
        self.progress.setVisible(running)
        self.progress.setRange(0,0 if running else 1)

    def analysis_finished(self):
        worker = self.worker
        self.worker = None
        self.set_running(False)
        if worker:
            worker.deleteLater()

    def analysis_error(self,message):
        self.invalidate()
        self.report = None
        self.export_json_button.setEnabled(False)
        self.export_csv_button.setEnabled(False)
        self.verdict_label.setText('ERROR')
        self.verdict_label.setStyleSheet('color: #ff8995;')
        self.verdict_caption.setText(message)
        self.status.setText('분석 실패 · '+message)

    def show_report(self,report):
        self.report = report
        verdict = report['verdict']
        self.verdict_label.setText(verdict)
        self.verdict_label.setStyleSheet('color: '+STATUS_COLORS.get(verdict,'#8ba3bd')+';')
        counts = {s:sum(r['status']==s for r in report['rows']) for s in ('PASS','NG','UNAVAILABLE','SKIP')}
        prefix = '제품 Spec 확인 필요 · ' if verdict == 'SPEC REQUIRED' else ''
        self.verdict_caption.setText(prefix+f"PASS {counts['PASS']}  ·  NG {counts['NG']}  ·  측정 불가 {counts['UNAVAILABLE']}  ·  SKIP {counts['SKIP']}")
        for key,value_label in self.metric_labels.items():
            value = report['metrics'].get(key)
            vals = value if isinstance(value,list) else [value]
            vals = [v for v in vals if v is not None]
            chosen = (min(vals) if key in ('rms_dbfs','snr_db') else max(vals)) if vals else None
            value_label.setText('—' if chosen is None else f'{chosen:.2f}')
        self.result_table.setRowCount(len(report['rows']))
        for i,row in enumerate(report['rows']):
            vals = row['value'] if isinstance(row['value'],list) else [row['value']]
            text = ' / '.join('—' if v is None else f'{v:.3f}' for v in vals)
            if row['key']=='response_db':
                text = '주파수별 값 보기'
            low = '−∞' if row['lower'] is None else f"{row['lower']:g}"
            high = '+∞' if row['upper'] is None else f"{row['upper']:g}"
            bounds = '주파수별 기준' if row['key']=='response_db' else f'{low} ~ {high}'
            for col,value in enumerate((row['name'],text,bounds,row['status'],row['reason'])):
                cell = QTableWidgetItem(value)
                cell.setToolTip(value)
                if col == 3:
                    cell.setForeground(QColor(STATUS_COLORS[row['status']]))
                self.result_table.setItem(i,col,cell)
            self.result_table.setRowHeight(i,32)
        for plot in self.plots.values():
            plot.render(report)
        self.export_json_button.setEnabled(True)
        self.export_csv_button.setEnabled(True)
        source = report['source']
        self.status.setText(f"분석 완료 · {Path(source['path']).name} · {source['sample_rate']:,} Hz / {source['bits']} bit / {source['channels']} ch / {source['duration_seconds']:.3f} s · {report['sox']['version']}")

    def show_reason(self):
        if self.report is None:
            return
        index = self.result_table.currentRow()
        if index < 0 or index >= len(self.report['rows']):
            return
        row = self.report['rows'][index]
        text = row['reason']
        if row['key']=='response_db' and isinstance(row['value'],list):
            text += ' | '+' · '.join(f"{p['hz']:g}Hz: {'—' if v is None else f'{v:.2f}dB'}" for p,v in zip(self.report['spec']['response_points'],row['value']))
        self.reason_label.setText(text)

    def save_result(self,kind):
        if self.report is None:
            return
        path,_ = QFileDialog.getSaveFileName(self,'결과 저장',f'speaker-result.{kind}',f'{kind.upper()} (*.{kind})')
        if path:
            try:
                (export_json if kind=='json' else export_csv)(self.report,path)
                self.status.setText('결과 저장 완료 · '+path)
            except (ValueError,OSError) as exc:
                QMessageBox.warning(self,'저장 오류',str(exc))

    def load_demo(self):
        base = Path(sys.executable).parent if getattr(sys,'frozen',False) else Path(__file__).resolve().parent.parent
        source = base/'examples'/'demo_composite.wav'
        if not source.is_file():
            self.status.setText('샘플 파일이 없습니다. python scripts/generate_demo.py로 생성하세요.')
            return
        self.spec_editor.set_spec(default_spec())
        self.source_edit.setText(str(source))
        self.reference_edit.setText(str(base/'examples'/'demo_reference.wav'))
        self.signal_start.setValue(0)
        self.signal_end.setValue(1)
        self.tone_enabled.setChecked(True)
        self.tone_hz.setValue(1000)
        self.noise_enabled.setChecked(True)
        self.noise_start.setValue(1)
        self.noise_end.setValue(2)
        self.response_enabled.setChecked(True)
        self.response_start.setValue(2)
        self.response_end.setValue(4)
        self.calibration_enabled.setChecked(True)
        self.calibration_db.setValue(110)
        self.local_badge.setText('●  DEMO · 합성 데이터')
        self.status.setText('시연용 합성 WAV · 교정 offset 110 dB는 실제 장비 교정값이 아닙니다.')

    def closeEvent(self,event):
        if self.worker is not None:
            self.status.setText('분석이 끝난 뒤 창을 닫아 주세요.')
            event.ignore()
        else:
            event.accept()


def main():
    app = QApplication(sys.argv)
    app.setApplicationName('SpeakerCheck')
    window = MainWindow()
    window.show()
    sys.exit(app.exec())
