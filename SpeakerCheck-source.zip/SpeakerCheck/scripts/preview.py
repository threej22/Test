"""Offscreen UI preview and example snapshot; used during release verification."""
from pathlib import Path
import os
import sys
import time
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from PySide6.QtWidgets import QApplication
from speakercheck.ui import MainWindow
from speakercheck.report import export_json,export_csv

base = Path(__file__).resolve().parents[1]
out = base/'output'
out.mkdir(exist_ok=True)
app = QApplication([])
w = MainWindow()
w.show()
w.sox_edit.setText(os.environ.get('SOX_BINARY','sox'))
w.load_demo()
w.start_analysis()
deadline = time.monotonic()+30
while w.worker is not None and time.monotonic()<deadline:
    app.processEvents()
    time.sleep(.01)
if w.report is None:
    raise RuntimeError(w.status.text())
w.navigate(0)
app.processEvents()
w.grab().save(str(out/'SpeakerCheck-preview.png'))
w.navigate(1)
app.processEvents()
w.grab().save(str(out/'SpeakerCheck-spec.png'))
export_json(w.report,out/'demo-result.json')
export_csv(w.report,out/'demo-result.csv')
print(w.report['verdict'],[(r['key'],r['status']) for r in w.report['rows']])
w.close()
