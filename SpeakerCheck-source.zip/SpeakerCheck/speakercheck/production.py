"""Durable production ledger. A verdict is displayed only after a final commit."""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import csv
import json
import os
import sqlite3
import uuid

KST=timezone(timedelta(hours=9))
TERMINAL={'PASS','NG','INCOMPLETE','SPEC REQUIRED','ERROR','ABORTED'}


def _json(value):
    return json.dumps(value,ensure_ascii=False,allow_nan=False,separators=(',',':'))


class ProductionStore:
    def __init__(self,directory):
        self.directory=Path(directory).resolve()
        self.directory.mkdir(parents=True,exist_ok=True)
        self.path=self.directory/'production.sqlite3'
        with self._connect() as db:
            db.execute('''CREATE TABLE IF NOT EXISTS runs (
                run_id TEXT PRIMARY KEY, serial TEXT NOT NULL, operator TEXT NOT NULL,
                station TEXT NOT NULL, started_utc TEXT NOT NULL, ended_utc TEXT,
                state TEXT NOT NULL, capture_json TEXT NOT NULL, report_json TEXT,
                error TEXT NOT NULL DEFAULT '')''')

    def _connect(self):
        db=sqlite3.connect(self.path,timeout=5)
        db.row_factory=sqlite3.Row
        db.execute('PRAGMA synchronous=FULL')
        db.execute('PRAGMA busy_timeout=5000')
        return db

    def _event(self,run,event,detail=None):
        day=datetime.now(KST).strftime('%Y-%m-%d')
        folder=self.directory/day
        folder.mkdir(exist_ok=True)
        line=_json({'time_utc':datetime.now(timezone.utc).isoformat(),'run_id':run,'event':event,'detail':detail})+'\n'
        with (folder/'events.jsonl').open('a',encoding='utf-8') as f:
            f.write(line);f.flush();os.fsync(f.fileno())

    def begin(self,serial,operator,station,capture):
        serial=serial.strip()
        if not serial or len(serial)>200 or any(ord(c)<32 for c in serial):
            raise ValueError('제품번호를 1~200자로 입력하세요. 바코드 입력 후 Enter로 시작할 수 있습니다.')
        run_id=uuid.uuid4().hex
        now=datetime.now(timezone.utc)
        row={'run_id':run_id,'serial':serial,'operator':operator.strip(),'station':station.strip(),
             'started_utc':now.isoformat(),'state':'RUNNING','capture_json':_json(capture)}
        # Event write occurs before RUNNING commit; any failure stops before audio starts.
        self._event(run_id,'run.start',{'serial':serial,'station':station})
        with self._connect() as db:
            db.execute('INSERT INTO runs(run_id,serial,operator,station,started_utc,state,capture_json) VALUES(?,?,?,?,?,?,?)',
                tuple(row[k] for k in ('run_id','serial','operator','station','started_utc','state','capture_json')))
        day=self.directory/now.astimezone(KST).strftime('%Y-%m-%d')
        day.mkdir(exist_ok=True)
        row['wav_path']=str(day/(now.astimezone(KST).strftime('%H%M%S')+'-'+run_id+'.wav'))
        return row

    def event(self,run_id,event,detail=None):
        self._event(run_id,event,detail)

    def finish(self,run_id,state,report=None,error='',before_commit=None):
        if state not in TERMINAL:
            raise ValueError('지원하지 않는 최종 검사 상태입니다.')
        ended=datetime.now(timezone.utc).isoformat()
        with self._connect() as db:
            db.execute('BEGIN IMMEDIATE')
            row=db.execute('SELECT * FROM runs WHERE run_id=?',(run_id,)).fetchone()
            if row is None or row['state']!='RUNNING':
                raise ValueError('이미 종료되었거나 존재하지 않는 검사입니다.')
            if state in {'PASS','NG','INCOMPLETE','SPEC REQUIRED'} and (report is None or report.get('verdict')!=state):
                raise ValueError('최종 판정과 측정 보고서가 일치하지 않습니다.')
            saved=json.loads(_json(report)) if report is not None else None
            if saved is not None:
                saved['production']={'run_id':run_id,'serial':row['serial'],'operator':row['operator'],
                    'station':row['station'],'started_utc':row['started_utc'],'ended_utc':ended,
                    'capture':json.loads(row['capture_json']),'database':str(self.path)}
            # Event only announces a pending decision; SQLite COMMIT below is authoritative.
            self._event(run_id,'run.finalizing',{'pending_state':state,'error':error})
            if before_commit is not None:
                before_commit()
            db.execute('UPDATE runs SET ended_utc=?,state=?,report_json=?,error=? WHERE run_id=?',
                (ended,state,_json(saved) if saved is not None else None,error,run_id))
        return saved

    def history(self,serial='',limit=1000):
        with self._connect() as db:
            # Exact serial search avoids wildcard surprises in scanned barcodes.
            rows=db.execute('SELECT * FROM runs WHERE (?=\'\' OR serial=?) ORDER BY started_utc DESC LIMIT ?',
                (serial,serial,limit)).fetchall()
        return [dict(r) for r in rows]

    def get_report(self,run_id):
        with self._connect() as db:
            row=db.execute('SELECT report_json FROM runs WHERE run_id=?',(run_id,)).fetchone()
        if row is None or row['report_json'] is None:
            raise ValueError('완료된 측정 보고서가 없습니다. 오류/중단 이력을 확인하세요.')
        return json.loads(row['report_json'])

    def export_csv(self,path,serial=''):
        target=Path(path).resolve()
        protected={self.path,Path(str(self.path)+'-wal'),Path(str(self.path)+'-shm'),Path(str(self.path)+'-journal')}
        if target in protected:
            raise ValueError('양산 이력 데이터베이스를 CSV로 덮어쓸 수 없습니다.')
        with self._connect() as db:
            rows=db.execute('SELECT * FROM runs WHERE (?=\'\' OR serial=?) ORDER BY started_utc', (serial,serial))
            base_columns=('run_id','serial','operator','station','started_utc','ended_utc','state','error')
            metric_columns=('rms_dbfs','peak_dbfs','thd_percent','noise_dbfs','snr_db','balance_db','spl_db','clip_percent','response_db')
            columns=base_columns+metric_columns+('source_path','source_sha256','spec_name','spec_confirmed','capture_json')
            with target.open('w',encoding='utf-8-sig',newline='') as f:
                writer=csv.writer(f);writer.writerow(columns)
                for row in rows:
                    report=json.loads(row['report_json']) if row['report_json'] else {}
                    data={key:row[key] for key in base_columns}
                    metrics=report.get('metrics',{})
                    data.update({key:_json(metrics[key]) if key in metrics else '' for key in metric_columns})
                    data.update(source_path=report.get('source',{}).get('path',''),
                        source_sha256=report.get('source',{}).get('sha256',''),
                        spec_name=report.get('spec',{}).get('name',''),
                        spec_confirmed=report.get('spec',{}).get('confirmed',''),capture_json=row['capture_json'])
                    values=[]
                    for key in columns:
                        v=data[key]
                        if isinstance(v,str) and v.lstrip().startswith(('=','+','-','@')):
                            v="'"+v
                        values.append(v)
                    writer.writerow(values)
