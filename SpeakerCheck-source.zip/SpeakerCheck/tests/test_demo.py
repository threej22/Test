from pathlib import Path
import os
from speakercheck.sox import SoxEngine
from speakercheck.report import make_report
from speakercheck.analysis import AnalysisSettings
from speakercheck.spec import default_spec


def test_all_metrics_and_ng_using_real_sox_composite():
    base = Path(__file__).resolve().parents[1]/'examples'
    settings = AnalysisSettings(signal_end=1,noise_start=1,noise_end=2,tone_hz=1000,
                                calibration_db=110,response_start=2,response_end=4)
    spec = default_spec()
    spec['confirmed'] = True  # Test fixture only, never claim physical qualification.
    engine = SoxEngine(os.environ.get('SOX_BINARY','sox'))
    good = make_report(engine,base/'demo_composite.wav',settings,spec,base/'demo_reference.wav')
    assert good['verdict'] == 'PASS'
    assert all(row['status']=='PASS' for row in good['rows'])
    bad = make_report(engine,base/'demo_ng.wav',settings,spec,base/'demo_reference.wav')
    assert bad['verdict'] == 'NG'
    rows = {row['key']:row for row in bad['rows']}
    assert rows['balance_db']['status'] == 'NG'
    assert rows['thd_percent']['status'] == 'NG'
