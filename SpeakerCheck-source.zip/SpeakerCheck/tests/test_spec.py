import copy
import math
import pytest
from speakercheck.spec import default_spec, validate_spec, evaluate


def test_missing_enabled_measurement_never_passes():
    s = default_spec()
    s['confirmed'] = True
    rows, verdict = evaluate(s, {})
    assert verdict == 'INCOMPLETE'
    assert all(x['status'] == 'UNAVAILABLE' for x in rows)


def test_inclusive_bounds_and_unconfirmed_spec():
    s = default_spec()
    for rule in s['metrics'].values():
        rule['enabled'] = False
    s['metrics']['rms_dbfs'].update(enabled=True, lower=-30, upper=-10)
    assert evaluate(s, {'rms_dbfs': [-30, -10]})[1] == 'SPEC REQUIRED'
    s['confirmed'] = True
    assert evaluate(s, {'rms_dbfs': [-30, -10]})[1] == 'PASS'
    assert evaluate(s, {'rms_dbfs': [-30, -9.99]})[1] == 'NG'
    assert evaluate(s, {'rms_dbfs': [math.nan]})[1] == 'INCOMPLETE'


def test_disabled_all_does_not_pass():
    s = default_spec()
    s['confirmed'] = True
    for r in s['metrics'].values():
        r['enabled'] = False
    assert evaluate(s, {})[1] == 'INCOMPLETE'


@pytest.mark.parametrize('patch', [
    {'lower': 10, 'upper': -10}, {'upper': math.nan},
    {'upper': math.inf}, {'enabled': 'false'}, {'lower': None, 'upper': None}
])
def test_invalid_bounds_rejected(patch):
    s = default_spec()
    s['metrics']['rms_dbfs'].update(patch)
    with pytest.raises(ValueError):
        validate_spec(s)


def test_frequency_point_failure_is_ng():
    s = default_spec()
    s['confirmed'] = True
    for key, rule in s['metrics'].items():
        rule['enabled'] = key == 'response_db'
    vals = [0.] * len(s['response_points'])
    vals[2] = 7.
    assert evaluate(s, {'response_db': vals})[1] == 'NG'
    vals[2] = None
    assert evaluate(s, {'response_db': vals})[1] == 'INCOMPLETE'


def test_unknown_metric_rejected():
    s = default_spec()
    s['metrics']['unknown'] = {'enabled':True,'lower':0,'upper':1}
    with pytest.raises(ValueError):
        validate_spec(s)
