"""Portable binary diagnostic; synthetic signals never enter production results."""
import json
from pathlib import Path
import struct
import sys
import tempfile
import traceback
import numpy as np
from scipy.io import wavfile
from PySide6.QtWidgets import QApplication
from . import __version__
from .analysis import AnalysisSettings
from .audio import audio_backend,validate_returned_tone
from .comparison import tone_comparison
from .production import ProductionStore
from .report import make_report
from .sox import SoxEngine
from .spec import default_spec,inspection_spec
from .ui import MainWindow


def run_self_test(path):
    result={'app_version':__version__,'frozen':bool(getattr(sys,'frozen',False)),
            'pointer_bits':struct.calcsize('P')*8,'physical_audio_tested':False}
    try:
        audio_backend()  # The PortAudio library must load, even with no devices.
        result['portaudio_loaded']=True
        app=QApplication.instance() or QApplication([])
        app.setApplicationName('SpeakerCheck')
        result['qt_platform']=app.platformName()
        window=MainWindow();window.show();app.processEvents();window.close();app.processEvents()
        result['qt_widgets_loaded']=True
        engine=SoxEngine();result.update(sox=engine.version,sox_path=engine.executable)
        spec=inspection_spec(default_spec());spec['confirmed']=True
        fs=48000;t=np.arange(fs)/fs
        good=np.repeat((.03*np.sin(2*np.pi*1000*t))[:,None],2,axis=1)
        bad=good+(.01*np.sin(2*np.pi*2000*t))[:,None]
        with tempfile.TemporaryDirectory(prefix='SpeakerCheck-self-test-') as folder:
            folder=Path(folder)
            good_wav=folder/'one-khz.wav';bad_wav=folder/'two-tones.wav'
            wavfile.write(good_wav,fs,good.astype(np.float32));wavfile.write(bad_wav,fs,bad.astype(np.float32))
            settings=AnalysisSettings(signal_end=1,tone_hz=1000)
            report=make_report(engine,good_wav,settings,spec)
            bad_report=make_report(engine,bad_wav,settings,spec)
            if report['verdict']!='PASS' or bad_report['verdict']!='NG':
                raise RuntimeError('Synthetic signal decision check failed.')
            report['capture']={'valid_1khz_return':validate_returned_tone(good,fs)['valid'],'self_test':True}
            report['plots']['comparison']=tone_comparison(good,fs,1000,-24)
            store=ProductionStore(folder/'isolated-test-log');run=store.begin('SELF-TEST','','',{'self_test':True})
            store.finish(run['run_id'],report['verdict'],report)
            verified=store.verified_report(run['run_id'])
            if verified['final_result']!='PASS':raise RuntimeError('SQLite verification failed.')
            window=MainWindow();window.show_report(verified);app.processEvents()
            if window.verdict_label.text()!='PASS':raise RuntimeError('UI report check failed.')
            window.close();app.processEvents()
            result.update(single_tone='PASS',two_tones='FAIL',sqlite_verified=True)
        result['status']='ok'
        code=0
    except Exception:
        result.update(status='error',traceback=traceback.format_exc());code=1
    Path(path).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    return code
