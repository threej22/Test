SoX 바이너리는 포함되지 않습니다.
Windows SoX 배포본 전체(sox.exe와 DLL)를 tools/sox/ 아래에 놓으면 자동 탐색합니다.
또는 UI의 설정에서 sox.exe를 직접 선택하세요.
공식 프로젝트: https://sourceforge.net/projects/sox/
SoX 재배포 시 해당 라이선스와 배포 조건을 확인하세요.
