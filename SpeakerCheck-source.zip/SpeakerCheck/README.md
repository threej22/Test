# SpeakerCheck 0.2.0

SoX(sox.exe) 기반 **Windows 데스크톱 WAV 스피커 검증 도구**입니다. 한국어 UI에서 PC 1 kHz 재생, 디바이스 입력 자동 녹음, SoX 분석과 제품별 양산 로그를 제공합니다. 저장된 WAV를 별도로 분석하는 기존 기능도 포함합니다.

## Windows에서 실행

1. Python **3.11 이상(64 bit)**을 설치합니다. Python Launcher(`py`)도 설치하세요.
2. 이 폴더에서 `setup.bat`를 실행합니다. 최초 설치 시 인터넷이 필요합니다.
3. `start.bat`를 실행합니다.
4. **설정 · 측정 안내**에서 설치한 `sox.exe`를 선택합니다. 또는 SoX 배포본 전체를 `tools/sox/`에 놓습니다(sox.exe와 DLL 포함).
5. **자동 녹음 · 양산**에서 **장치 새로고침**을 누르고 PC 스피커 출력과 디바이스의 PC 입력을 각각 선택합니다.
6. 입력/출력 채널, 출력 레벨, 녹음 시간, 안정화 시간을 설정합니다.
7. **1 kHz 검사 항목 적용**을 누르고 **Spec 관리**에서 실제 제품 한계값을 설정·확인합니다.
8. 제품번호와 작업자/스테이션, 저장 폴더를 입력하고 **자동 녹음 → 판정**을 누릅니다. 바코드 입력 후 Enter로도 시작할 수 있습니다.
9. **제품별 시험 이력**에서 조회/CSV 저장 또는 선택 보고서 JSON 저장을 사용할 수 있습니다.

기존 버전을 사용했다면 새 폴더에 압축을 풀고 `setup.bat`를 다시 실행하세요. 새 오디오 의존성 `sounddevice`가 추가되었습니다.

SoX는 별도 설치가 필요하며 배포 파일에 포함하지 않습니다. 공식 프로젝트: https://sourceforge.net/projects/sox/

## 자동 검사와 연속 재생

연결: **PC 오디오 출력 → 스피커 → 디바이스의 음향 입력 → PC 오디오 녹음 장치**.

디바이스가 Windows 녹음 장치(USB Audio/오디오 인터페이스/라인 입력 등)로 인식되어야 합니다. 독자 UART/USB 데이터 패킷 프로토콜은 지원하지 않습니다. Windows 녹음 권한과 장치 드라이버를 확인하고, 양산 측정에서는 AGC/음향 효과와 입력 게인을 시험 조건에 맞게 고정하세요.

- **자동 녹음 → 판정**: 새 1 kHz 출력 시작 → 안정화 → 설정한 시간 녹음 → WAV 자동 저장 → SoX 분석 → 양산 로그 commit → 결과 표시. 앱이 새로 켠 톤은 녹음 후 중지합니다.
- **1 kHz 연속 재생**을 먼저 켜면 검사 전후에도 재생을 유지합니다. 성공한 검사 후 다음 제품번호를 스캔해 재검사할 수 있습니다.
- **무음 1초 추가**: 톤 잠시 mute → 안정화 → 무음 녹음 → unmute → 안정화 → 신호 녹음. 연속 재생도 이 구간에서는 잠시 중지됩니다. 옵션을 끄면 Noise/SNR에 사용할 별도 무음 구간이 없으므로 계산하지 않습니다.
- **상단 오디오 중지 / Esc**: 출력과 진행 중 녹음을 중지합니다. 최종 DB commit을 시작한 이후에는 이미 끝난 측정의 저장을 완료합니다. 장치 오류/중단/로그 오류는 PASS로 표시하지 않습니다.
- 기본 출력: **-24 dBFS Peak**, 48 kHz, 입력 1채널/출력 2채널, 신호 3초, 안정화 1초. 출력 레벨은 PC 시스템 볼륨과 함께 실제 스피커 음량에 영향을 줍니다.
- SPL 교정 적용/offset을 자동 검사 화면에서 설정할 수 있습니다. 1 kHz 전용 Spec 버튼은 수치 한계를 유지하며 주파수 응답을 끄고, 무음/채널/교정 조건에 맞춰 사용 항목을 설정합니다. Spec 확인은 해제되므로 실제 제품 기준을 확인해야 합니다.
- 녹음 전체에 대해 약 100 ms FFT 톤 에너지와 20 ms RMS를 확인합니다. 약 1 kHz(FFT bin 기준 980~1020 Hz), 톤 에너지 비율 60% 이상, 짧은 구간 전력이 중앙값의 10% 이상이어야 유효합니다. 이 조건은 단절/잘못된 입력을 막는 수집 유효성 검사이며 제품 Spec을 대체하지 않습니다.
- THD는 전체 신호 구간을 약 1초씩 나눠 계산한 채널별 최댓값입니다. 장기 평균에 숨겨지는 뒤쪽 왜곡을 놓치지 않도록 했습니다.

이 버전은 **정해진 시간의 자동 녹음 후 판정**합니다. 무기한 실시간 PASS 갱신이나 설비 PLC 자동 트리거는 포함하지 않습니다.

## 양산 Log

기본 저장 위치는 Windows 사용자별 앱 데이터의 `SpeakerCheck/results`이며 UI에서 변경할 수 있습니다.

```text
results/
  production.sqlite3          # 최종 판정의 원본 · report JSON 전체 포함
  YYYY-MM-DD/                 # KST 날짜
    HHMMSS-<run_id>.wav        # 자동 저장 녹음
    events.jsonl              # UTC 시각, run ID, 시작/녹음/판정 준비 이벤트
```

제품번호는 필수입니다. 같은 제품을 재검사해도 UUID Run ID를 새로 부여해 이전 이력을 덮어쓰지 않습니다. 시작 전에 `RUNNING`을 저장하고, 완료 시 `PASS/NG/INCOMPLETE/SPEC REQUIRED/ERROR/ABORTED`를 트랜잭션으로 기록합니다. 비정상 종료 후 남은 `RUNNING`은 합격이 아니며 수동 확인이 필요합니다.

기록: 제품번호, 작업자, 스테이션, 시작/종료 UTC, 소프트웨어/SoX 버전, 장치 이름/ID/host API, 출력·입력 설정, Spec/교정/분석 구간 snapshot, WAV 경로/SHA256, 측정값, 항목별 판정과 사유. 자동 저장이 실패하면 PASS를 표시하지 않습니다. `events.jsonl`의 `pending_state`는 commit 전 상태이며 최종 합격 집계에는 **SQLite state**를 사용하세요.

**제품별 시험 이력**에서 제품번호 정확히 검색, 최신 1,000건 표시, 전체 검색 이력 CSV 저장, 선택한 완료 보고서 JSON 저장이 가능합니다. CSV는 Excel용 UTF-8 BOM이며 주요 측정값을 개별 컬럼으로 내보냅니다. 전체 그래프와 정확한 Spec snapshot은 SQLite의 report JSON과 선택 보고서 JSON에 보관됩니다.

WAV 분석 화면에서 별도로 여는 파일은 오프라인 분석이며 자동 생산 이력을 생성하지 않습니다. 생산 검사에는 자동 녹음·양산 화면을 사용하세요. SQLite를 포함한 결과 폴더 전체를 유휴 상태에서 정기 백업하고 실제 양산 라인에서 전원 중단·디스크 오류·장치 재연결·교정 조건을 검증하세요.

## WAV 분석 빠른 시연

**합성 샘플 열기 → 분석 실행**을 누릅니다. SoX 경로가 먼저 설정되어야 합니다.

- 신호: 0~1초, 단일 톤 1000 Hz
- 무음: 1~2초
- 주파수 응답: 2~4초, `demo_reference.wav`와 비교
- 교정 offset: 110 dB, **시연용 수치이며 실제 장비 교정값이 아닙니다.**
- `demo_ng.wav`로 DUT만 바꾸면 THD·좌우차 NG를 볼 수 있습니다.

초기 Spec은 **EXAMPLE**입니다. 제품 기준을 확인하기 전에는 최종 `SPEC REQUIRED`를 표시합니다. 샘플의 항목별 PASS는 실제 스피커의 품질 인증이 아닙니다.

## 검사 항목

| 항목 | 측정 방법 / 필요 조건 |
|---|---|
| RMS | 신호 구간 채널별 RMS, dBFS |
| Peak | 파일 전체 채널별 최대 절대 레벨, dBFS |
| 클리핑 근접 표본 | 전체 파일에서 `abs(x) >= 1-1/32768`인 비율. 아날로그 clipping 검출 기능은 아님 |
| THD | 정상상태 단일 톤, 지정 주파수 ±2% 추정, 2~5차 harmonic 동시 적합. 20 Hz 이상·fs/10 미만. 전체 신호를 약 1초씩 나눈 채널별 최댓값 |
| 노이즈 | 신호와 겹치지 않는 별도 무음 구간 RMS, dBFS |
| SNR | `10 log10((P_signal-P_noise)/P_noise)`, 무가중 전체 대역. 디지털 0 무음은 측정 불가 |
| 좌우차 | 2채널 신호 RMS 레벨 차이의 절댓값 |
| SPL | RMS(dBFS) + 교정 offset. 동일 마이크/게인/경로 필요. 모든 채널에 같은 offset 적용, Z/무가중 |
| 주파수 응답 | 기준 WAV 대비 Welch PSD 비율, 1/6 octave 대역. 광대역 기준·동일 sample rate 필요. 주파수별 상·하한 |

THD용 단일 톤과 주파수 응답용 광대역은 서로 다른 신호입니다. 하나의 WAV에 결합했다면 **응답 구간 별도 지정**을 사용하세요. 응답 비교의 같은 구간이 기준 WAV에도 적용됩니다. 두 녹음은 같은 시험 조건/시간 구성이어야 합니다. 위상·지연·sweep deconvolution·마이크 주파수 EQ는 지원하지 않습니다.

SPL 교정: 알려진 교정기 음압이 94 dB SPL이고 동일 체인의 교정 녹음 RMS가 -20 dBFS이면 offset은 114 dB입니다. dBFS 자체를 dB SPL로 취급하면 안 됩니다. A/C 가중치는 적용하지 않습니다.

## 판정 규칙

- `PASS`: 활성 항목 모두 측정됨 + 모든 한계 이내 + 제품 Spec 확인됨.
- `NG`: 활성 항목 하나 이상이 한계를 벗어남.
- `INCOMPLETE`: 활성 항목이 없거나 필수 항목 측정 불가. 다른 항목에 NG가 있으면 최종 NG.
- `SPEC REQUIRED`: 제품 Spec 미확인. 이 상태에서도 항목별 NG는 표에 표시됩니다.
- `SKIP`: Spec에서 사용하지 않는 항목.

상·하한은 경계값을 포함합니다. 다채널 항목은 모든 채널이 기준을 만족해야 합니다. 응답은 대역별 최악 채널 값을 표시하며 나머지 항목은 채널별 값을 보존합니다. Spec 한계값을 수정하면 제품 Spec 확인이 해제됩니다.

## 결과와 입력 제한

JSON: 파일 경로·SHA256·SoX 버전/원본 통계·Spec·교정/구간·측정값·그래프 데이터·판정.
CSV: Excel 호환 UTF-8 BOM, 채널/주파수별 측정값과 기준 및 사유. 항목의 모든 행에 항목 전체의 판정을 표시합니다.

입력/Spec 변경 시 이전 결과가 무효화됩니다. 분석 중 설정은 잠기며 종료 후 창을 닫을 수 있습니다. 녹음 중인 파일 대신 완성된 파일을 사용하세요. 분석 중 원본이 바뀌면 오류 처리합니다.

RIFF/RIFX/RF64 WAV, 1~32채널, 1~768 kHz, 최소 32표본, 파일 및 float64 디코딩 크기 각각 최대 512 MiB입니다. SoX 각 명령 제한 시간은 60초입니다. PCM 16/24 bit와 정규화 float 입력을 검증했습니다. float 원본은 유한하고 -1~+1 범위여야 하며 NaN/Inf/초과 표본은 거부합니다. SoX 내부 표본 정밀도(일반적으로 32 bit)의 영향을 받으므로 디지털 극저레벨 측정용으로 사용하기 전 검증이 필요합니다.

## EXE 빌드

Windows에서 `build_windows.bat`를 실행하면 PyInstaller로 `dist/SpeakerCheck/SpeakerCheck.exe`를 만듭니다. **dist/SpeakerCheck 폴더 전체**를 배포하세요. `tools/sox/`가 있으면 배포 폴더로 복사합니다. SoX 재배포 시 해당 라이선스 조건을 확인하세요.

이 프로젝트는 Linux에서 실제 SoX, SQLite와 Qt offscreen으로 검증했습니다. 물리 오디오 입출력은 합성 backend로 시험했으며 Windows 녹음 장치가 연결된 실제 체인은 시험하지 않았습니다. **Windows EXE는 빌드하거나 Windows 실기기에서 실행 검증하지 않았습니다.** `setup.bat`, `start.bat`, `build_windows.bat`는 Windows용으로 제공됩니다.

## 개발 및 검증

```bash
python -m pip install -r requirements-dev.txt
# sox를 PATH에 넣거나 SOX_BINARY 환경 변수에 전체 경로 지정
python -m pytest tests -q
python -m speakercheck
```

Linux CI에서는 `QT_QPA_PLATFORM=offscreen`을 지정할 수 있습니다. 샘플 재생성: `python scripts/generate_demo.py`. 화면 및 보고서 생성: `python scripts/preview.py`(SoX 필요).

구조: `audio.py` 오디오 I/O, `capture_ui.py` 자동 검사 UI/worker, `production.py` 양산 로그/CSV, `sox.py` 실행/디코딩, `analysis.py` 계산, `spec.py` 검증/판정, `report.py` 저장, `ui.py` 화면, `spec_editor.py` 기준 편집, `plots.py` 그래프. 설계/검증 기록은 `docs/`에 있습니다.
