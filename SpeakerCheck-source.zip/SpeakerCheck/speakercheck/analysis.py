"""Signal measurements. Digital level is never implicitly acoustic SPL."""
from dataclasses import dataclass, asdict
import math
import numpy as np
from scipy import signal, optimize
from .spec import validate_spec, evaluate


@dataclass(frozen=True)
class AnalysisSettings:
    signal_start: float = 0.
    signal_end: float | None = None
    noise_start: float | None = None
    noise_end: float | None = None
    tone_hz: float | None = None
    calibration_db: float | None = None
    response_start: float | None = None
    response_end: float | None = None


@dataclass
class AnalysisResult:
    metrics: dict
    reasons: dict
    rows: list
    verdict: str
    plots: dict
    settings: dict
    spec: dict


def _db(x):
    return 20*np.log10(np.maximum(x, 1e-300))


def _values(x):
    vals = [float(v) if np.isfinite(v) else None for v in np.atleast_1d(x)]
    return None if all(v is None for v in vals) else vals


def _levels(x):
    rms = np.sqrt(np.mean(np.square(x), axis=0))
    return [float(_db(v)) if v > 1e-15 else None for v in rms]


def _range(start, end, fs, n):
    duration = n/fs
    if not 0 <= start < duration or (end is not None and not start < end <= duration + 1e-9):
        raise ValueError(f'분석 구간을 확인하세요. 파일 길이: {duration:.3f}초')
    a, b = int(round(start*fs)), n if end is None else min(n, int(round(end*fs)))
    if b-a < 32:
        raise ValueError('분석 구간은 최소 32개 표본이어야 합니다.')
    return a, b


def _thd(x, fs, nominal):
    if not 20 <= nominal < fs/10 or len(x) < fs*max(.1, 20/nominal):
        return None
    # One second limits memory and makes the stationary-tone assumption explicit.
    x = x[:min(len(x), fs)]
    x = x - np.mean(x)
    power = np.mean(x*x)
    if power < 1e-12:
        return None
    t = np.arange(len(x))/fs
    window = np.hanning(len(x))
    freqs = np.fft.rfftfreq(len(x), 1/fs)
    spectrum = np.abs(np.fft.rfft(x*window))
    search = np.flatnonzero((freqs >= nominal*.98) & (freqs <= nominal*1.02))
    if not len(search):
        return None
    guess = freqs[search[np.argmax(spectrum[search])]]
    resolution = fs/len(x)
    def objective(f):
        return -abs(np.dot(x*window, np.exp(-2j*np.pi*f*t)))**2
    fit = optimize.minimize_scalar(objective, bounds=(max(nominal*.98, guess-resolution),
                                   min(nominal*1.02, guess+resolution)), method='bounded',
                                   options={'xatol': 1e-7})
    f = fit.x
    if f*5 >= fs/2:
        return None
    cols = [np.ones(len(t))]
    for k in range(1, 6):
        cols.extend([np.sin(2*np.pi*k*f*t), np.cos(2*np.pi*k*f*t)])
    design = np.column_stack(cols)
    coeff, *_ = np.linalg.lstsq(design, x, rcond=None)
    amps = np.hypot(coeff[1::2], coeff[2::2])
    residual = np.mean((x-design@coeff)**2)
    if amps[0]**2/2 < .5*power or residual > .1*power:
        return None
    return float(100*np.linalg.norm(amps[1:])/amps[0])


def _response(x, ref, fs, points):
    if ref.ndim != 2 or ref.shape[1] not in (1, x.shape[1]) or len(ref) < 1024 or len(x) < 1024:
        return None, None
    nperseg = min(8192, len(x)//2, len(ref)//2)
    f, px = signal.welch(x, fs, nperseg=nperseg, axis=0)
    _, pr = signal.welch(ref, fs, nperseg=nperseg, axis=0)
    values = []
    for point in points:
        hz = point['hz']
        band = (f >= hz/2**(1/12)) & (f <= hz*2**(1/12))
        if hz*2**(1/12) >= fs/2 or not np.any(band):
            values.append(None)
            continue
        rp = np.mean(pr[band], axis=0)
        xp = np.mean(px[band], axis=0)
        # Require broadband excitation within 40 dB of the reference's PSD peak.
        if np.any(rp <= np.max(pr, axis=0)*1e-4) or np.any(xp < 1e-24):
            values.append(None)
            continue
        gains = 10*np.log10(xp/rp)
        lo, hi = point['lower'], point['upper']
        # Return the channel furthest outside this band's envelope.
        violation = np.maximum(0 if lo is None else lo-gains, 0 if hi is None else gains-hi)
        idx = int(np.argmax(violation)) if np.any(violation > 0) else int(np.argmax(np.abs(gains)))
        values.append(float(gains[idx]))
    return values, {'hz': [p['hz'] for p in points], 'db': values,
                    'lower': [p['lower'] for p in points], 'upper': [p['upper'] for p in points]}


def analyze_pcm(pcm, fs, settings, spec, reference=None):
    spec = validate_spec(spec)
    x = np.asarray(pcm, dtype=np.float64)
    if x.ndim != 2 or not len(x) or x.shape[1] < 1 or not np.all(np.isfinite(x)) or fs < 1000:
        raise ValueError('유효한 WAV 표본/샘플레이트가 아닙니다.')
    for value in asdict(settings).values():
        if value is not None and (isinstance(value, bool) or not math.isfinite(value)):
            raise ValueError('측정 설정은 유한한 숫자여야 합니다.')
    a, b = _range(settings.signal_start, settings.signal_end, fs, len(x))
    active = x[a:b]
    rms = np.sqrt(np.mean(active*active, axis=0))
    peaks = np.max(np.abs(x), axis=0)
    levels = _levels(active)
    metrics = {'rms_dbfs': None if all(v is None for v in levels) else levels,
               'peak_dbfs': None if np.all(peaks < 1e-15) else [float(_db(v)) if v > 1e-15 else None for v in peaks],
               'clip_percent': _values(100*np.mean(np.abs(x) >= 1-1/32768, axis=0)),
               'balance_db': float(abs(_db(rms[0])-_db(rms[1]))) if x.shape[1] == 2 and np.all(rms > 1e-15) else None,
               'thd_percent': None, 'noise_dbfs': None, 'snr_db': None,
               'spl_db': [None if v is None else v+settings.calibration_db for v in levels] if settings.calibration_db is not None else None,
               'response_db': None}
    reasons = {'rms_dbfs': '무음 또는 유효 신호가 없는 채널입니다.',
               'peak_dbfs': '무음 채널입니다.',
               'balance_db': '2채널 WAV와 양쪽 채널의 유효 신호가 필요합니다.',
               'thd_percent': '정상상태 단일 톤 구간과 올바른 기본 주파수가 필요합니다(20 Hz 이상, fs/10 미만).',
               'noise_dbfs': '신호와 겹치지 않는 무음 구간이 필요합니다.',
               'snr_db': '별도 무음 구간과 무음보다 큰 신호 전력이 필요합니다.',
               'spl_db': '동일 마이크·녹음 게인의 교정 offset이 필요합니다.',
               'response_db': '동일 시험의 광대역 기준 WAV와 충분한 대역별 신호가 필요합니다.'}
    if settings.tone_hz is not None:
        vals = [_thd(active[:, c], fs, settings.tone_hz) for c in range(x.shape[1])]
        metrics['thd_percent'] = None if all(v is None for v in vals) else vals
    if settings.noise_start is not None and settings.noise_end is not None:
        try:
            na, nb = _range(settings.noise_start, settings.noise_end, fs, len(x))
            if max(a, na) < min(b, nb):
                raise ValueError('무음 구간이 신호 구간과 겹칩니다.')
            noise = x[na:nb]
            metrics['noise_dbfs'] = _levels(noise)
            npower = np.mean(noise*noise, axis=0)
            spower = rms*rms - npower
            metrics['snr_db'] = [float(10*np.log10(s/n)) if s > 0 and n > 1e-30 else None for s, n in zip(spower, npower)]
            if all(v is None for v in metrics['noise_dbfs']):
                metrics['noise_dbfs'] = None
        except ValueError as exc:
            reasons['noise_dbfs'] = reasons['snr_db'] = str(exc)
    response_plot = None
    if reference is not None:
        ref = np.asarray(reference, dtype=float)
        if not np.all(np.isfinite(ref)):
            raise ValueError('기준 WAV에 유효하지 않은 표본이 있습니다.')
        # Composite tests can use a separate broadband interval for the response.
        ra, rb = _range(settings.response_start if settings.response_start is not None else settings.signal_start,
                        settings.response_end if settings.response_end is not None else settings.signal_end, fs, len(x))
        ref_slice = ref[ra:min(rb, len(ref))]
        if len(ref) < rb:
            reasons['response_db'] = '기준 WAV가 선택한 신호 구간보다 짧습니다.'
        else:
            metrics['response_db'], response_plot = _response(x[ra:rb], ref_slice, fs, spec['response_points'])
    rows, verdict = evaluate(spec, metrics, reasons)
    nseg = min(8192, len(active))
    f, psd = signal.welch(active, fs, nperseg=nseg, axis=0)
    # Peak-preserving envelope for long recordings, never every-N decimation.
    edges = np.linspace(0, len(x), min(1600, len(x))+1, dtype=int)
    low = [float(np.min(x[lo:hi])) for lo, hi in zip(edges[:-1], edges[1:])]
    high = [float(np.max(x[lo:hi])) for lo, hi in zip(edges[:-1], edges[1:])]
    plots = {'waveform': {'time': (edges[:-1]/fs).tolist(), 'min': low, 'max': high},
             'spectrum': {'hz': f[1:].tolist(), 'db': (10*np.log10(np.maximum(np.mean(psd[1:], axis=1), 1e-30))).tolist()},
             'response': response_plot}
    return AnalysisResult(metrics, reasons, rows, verdict, plots, asdict(settings), spec)
